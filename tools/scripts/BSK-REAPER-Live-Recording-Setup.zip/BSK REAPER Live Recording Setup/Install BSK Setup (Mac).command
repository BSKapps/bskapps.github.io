#!/bin/bash
set -e

SRC="$(cd "$(dirname "$0")" && pwd)"
REZ="$HOME/Library/Application Support/REAPER"
STAMP="$(date +%Y%m%d-%H%M%S)"

echo "BSK REAPER Live Recording Setup installer"
echo

if [ "$BSK_INSTALL_FORCE" != "1" ] && pgrep -x "REAPER" >/dev/null 2>&1; then
    echo "REAPER is running. Quit REAPER first, then run this installer again."
    exit 1
fi

if [ ! -d "$REZ" ]; then
    echo "REAPER resource folder not found at:"
    echo "  $REZ"
    echo "Run REAPER once first. For portable installs, use the manual"
    echo "steps in README.txt instead."
    exit 1
fi

echo "Installing into: $REZ"
echo

mkdir -p "$REZ/ProjectTemplates" "$REZ/TrackTemplates" "$REZ/Scripts" \
         "$REZ/Data/toolbar_icons" "$REZ/ColorThemes"

cp -f "$SRC/ProjectTemplates/"*.RPP                 "$REZ/ProjectTemplates/"
cp -f "$SRC/TrackTemplates/"*.RTrackTemplate        "$REZ/TrackTemplates/"
cp -Rf "$SRC/Scripts/BSK_Reaper_Scripts"            "$REZ/Scripts/"
cp -f "$SRC/Data/toolbar_icons/"*.png               "$REZ/Data/toolbar_icons/"
cp -f "$SRC/ColorThemes/"*.ReaperThemeZip           "$REZ/ColorThemes/"
echo "Copied templates, scripts, toolbar icons and theme."

if [ -f "$REZ/reaper-screensets.ini" ]; then
    cp "$REZ/reaper-screensets.ini" "$REZ/reaper-screensets.ini.backup-$STAMP"
    echo "Backed up your existing window sets to reaper-screensets.ini.backup-$STAMP"
fi
cp -f "$SRC/WindowSets/reaper-screensets.ini" "$REZ/reaper-screensets.ini"
echo "Installed window sets (meter bridge and mixer views)."

merge_section() {
    ini="$1"; section="$2"; srcfile="$3"
    [ -f "$ini" ] && cp "$ini" "$ini.backup-$STAMP" || : > "$ini"
    awk -v sec="[$section]" '
        $0 == sec      { skip = 1; next }
        /^\[/          { skip = 0 }
        !skip          { print }
    ' "$ini" > "$ini.tmp"
    awk -v sec="[$section]" '
        $0 == sec { found = 1 }
        found && /^\[/ && $0 != sec { exit }
        found { print }
    ' "$srcfile" >> "$ini.tmp"
    printf '\n' >> "$ini.tmp"
    mv "$ini.tmp" "$ini"
}

merge_section "$REZ/S&M.ini" "TrackTemplates" "$SRC/Toolbars/SWS-Resources-TrackTemplates.txt"
echo "Filled the SWS Resources track template list (slots 1-8)."

merge_section "$REZ/reaper-themeconfig.ini" "Default_5.0_green_yellow_red_VU" "$SRC/WindowSets/reaper-themeconfig.ini"
echo "Installed theme colour calibration."

echo
echo "Done. Finish inside REAPER (see README.txt):"
echo "  1. Actions > Show action list > Key map... > Import...  -> Toolbars/BSK_Actions.ReaperKeyMap"
echo "  2. Extensions > Cycle Action editor > Import/export > Import all sections -> Toolbars/BSK_Cyclactions.ini"
echo "  3. Right-click each toolbar > Customize toolbar... > Import... -> matching file in Toolbars/"
echo "  4. Options > Themes > Default_5.0_green_yellow_red_VU"
