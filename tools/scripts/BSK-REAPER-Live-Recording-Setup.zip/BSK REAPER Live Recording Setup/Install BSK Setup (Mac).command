#!/bin/bash
set -e

SRC="$(cd "$(dirname "$0")" && pwd)"
REZ="${BSK_INSTALL_REZ:-$HOME/Library/Application Support/REAPER}"
STAMP="$(date +%Y%m%d-%H%M%S)"

echo "BSK REAPER Live Recording Setup installer"
echo

if [ "$BSK_INSTALL_FORCE" != "1" ] && pgrep -x "REAPER" >/dev/null 2>&1; then
    echo "REAPER is running. Quit REAPER first, then run this installer again."
    exit 1
fi

if [ ! -f "$REZ/reaper.ini" ]; then
    echo "REAPER resource folder not found at:"
    echo "  $REZ"
    echo "Start REAPER once and quit it, then run this installer again."
    echo "For a portable REAPER, use the Portable download instead."
    exit 1
fi

echo "Installing into: $REZ"
echo

backup() {
    [ -f "$1" ] && cp "$1" "$1.backup-$STAMP"
    return 0
}

mkdir -p "$REZ/ProjectTemplates" "$REZ/TrackTemplates" "$REZ/FXChains" \
         "$REZ/Scripts/BSK_Reaper_Scripts" "$REZ/ColorThemes" \
         "$REZ/Data/toolbar_icons/150" "$REZ/Data/toolbar_icons/200"

cp -f "$SRC/ProjectTemplates/"*.RPP                 "$REZ/ProjectTemplates/"
cp -f "$SRC/TrackTemplates/"*.RTrackTemplate        "$REZ/TrackTemplates/"
cp -f "$SRC/FXChains/"*.RfxChain                    "$REZ/FXChains/"
cp -f "$SRC/Scripts/BSK_Reaper_Scripts/"*.lua       "$REZ/Scripts/BSK_Reaper_Scripts/"
cp -f "$SRC/Data/toolbar_icons/"*.png               "$REZ/Data/toolbar_icons/"
cp -f "$SRC/Data/toolbar_icons/150/"*.png           "$REZ/Data/toolbar_icons/150/"
cp -f "$SRC/Data/toolbar_icons/200/"*.png           "$REZ/Data/toolbar_icons/200/"
cp -f "$SRC/ColorThemes/"*.ReaperThemeZip           "$REZ/ColorThemes/"
echo "Copied templates, FX chains, scripts, toolbar icons and theme."

STARTUP="$REZ/Scripts/__startup.eel"
if [ ! -f "$STARTUP" ]; then
    cp "$SRC/Scripts/__startup.eel" "$STARTUP"
    echo "Added the startup file that lights the toolbar buttons at launch."
elif grep -q "_RSc33c09db3647fbb75a92022edef4d9d24ceb880e" "$STARTUP"; then
    echo "Startup file already starts the BSK lights."
else
    backup "$STARTUP"
    printf '\n' >> "$STARTUP"
    grep -v '^//' "$SRC/Scripts/__startup.eel" >> "$STARTUP"
    echo "Added the BSK lights to your existing startup file (backup next to it)."
fi

backup "$REZ/reaper-screensets.ini"
cp -f "$SRC/WindowSets/reaper-screensets.ini" "$REZ/reaper-screensets.ini"
echo "Installed window sets (meter bridge and mixer views)."

MENU="$REZ/reaper-menu.ini"
[ -f "$MENU" ] || : > "$MENU"
backup "$MENU"
awk '
    /^\[/ { skip = ($0 == "[Main toolbar]" || $0 ~ /^\[Floating toolbar ([1-9]|10)\]$/) }
    !skip { print }
' "$MENU" > "$MENU.tmp"
cat "$SRC/Toolbars/BSK_Toolbars.ini" >> "$MENU.tmp"
mv "$MENU.tmp" "$MENU"
echo "Installed the toolbars (Main toolbar and floating toolbars 1 to 10)."

set_key() {
    ini="$1"; section="$2"; key="$3"; value="$4"
    awk -v sec="[$section]" -v key="$key" -v val="$value" '
        function put() { if (!done) { print key "=" val; done = 1 } }
        $0 == sec { insec = 1; seen = 1; print; next }
        /^\[/ { if (insec) put(); insec = 0 }
        insec && index($0, key "=") == 1 { put(); next }
        { print }
        END { if (insec) put(); else if (!seen) { print sec; put() } }
    ' "$ini" > "$ini.tmp"
    mv "$ini.tmp" "$ini"
}

INI="$REZ/reaper.ini"
backup "$INI"
while IFS='=' read -r key value; do
    [ -n "$key" ] && set_key "$INI" "REAPER" "$key" "$value"
done < "$SRC/Toolbars/BSK_Settings.txt"
current="$(awk '/^\[/{insec=($0=="[REAPER]")} insec && /^diskcheck=/{sub(/^diskcheck=/,""); print; exit}' "$INI")"
if [ -n "$current" ]; then
    set_key "$INI" "REAPER" "diskcheck" "$(( current - current % 2 ))"
else
    set_key "$INI" "REAPER" "diskcheck" "22"
fi
set_key "$INI" "SWS" "Record input check" "0"
echo "Set the mixer layouts, the recorded file names, and turned off the"
echo "free disk space check and the SWS record input check at record start."

SNM="$REZ/S&M.ini"
[ -f "$SNM" ] || : > "$SNM"
backup "$SNM"
awk '
    /^\[/ { skip = ($0 == "[TrackTemplates]") }
    !skip { print }
' "$SNM" > "$SNM.tmp"
cat "$SRC/Toolbars/SWS-Resources-TrackTemplates.txt" >> "$SNM.tmp"
mv "$SNM.tmp" "$SNM"
echo "Filled the SWS Resources track template list (slots 1-9)."

echo
echo "Your toolbars, window sets, reaper.ini, S&M.ini and startup file are backed up"
echo "next to the originals with .backup-$STAMP"
echo
echo "Done. Finish inside REAPER (see README.txt):"
echo "  1. Actions > Show action list > Key map... >"
echo "     Import shortcuts/custom actions, import all sections...  -> Toolbars/BSK_Actions.ReaperKeyMap"
echo "  2. Options > Themes > bsk_flat"
echo "  3. Quit and restart REAPER."
