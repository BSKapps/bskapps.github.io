-- @description BSK Transport: SPACE KEY (play/pause; never pauses a recording)
-- @author BSK
-- @version 1.1
-- @about For the Space key. Stopped: plays. Playing: pauses. Paused: carries on. Recording: does nothing, so a stray Space never pauses a take. A paused recording carries on.

if reaper.set_action_options then reaper.set_action_options(3) end
reaper.defer(function() end)

local state = reaper.GetPlayState()
if state & 4 == 4 and state & 2 == 0 then return end
reaper.Main_OnCommand(40073, 0)
