-- @description BSK Transport: AUDITION TIME SELECTION (play the time selection once; press again to stop)
-- @author BSK
-- @version 1.0
-- @about Plays the time selection once from its start, loop off. Lit from the press until playback stops. Pressed lit: stops, puts back the loop setting and any solo the press turned on, and keeps the selections. Does not light while recording.

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")

transport.audition("_RS78e2502909765363524f2a15f4a22d45a01bae3a")
