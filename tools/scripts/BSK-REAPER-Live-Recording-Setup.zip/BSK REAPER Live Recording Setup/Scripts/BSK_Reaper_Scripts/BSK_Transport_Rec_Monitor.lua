-- @description BSK Transport: REC MONITOR (lit while every track is record monitoring, slow blink while only some are; press to turn it on for all, or off for all when lit)
-- @author BSK
-- @version 1.0
-- @about Unlit or blinking: turns record monitoring on for every track. Lit: turns it off for every track. Runs the SELECT ALL RECORD MONITOR ON / OFF custom actions, then unselects all tracks.

if reaper.set_action_options then reaper.set_action_options(3) end
reaper.defer(function() end)

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")

transport.recMonitor()
