-- @description BSK: TOGGLE PUT ENVELOPES IN MEDIA/LANES
-- @author BSK
-- @version 1.0
-- @about First press puts the selected envelopes in the media lane and lights; the next press puts them back in their own lanes and goes dark. Needs the SWS extension.

if reaper.set_action_options then reaper.set_action_options(3) end
reaper.defer(function() end)

local _, _, section, id = reaper.get_action_context()
local on = reaper.GetToggleCommandStateEx(section, id) == 1
local step = reaper.NamedCommandLookup(on and "_WOL_PUTSELENVINENVLANE" or "_WOL_PUTSELENVINMEDIALANE")
if step == 0 then
  reaper.ShowMessageBox("Failed to run Put Envelopes in Media/Lanes: the SWS extension is not installed.\n\nInstall SWS, then try again.", "Put Envelopes in Media/Lanes", 0)
  return
end
reaper.Main_OnCommand(step, 0)
reaper.SetToggleCommandState(section, id, on and 0 or 1)
reaper.RefreshToolbar2(section, id)
