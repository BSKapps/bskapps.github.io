-- @description BSK Transport: SAFE REC (arm all, monitor off, record from the end)
-- @author BSK
-- @version 1.0
-- @about Stopped: runs the Safe Record steps custom action, or says it failed when that custom action is missing. While recording: drops a marker only. This button stays lit until recording stops, including across NEW TAKE.

if reaper.set_action_options then reaper.set_action_options(3) end
reaper.defer(function() end)

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")

if reaper.GetPlayState() & 4 == 4 then
  reaper.Main_OnCommand(40157, 0) -- Markers: Insert marker at current position
  return
end

local safe = transport.customAction(transport.SAFE_ACTION, "SAFE REC")
if not safe then return end
transport.fixRecordMode()
reaper.Main_OnCommand(safe, 0) -- Custom: Safe Record with Marker

if reaper.GetPlayState() & 4 == 4 then
  transport.setLight(transport.SAFE_ID, true)
end
