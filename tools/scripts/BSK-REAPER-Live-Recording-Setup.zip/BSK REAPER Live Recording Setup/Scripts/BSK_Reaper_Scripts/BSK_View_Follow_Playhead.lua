-- @description BSK View: FOLLOW PLAYHEAD (the view follows the play cursor in playback and recording)
-- @author BSK
-- @version 1.1
-- @about Turns REAPER's auto-scroll on for both playback and recording, or off for both when both are on. Lit while both are on, blinks slowly while only one is.

if reaper.set_action_options then reaper.set_action_options(3) end
reaper.defer(function() end)

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")

transport.toggleFollow()
