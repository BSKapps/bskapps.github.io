-- @description BSK View: RECORD / VSC flip (for the Stream Deck: on RECORD goes to VSC, otherwise to RECORD)
-- @author BSK
-- @version 1.1
-- @about For a Stream Deck key (hold). Last tab pressed was RECORD: does exactly what the VSC tab does. Any other tab: does exactly what the RECORD tab does. Same rules as the tabs: docked meters hide on VSC, floating ones stay, RECORD opens the meters and TIME LEFT only if closed (and TIME LEFT not hidden with its button).

if reaper.set_action_options then reaper.set_action_options(3) end
reaper.defer(function() end)

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")

if transport.currentTab() == "RECORD" then
  transport.vscTab()
else
  transport.recordTab()
end
