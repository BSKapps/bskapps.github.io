-- @description BSK View: FX CHAIN (open the FX chains of the selected tracks; if one of theirs is already open, close every FX chain window)
-- @author BSK
-- @version 1.1
-- @about Opens the FX chain of each selected track that has plugins (the master too when selected), even while other chains are open; one selected track always opens, so a plugin can be added. When a selected track's chain is already open, or there is nothing to open (nothing selected, or several selected and none has plugins), closes every track and master FX chain window instead. Lit while any FX chain window is open; closing them with their own close buttons turns it off.

if reaper.set_action_options then reaper.set_action_options(3) end
reaper.defer(function() end)

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")

transport.toggleFxChains()
