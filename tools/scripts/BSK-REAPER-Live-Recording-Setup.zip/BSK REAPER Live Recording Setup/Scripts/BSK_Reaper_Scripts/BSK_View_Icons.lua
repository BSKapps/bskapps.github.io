-- @description BSK View: ICON (hide every track icon, or put them back)
-- @author BSK
-- @version 1.1
-- @about Pressed while any track shows an icon, it remembers every track's icon in the project and clears them all, so the track panel drops its icon column and the controls get that space. Pressed again, it puts each remembered icon back. Lit while any track shows an icon.

if reaper.set_action_options then reaper.set_action_options(3) end
reaper.defer(function() end)

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")

transport.toggleIcons()
