-- @description BSK View: DOCK MIXER (unlit: dock and show the mixer; lit: undock it)
-- @author BSK
-- @version 1.1
-- @about Unlit: docks the mixer and shows it in the dock. Lit with the mixer showing: pops it out as a floating window. Lit with the mixer hidden: undocks it quietly and it stays hidden (it floats the next time it is shown). Lit while the mixer is set to docked.

if reaper.set_action_options then reaper.set_action_options(3) end
reaper.defer(function() end)

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")

transport.toggleDock()
