-- @description BSK Transport: SELECT ALL ITEMS (lit while every item is selected; press to select all, or unselect all when lit)
-- @author BSK
-- @version 1.0
-- @about Unlit: selects every item. Lit: unselects every item. The light follows the selection, however it was made.

if reaper.set_action_options then reaper.set_action_options(3) end
reaper.defer(function() end)

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")

transport.selectAllItems()
