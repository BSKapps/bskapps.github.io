-- @description BSK Transport: STOP AUDITION RESET (stop, loop off, unsolo all, clear the time selection, unselect all items, stop Preview Item)
-- @author BSK
-- @version 1.0
-- @about Stops playback, turns loop off, unsolos every track, clears the time selection, unselects every item and stops Preview Item if it is playing. The audition buttons go dark.

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")

transport.auditionReset()
