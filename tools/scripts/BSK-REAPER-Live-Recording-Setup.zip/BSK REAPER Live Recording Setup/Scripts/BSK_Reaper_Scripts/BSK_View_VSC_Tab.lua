-- @description BSK View: VSC tab (shows the VSC toolbar; hides docked meters, leaves floating ones)
-- @author BSK
-- @version 1.1
-- @about Shows the VSC toolbar. If the mixer is docked in the main window it is hidden, so the tracks get the room; a mixer floating on another screen stays exactly where it is. The RECORD tab opens the meters again. Lit while VSC was the last tab pressed.

if reaper.set_action_options then reaper.set_action_options(3) end
reaper.defer(function() end)

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")

transport.vscTab()
