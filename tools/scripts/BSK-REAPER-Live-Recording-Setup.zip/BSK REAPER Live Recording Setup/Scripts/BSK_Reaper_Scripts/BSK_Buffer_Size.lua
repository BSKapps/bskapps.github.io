-- @description BSK: BUFFER (pick the audio block size from a menu)
-- @author BSK
-- @version 1.4
-- @about Opens a menu at the mouse with block sizes 16 to 4096 and Custom..., the current size ticked. Picking a size turns on "Request block size", sets it and restarts audio, so audio drops out for a moment. Refuses while any project is recording.

if reaper.set_action_options then reaper.set_action_options(3) end
reaper.defer(function() end)

local TITLE = "Buffer"

local function anyRecording()
  local i = 0
  while true do
    local proj = reaper.EnumProjects(i)
    if not proj then return false end
    if reaper.GetPlayStateEx(proj) & 4 == 4 then return true end
    i = i + 1
  end
end

local function refuseWhileRecording()
  if anyRecording() then
    reaper.ShowMessageBox("Failed to change the buffer: REAPER is recording.\n\nStop first, then change it.", TITLE, 0)
    return true
  end
  return false
end

local nativeSet = reaper.set_config_var_string
local setConfig = nativeSet and function(name, value)
  nativeSet(name, value, 3)
  local ok, now = reaper.get_config_var_string(name)
  return ok and now == value
end or reaper.SNM_SetStringConfigVar

local function hasSetting()
  if not reaper.get_config_var_string then return false end
  local okSize = reaper.get_config_var_string("coreaudiobs")
  local okUse = reaper.get_config_var_string("coreaudiobsuse")
  return okSize and okUse
end

if refuseWhileRecording() then return end

if setConfig == nil then
  reaper.ShowMessageBox("Failed to change the buffer: the SWS extension is not installed.", TITLE, 0)
  return
end

if not hasSetting() then
  reaper.ShowMessageBox("Failed to change the buffer: this REAPER has no block size setting.", TITLE, 0)
  return
end

local known, currentText = reaper.GetAudioDeviceInfo("BSIZE")
local current = known and tonumber(currentText) or nil

local menu = "#Block size|"
local sizes = {}
local currentAdded = false
local size = 8
for _ = 0, 8 do
  size = size * 2
  if current and not currentAdded and current < size then
    menu = menu .. "!" .. tostring(current) .. "|"
    sizes[#sizes + 1] = current
    currentAdded = true
  end
  if size ~= current then
    menu = menu .. tostring(size) .. "|"
    sizes[#sizes + 1] = size
  end
end
if current and not currentAdded then
  menu = menu .. "!" .. tostring(current) .. "|"
  sizes[#sizes + 1] = current
end
menu = menu .. "|Custom..."
sizes[#sizes + 1] = -1

local selection = gfx.showmenu(menu)
if selection == 0 then return end
local pick = sizes[selection - 1]
if pick == nil then return end

if pick == -1 then
  local ok, text = reaper.GetUserInputs(TITLE, 1, "Block size", current and tostring(current) or "")
  if not ok then return end
  pick = tonumber(text)
  if not pick or pick ~= math.floor(pick) or pick < 16 or pick > 4096 then
    reaper.ShowMessageBox("Failed to change the buffer: enter a whole number from 16 to 4096.", TITLE, 0)
    return
  end
  pick = math.floor(pick)
end

if pick == current then return end
if refuseWhileRecording() then return end

local _, oldSize = reaper.get_config_var_string("coreaudiobs")
local _, oldUse = reaper.get_config_var_string("coreaudiobsuse")
local failed = setConfig("coreaudiobs", tostring(pick)) == false
if not failed and setConfig("coreaudiobsuse", "1") == false then
  setConfig("coreaudiobs", oldSize)
  setConfig("coreaudiobsuse", oldUse)
  failed = true
end
if failed then
  reaper.ShowMessageBox("Failed to change the buffer: REAPER did not take the new block size.", TITLE, 0)
  return
end
reaper.Main_OnCommand(1016, 0)
reaper.Audio_Quit()
reaper.Audio_Init()
