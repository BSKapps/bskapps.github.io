-- @description BSK View: SETUP tab (hides docked meters, shows the SETUP toolbar)
-- @author BSK
-- @version 1.2
-- @about Hides the meters if they are docked (a floating meter bridge stays where it is), then shows the SETUP toolbar (REAPER's Main toolbar). Lit while SETUP was the last tab pressed.

if reaper.set_action_options then reaper.set_action_options(3) end
reaper.defer(function() end)

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")

transport.setupTab()
