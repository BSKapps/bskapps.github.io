-- @description BSK Transport: VSC UNITY (lit while what goes back to the console is as it went in: hardware outputs, items and takes at 0 dB and centre, and the patch, mutes, solos, polarity, monitoring, master sends and playrate as they were when recording stopped; press while dark to see what changed and put it back or keep it)
-- @author BSK
-- @version 1.1
-- @about Checks every track that has a hardware output: the output's level and pan, the volume and pan of every item and take on it, and the fader and pan when an output follows the fader (OUTS FOLLOW FADERS). Once a project has recordings it also remembers how it went in, taken each time recording stops: which output each track goes to, output mutes, track mute, solo, polarity, record monitoring and master send, and the project playrate (a stop while MIX DOWN is on keeps the setup from before). An output switched to or from after the plugins on a track with a plugin playing also counts as a change. Lit: pressing does nothing. Dark: a window lists what changed. Put Back as Recorded puts the remembered setup back, Keep Changes keeps the new setup as the one to check against, and both put levels back to 0 dB and centre (take polarity is kept). Put Back to 0 dB shows when only levels are off. Always lit in a project whose file name contains PLUGIN HOST. AUTO PATCH, AUTO ROUTE and Teardown start the memory fresh. Does nothing while recording. While MIX DOWN is on there is no Keep Changes, so a mixdown never becomes the setup to check against; Put Back as Recorded turns MIX DOWN off exactly like its own button (meters included), then puts back the rest. One undo.

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")

if reaper.GetPlayState() & 4 == 4 then return end

local report = transport.unityReport()
if #report.lines == 0 then
  transport.unityLitPress()
  return
end

local TITLE = "VSC Unity"
local W, PAD, ROWS_Y, ROW_H, NOTE_H, BTN_H = 480, 12, 38, 22, 18, 28
local ACCENT = "#2FA39A"
local project, projectFile = reaper.EnumProjects(-1)

local lines = {}
for i = 1, math.min(#report.lines, transport.UNITY_LIST_MAX) do lines[i] = report.lines[i] end
if #report.lines > #lines then lines[#lines + 1] = "...and " .. (#report.lines - #lines) .. " more" end

local buttons, note
local mixDownOn = transport.mixDownOn()
if mixDownOn and report.restorable then
  buttons = { { label = "Put Back as Recorded", choice = "put_back" }, { label = "Cancel" } }
  note = "MIX DOWN is on: Put Back as Recorded also turns it off."
elseif mixDownOn and report.changed then
  buttons = { { label = "OK" } }
  note = "MIX DOWN is on: press MIX DOWN to turn it off."
elseif report.restorable then
  buttons = { { label = "Put Back as Recorded", choice = "put_back" }, { label = "Keep Changes", choice = "keep" }, { label = "Cancel" } }
  note = "Keep Changes makes this setup the new 'as recorded'. Both buttons put the levels listed back to 0 dB and centre."
elseif report.changed then
  buttons = { { label = "Keep Changes", choice = "keep" }, { label = "Cancel" } }
  note = "Keep Changes makes this setup the new 'as recorded' and puts levels back to 0 dB and centre."
else
  buttons = { { label = "Put Back to 0 dB", choice = "levels" }, { label = "Cancel" } }
  note = "Puts these outputs, faders, items and takes back to 0 dB and centre."
end

local height = ROWS_Y + #lines * ROW_H + 6 + NOTE_H + 12 + BTN_H + 12
local scale, hits, wasDown, pressedKey = 1, {}, false, nil

local function setColor(hex, alpha)
  local r, g, b = hex:match("^#(%x%x)(%x%x)(%x%x)$")
  gfx.set(tonumber(r, 16) / 255, tonumber(g, 16) / 255, tonumber(b, 16) / 255, alpha or 1)
end

local function fillRound(x, y, w, h, r)
  x, y, w, h, r = x * scale, y * scale, w * scale, h * scale, r * scale
  gfx.rect(x + r, y, w - 2 * r, h, 1)
  gfx.rect(x, y + r, w, h - 2 * r, 1)
  gfx.circle(x + r, y + r, r, 1, 1)
  gfx.circle(x + w - r - 1, y + r, r, 1, 1)
  gfx.circle(x + r, y + h - r - 1, r, 1, 1)
  gfx.circle(x + w - r - 1, y + h - r - 1, r, 1, 1)
end

local function frameRound(x, y, w, h, r)
  gfx.roundrect(x * scale, y * scale, w * scale, h * scale, r * scale, 1)
end

local function fitText(text, width)
  if gfx.measurestr(text) <= width then return text end
  while #text > 0 and gfx.measurestr(text .. "...") > width do text = text:sub(1, -2) end
  return text .. "..."
end

local function drawText(text, x, y, w, h, flags)
  gfx.x, gfx.y = x * scale, y * scale
  gfx.drawstr(fitText(text, w * scale), flags, (x + w) * scale, (y + h) * scale)
end

local function addHit(key, x, y, w, h, action)
  hits[#hits + 1] = { key = key, x = x, y = y, w = w, h = h, action = action }
end

local function setFont(size)
  gfx.setfont(1, "Arial", size * scale)
end

local function button(key, label, x, y, w, h, primary, action)
  setColor(primary and ACCENT or "#444444")
  fillRound(x, y, w, h, 4)
  if not primary then
    setColor("#666666")
    frameRound(x, y, w, h, 4)
  end
  setColor(primary and "#FFFFFF" or "#DDDDDD")
  drawText(label, x, y, w, h, 5)
  addHit(key, x, y, w, h, action)
end

local function choose(chosen)
  local nowProject, nowFile = reaper.EnumProjects(-1)
  if chosen.choice and nowProject == project and nowFile == projectFile then transport.unityApply(chosen.choice) end
  return true
end

local function draw()
  scale = (gfx.ext_retina and gfx.ext_retina > 0) and gfx.ext_retina or 1
  hits = {}
  setColor("#2B2B2B")
  gfx.rect(0, 0, gfx.w, gfx.h, 1)

  setFont(14)
  setColor("#EEEEEE")
  drawText("These tracks will not play back the way they were recorded:", PAD, 12, W - 2 * PAD, 18, 4)

  setFont(13)
  setColor("#DDDDDD")
  for i, line in ipairs(lines) do
    drawText(line, PAD, ROWS_Y + (i - 1) * ROW_H, W - 2 * PAD, ROW_H, 4)
  end

  local y = ROWS_Y + #lines * ROW_H + 6
  setFont(12)
  setColor("#999999")
  drawText(note, PAD, y, W - 2 * PAD, NOTE_H, 4)

  y = y + NOTE_H + 12
  setFont(13)
  local buttonW = (W - 2 * PAD - (#buttons - 1) * 8) / #buttons
  for i, b in ipairs(buttons) do
    button(i, b.label, PAD + (i - 1) * (buttonW + 8), y, buttonW, BTN_H, i == 1, function() return choose(b) end)
  end
end

local function hitAt(x, y)
  for i = #hits, 1, -1 do
    local hit = hits[i]
    if x >= hit.x and x < hit.x + hit.w and y >= hit.y and y < hit.y + hit.h then return hit end
  end
  return nil
end

local function loop()
  local char = gfx.getchar()
  if char < 0 or char == 27 then
    gfx.quit()
    return
  end
  if char == 13 then
    choose(buttons[1])
    gfx.quit()
    return
  end

  draw()

  local x, y = gfx.mouse_x / scale, gfx.mouse_y / scale
  local down = (gfx.mouse_cap & 1) == 1
  if down and not wasDown then
    local hit = hitAt(x, y)
    pressedKey = hit and hit.key
  elseif wasDown and not down then
    local hit = hitAt(x, y)
    local key = pressedKey
    pressedKey = nil
    if hit and key and hit.key == key and hit.action() then
      gfx.quit()
      return
    end
  end
  wasDown = down

  gfx.update()
  reaper.defer(loop)
end

if reaper.set_action_options then reaper.set_action_options(3) end

local mouseX, mouseY = reaper.GetMousePosition()
gfx.ext_retina = 1
gfx.init(TITLE, W, height, 0, mouseX - W / 2, mouseY - height / 2)
reaper.defer(loop)
