-- @description BSK View: REC TIME LEFT (show or hide the REC TIME LEFT window)
-- @author BSK
-- @version 1.1
-- @about Lit while the REC TIME LEFT window is open. Pressed lit: hides it and keeps it hidden, so the RECORD tab stops reopening it. Pressed dark: shows it again.

if reaper.set_action_options then reaper.set_action_options(3) end
reaper.defer(function() end)

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")

transport.toggleTimeLeft()
