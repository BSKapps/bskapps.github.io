-- @description BSK Transport: NEW TAKE {MIDI SCENE} (for desk scenes: NEW TAKE while recording, with MIDI SCENE on)
-- @author BSK
-- @version 1.0
-- @about For the desk's scene recalls through Companion (the SCENE REC {MIDI SCENE} custom action runs this). While recording with MIDI SCENE lit: does exactly what NEW TAKE does (save, keep recording from here, marker). Otherwise does nothing. The TAKE button and Stream Deck keys are unchanged.

if reaper.set_action_options then reaper.set_action_options(3) end
reaper.defer(function() end)

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")

if not transport.midiSceneOn() then return end

dofile(dir .. "BSK_Transport_New_Take.lua")
