-- @description BSK Transport: RETURN KEY (play/stop; never stops a recording)
-- @author BSK
-- @version 1.1
-- @about For the Return key. Stopped: plays. Playing or paused: stops. Recording: does nothing, so a stray Return never ends a take; SAVE REC and DELETE REC stop a recording.

if reaper.set_action_options then reaper.set_action_options(3) end
reaper.defer(function() end)

if reaper.GetPlayState() & 4 == 4 then return end
reaper.Main_OnCommand(40044, 0)
