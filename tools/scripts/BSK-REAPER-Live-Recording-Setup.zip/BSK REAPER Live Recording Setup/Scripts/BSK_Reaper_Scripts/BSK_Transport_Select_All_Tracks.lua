-- @description BSK Transport: SELECT ALL TRACKS (lit while every track is selected; press to select all, or unselect all when lit)
-- @author BSK
-- @version 1.0
-- @about Unlit: selects every track. Lit: unselects every track. The light follows the selection, however it was made.

if reaper.set_action_options then reaper.set_action_options(3) end
reaper.defer(function() end)

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")

transport.selectAllTracks()
