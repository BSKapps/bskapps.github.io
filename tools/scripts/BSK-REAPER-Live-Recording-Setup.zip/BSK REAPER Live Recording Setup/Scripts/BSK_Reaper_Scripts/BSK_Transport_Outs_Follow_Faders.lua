-- @description BSK Transport: OUTS FOLLOW FADERS (lit while every track's hardware outputs are post-fader, slow blink while only some are; press to switch all, asks first)
-- @author BSK
-- @version 1.1
-- @about Every track, no selection needed. Unlit or blinking: switches every hardware output to post-fader, so faders, pan and plugins change what goes out, and switches the meters to post-fader to match. Lit: puts every hardware output back to the mode it had before it followed the faders (pre-FX in a live recording); outputs with nothing remembered, like the plugin host's, go pre-fader after the plugins, so plugins stay in, and the meters go back to how they were unless MIX DOWN is on. The meters are one REAPER-wide setting, and an undo does not change them. Asks first (OK/Cancel). Does nothing while recording. One undo.

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")

transport.outsFollowFaders()
