-- @description BSK View: DEFAULT MIXER (lit while the standard mixer is showing)
-- @author BSK
-- @version 1.1
-- @about Shows the DEFAULT MIXER view (loads its window set and makes sure the mixer is showing). Pressed again while it is showing, it hides the mixer. This button is lit while the mixer is open with this layout showing.

if reaper.set_action_options then reaper.set_action_options(3) end
reaper.defer(function() end)

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")

transport.showMixer(1)
