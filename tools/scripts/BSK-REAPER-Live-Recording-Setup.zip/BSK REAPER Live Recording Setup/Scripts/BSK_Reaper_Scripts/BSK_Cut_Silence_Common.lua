-- @description BSK: CUT SILENCE shared logic (not an action)
-- @author BSK
-- @version 1.1
-- @about Used by BSK_Cut_Silence.lua. Settings, listening for silence from the peak files, the red CUT SILENCE regions and the cut itself.

local M = {}

M.SECTION = "BSK_CUT_SILENCE"
M.REGION_NAME = "CUT SILENCE"
M.PEAK_RATE = 20
M.BLOCK_SECONDS = 300
M.FADE = 0.01
M.MIN_KEEP = 2
M.MIN_DB = -90
M.MAX_DB = -30
M.DEFAULT_DB = -45
M.DEFAULT_LENGTH = 30
M.DEFAULT_KEEP = 2
M.UNITY_DB = 0.05
M.EPS = 0.000001
M.SPOT_SECONDS = 0.1
M.PEAK_STALL = 10
M.UNDO_MARK = 8
M.UNDO_CUT = 4 | 8

function M.failure(action, reason, fix)
  return "Failed to " .. action .. ": " .. reason .. (fix and ("\n\n" .. fix) or "")
end

local function formatNumber(value)
  if value == math.floor(value) and math.abs(value) < 1e15 then return string.format("%d", value) end
  return string.format("%g", value)
end
M.formatNumber = formatNumber

function M.checkSettings(db, length, keep)
  if type(db) ~= "number" or db ~= db or db < M.MIN_DB or db > M.MAX_DB then
    return "Failed to change settings: enter Silent below (dB) as a number from -90 to -30."
  end
  if type(keep) ~= "number" or keep ~= keep or keep < M.MIN_KEEP or keep == math.huge then
    return "Failed to change settings: Keep each side (seconds) must be 2 or more."
  end
  if type(length) ~= "number" or length ~= length or length == math.huge then
    return "Failed to change settings: enter Silent for at least (seconds) as a number."
  end
  if length <= 2 * keep then
    return "Failed to change settings: Silent for at least (seconds) must be more than twice Keep each side (seconds)."
  end
  return nil
end

local function stored(key, default)
  local value = tonumber(reaper.GetExtState(M.SECTION, key))
  if value == nil then return default end
  return value
end

function M.settings()
  local db, length, keep = stored("db", M.DEFAULT_DB), stored("length", M.DEFAULT_LENGTH), stored("keep", M.DEFAULT_KEEP)
  if M.checkSettings(db, length, keep) then
    db, length, keep = M.DEFAULT_DB, M.DEFAULT_LENGTH, M.DEFAULT_KEEP
  end
  return { db = db, length = length, keep = keep }
end

function M.saveSettings(settings)
  reaper.SetExtState(M.SECTION, "db", formatNumber(settings.db), true)
  reaper.SetExtState(M.SECTION, "length", formatNumber(settings.length), true)
  reaper.SetExtState(M.SECTION, "keep", formatNumber(settings.keep), true)
end

function M.settingsText(settings)
  return formatNumber(settings.db) .. "|" .. formatNumber(settings.length) .. "|" .. formatNumber(settings.keep)
end

function M.parseSettings(text)
  local fields = {}
  for field in ((text or "") .. "|"):gmatch("([^|]*)|") do fields[#fields + 1] = field end
  if #fields ~= 3 then return nil, "Failed to change settings: fill in all three boxes." end
  local values = {}
  for i = 1, 3 do values[i] = tonumber((fields[i]:gsub("^%s+", ""):gsub("%s+$", ""))) end
  local problem = M.checkSettings(values[1], values[2], values[3])
  if problem then return nil, problem end
  return { db = values[1], length = values[2], keep = values[3] }
end

function M.isPluginHost(file)
  return ((file or ""):match("[^/\\]*$") or ""):upper():find("PLUGIN HOST", 1, true) ~= nil
end

function M.anyRecording()
  local i = 0
  while true do
    local proj = reaper.EnumProjects(i)
    if not proj then return false end
    if reaper.GetPlayStateEx(proj) & 4 == 4 then return true end
    i = i + 1
  end
end

function M.blocked(proj, file)
  if M.anyRecording() then return "REAPER is recording.", "Stop first, then try again." end
  local state = reaper.GetPlayStateEx(proj)
  if state & 2 == 2 then return "REAPER is paused.", "Stop first, then try again." end
  if state & 1 == 1 then return "REAPER is playing.", "Stop first, then try again." end
  if M.isPluginHost(file) then
    return "this project's file name contains PLUGIN HOST.", "Remove Silent Gaps does nothing in a plugin host project."
  end
  return nil
end

function M.sameProject(proj, file)
  local now, nowFile = reaper.EnumProjects(-1)
  return now == proj and (nowFile or "") == (file or "")
end

function M.trackLabel(track)
  local number = math.floor(reaper.GetMediaTrackInfo_Value(track, "IP_TRACKNUMBER") + 0.5)
  if number < 1 then return "the master track" end
  local _, name = reaper.GetTrackName(track)
  name = (name or ""):match("^%s*(.-)%s*$")
  if name == "" or name:lower() == "track " .. number then return "track " .. number end
  return "track " .. number .. " (" .. name .. ")"
end

function M.listenedTracks(proj)
  local tracks = {}
  local selected = reaper.CountSelectedTracks2(proj, false)
  if selected > 0 then
    for i = 0, selected - 1 do tracks[#tracks + 1] = reaper.GetSelectedTrack2(proj, i, false) end
  else
    for i = 0, reaper.CountTracks(proj) - 1 do tracks[#tracks + 1] = reaper.GetTrack(proj, i) end
  end
  return tracks, selected > 0
end

function M.projectEnd(proj)
  local last = 0
  for i = 0, reaper.CountMediaItems(proj) - 1 do
    local item = reaper.GetMediaItem(proj, i)
    local finish = reaper.GetMediaItemInfo_Value(item, "D_POSITION") + reaper.GetMediaItemInfo_Value(item, "D_LENGTH")
    if finish > last then last = finish end
  end
  return last
end

local function isReversed(take)
  local ok, _, _, reversed = reaper.PCM_Source_GetSectionInfo(reaper.GetMediaItemTake_Source(take))
  return ok and reversed
end

local function changedSpeed(take)
  return math.abs(reaper.GetMediaItemTakeInfo_Value(take, "D_PLAYRATE") - 1) > M.EPS
    or reaper.GetTakeNumStretchMarkers(take) > 0 or isReversed(take)
end

local SPEED_REASON = " is sped up, slowed down, stretched or reversed."
M.SPEED_REASON = SPEED_REASON
local SPEED_FIX = "Put it back to normal, then try again."

local function sortRuns(runs)
  table.sort(runs, function(x, y) return x[1] < y[1] end)
  return runs
end

function M.subtract(runs, loud)
  sortRuns(loud)
  local out = {}
  local j = 1
  for _, run in ipairs(runs) do
    local start = run[1]
    while j <= #loud and loud[j][2] <= run[1] do j = j + 1 end
    local k = j
    while k <= #loud and loud[k][1] < run[2] do
      if loud[k][1] > start then out[#out + 1] = { start, loud[k][1] } end
      if loud[k][2] > start then start = loud[k][2] end
      k = k + 1
    end
    if start < run[2] then out[#out + 1] = { start, run[2] } end
  end
  return out
end

function M.longEnough(runs, length)
  local out = {}
  for _, run in ipairs(runs) do
    if run[2] - run[1] >= length - M.EPS then out[#out + 1] = run end
  end
  return out
end

function M.cutsFromRuns(runs, keep, rangeEnd)
  local cuts, allSilent = {}, false
  for _, run in ipairs(runs) do
    local atStart = run[1] <= M.EPS
    local atEnd = run[2] >= rangeEnd - M.EPS
    if atStart and atEnd then
      allSilent = true
    else
      local a = atStart and 0 or run[1] + keep
      local b = atEnd and rangeEnd or run[2] - keep
      if b - a > M.EPS then cuts[#cuts + 1] = { a, b } end
    end
  end
  return cuts, allSilent
end

local buffers = {}
local function peakBuffer(channels)
  local buf = buffers[channels]
  if not buf then
    buf = reaper.new_array(channels * math.ceil(M.BLOCK_SECONDS * M.PEAK_RATE + 1) * 2)
    buffers[channels] = buf
  end
  return buf
end

local OUTSIDE = {}

-- REAPER returns nil for peak and audio accessor reads made inside a coroutine, so the scan hands them to stepScan.
function M.outside(fn, ...)
  return coroutine.yield(OUTSIDE, fn, table.pack(...))
end

function M.resume(co)
  local step = table.pack(coroutine.resume(co))
  while step[1] and step[2] == OUTSIDE do
    local args = step[4]
    local call = table.pack(pcall(step[3], table.unpack(args, 1, args.n)))
    if not call[1] then return false, call[2] end
    step = table.pack(coroutine.resume(co, table.unpack(call, 2, call.n)))
  end
  return step[1], step[2]
end

-- REAPER leaves out the last part-slice when a read runs past the end of the file.
function M.usableSlices(got, count, last)
  local n = got & 0xFFFFF
  if n == count or (last and n == count - 1 and n > 0) then return n end
end

local function readPeaks(take, at, channels, count)
  local buf = peakBuffer(channels)
  buf.clear()
  local got = reaper.GetMediaItemTake_Peaks(take, M.PEAK_RATE, at, channels, count, 0, buf)
  local size = channels * count
  return got, buf.table(1, size), buf.table(size + 1, size)
end

local function spotCheckSilent(take, itemStart, ranges, threshold)
  local accessor = reaper.CreateTakeAudioAccessor(take)
  if not accessor then return false end
  local source = reaper.GetMediaItemTake_Source(take)
  local rate = math.floor(reaper.GetMediaSourceSampleRate(source) + 0.5)
  if rate <= 0 then rate = 48000 end
  local channels = math.max(1, reaper.GetMediaSourceNumChannels(source))
  local frames = math.max(1, math.floor(rate * M.SPOT_SECONDS))
  local first = reaper.GetAudioAccessorStartTime(accessor)
  local buf = reaper.new_array(frames * channels)
  local points = {}
  for _, range in ipairs(ranges) do
    for _, part in ipairs({ 0.25, 0.5, 0.75 }) do points[#points + 1] = { range, range[1] + (range[2] - range[1]) * part } end
  end
  local picks = { points[1], points[(#points + 1) // 2], points[#points] }
  local silent = true
  for _, pick in ipairs(picks) do
    local range, point = pick[1], pick[2]
    local window = math.min(M.SPOT_SECONDS, range[2] - range[1])
    local start = math.max(range[1], math.min(point - window / 2, range[2] - window))
    local count = math.max(1, math.floor(rate * window))
    buf.clear()
    local at = first + math.max(0, start - itemStart)
    if reaper.GetAudioAccessorSamples(accessor, rate, channels, at, count, buf) < 0 then
      silent = false
      break
    end
    for _, value in ipairs(buf.table(1, count * channels)) do
      if math.abs(value) >= threshold then
        silent = false
        break
      end
    end
    if not silent then break end
  end
  reaper.DestroyAudioAccessor(accessor)
  return silent
end

local function scanBody(scan, tracks, settings, rangeEnd)
  local proj = scan.proj
  local threshold = 10 ^ (settings.db / 20)
  local runs = { { 0, rangeEnd } }

  local function due(track, item, take)
    if reaper.time_precise() < scan.deadline then return end
    coroutine.yield()
    if not reaper.ValidatePtr2(proj, track, "MediaTrack*")
      or (item and not reaper.ValidatePtr2(proj, item, "MediaItem*"))
      or (take and not reaper.ValidatePtr2(proj, take, "MediaItem_Take*")) then
      error({ changed = true })
    end
  end

  local function ensurePeaks(track, item, take)
    local source = reaper.GetMediaItemTake_Source(take)
    if reaper.PCM_Source_BuildPeaks(source, 0) == 0 then return true end
    scan.building = source
    local ok, problem = pcall(function()
      local best, since = math.huge, reaper.time_precise()
      while true do
        local left = reaper.PCM_Source_BuildPeaks(source, 1)
        if left <= 0 then return end
        if left < best then
          best, since = left, reaper.time_precise()
        elseif reaper.time_precise() - since > M.PEAK_STALL then
          error({ unreadable = track })
        end
        local before = reaper.time_precise()
        due(track, item, take)
        since = since + (reaper.time_precise() - before)
      end
    end)
    scan.building = nil
    if reaper.ValidatePtr2(proj, source, "PCM_source*") then reaper.PCM_Source_BuildPeaks(source, 2) end
    if not ok then
      if type(problem) == "table" and problem.unreadable then return false end
      error(problem, 0)
    end
    return true
  end

  local function readLoud(track, item, take, channels, from, to, loud, seen, gain)
    local at = from
    while at < to - M.EPS do
      local blockEnd = math.min(to, at + M.BLOCK_SECONDS)
      local count = math.max(1, math.ceil((blockEnd - at) * M.PEAK_RATE - M.EPS))
      local got, highs, lows = M.outside(readPeaks, take, at, channels, count)
      local slices = M.usableSlices(got, count, blockEnd >= to - M.EPS)
      if not slices then return false end
      local loudFrom
      for k = 0, slices - 1 do
        local level = 0
        for c = 1, channels do
          local high, low = math.abs(highs[k * channels + c]), math.abs(lows[k * channels + c])
          if high > level then level = high end
          if low > level then level = low end
        end
        if level ~= 0 then seen.nonZero = true end
        local sliceStart = at + k / M.PEAK_RATE
        if level * gain >= threshold then
          if not loudFrom then loudFrom = sliceStart end
        elseif loudFrom then
          loud[#loud + 1] = { loudFrom, sliceStart }
          loudFrom = nil
        end
      end
      if loudFrom then loud[#loud + 1] = { loudFrom, at + count / M.PEAK_RATE } end
      at = blockEnd
      due(track, item, take)
    end
    return true
  end

  for index, track in ipairs(tracks) do
    scan.done = index - 1
    if #runs == 0 then break end
    local loud = {}
    for i = 0, reaper.CountTrackMediaItems(track) - 1 do
      local item = reaper.GetTrackMediaItem(track, i)
      local take = reaper.GetActiveTake(item)
      local itemStart = reaper.GetMediaItemInfo_Value(item, "D_POSITION")
      local itemEnd = itemStart + reaper.GetMediaItemInfo_Value(item, "D_LENGTH")
      if take then
        local midi = reaper.TakeIsMIDI(take)
        local channels, gain, unmeasured = 1, 1, false
        if not midi then
          channels = math.max(1, reaper.GetMediaSourceNumChannels(reaper.GetMediaItemTake_Source(take)))
          gain = math.abs(reaper.GetMediaItemInfo_Value(item, "D_VOL")) * math.abs(reaper.GetMediaItemTakeInfo_Value(take, "D_VOL"))
          unmeasured = changedSpeed(take)
        end
        local seen = { nonZero = false }
        local ranges, overlaps = {}, {}
        for _, run in ipairs(runs) do
          local from, to = math.max(run[1], itemStart), math.min(run[2], itemEnd)
          if to - from > M.EPS then
            overlaps[#overlaps + 1] = { from, to }
            if midi or unmeasured then
              loud[#loud + 1] = { from, to }
            elseif gain > 0 then
              if #ranges == 0 and not ensurePeaks(track, item, take) then
                unmeasured = true
              else
                ranges[#ranges + 1] = { from, to }
                if not readLoud(track, item, take, channels, from, to, loud, seen, gain) then unmeasured = true end
              end
            end
          end
        end
        if not unmeasured and #ranges > 0 and not seen.nonZero and not M.outside(spotCheckSilent, take, itemStart, ranges, threshold / gain) then
          unmeasured = true
        end
        if unmeasured and not midi and #overlaps > 0 then
          for _, range in ipairs(overlaps) do loud[#loud + 1] = range end
          scan.unmeasured[#scan.unmeasured + 1] = track
        end
      end
      due(track, item, nil)
    end
    runs = M.longEnough(M.subtract(runs, loud), settings.length)
  end
  scan.done = #tracks
  local cuts, allSilent = M.cutsFromRuns(runs, settings.keep, rangeEnd)
  scan.allSilent = allSilent
  return cuts
end

function M.startScan(proj, tracks, settings, rangeEnd)
  local scan = { proj = proj, total = #tracks, done = 0, deadline = 0, unmeasured = {} }
  scan.change = reaper.GetProjectStateChangeCount(proj)
  scan.co = coroutine.create(function() return scanBody(scan, tracks, settings, rangeEnd) end)
  return scan
end

function M.stopScan(scan)
  if scan and scan.building then
    if reaper.ValidatePtr2(scan.proj, scan.building, "PCM_source*") then reaper.PCM_Source_BuildPeaks(scan.building, 2) end
    scan.building = nil
  end
end

function M.stepScan(scan, budget)
  if reaper.GetProjectStateChangeCount(scan.proj) ~= scan.change then
    M.stopScan(scan)
    return "changed"
  end
  scan.deadline = reaper.time_precise() + budget
  local ok, result = M.resume(scan.co)
  if not ok then
    if type(result) == "table" and result.unreadable then return "unreadable", result.unreadable end
    if type(result) == "table" and result.changed then return "changed" end
    return "error", tostring(result)
  end
  if coroutine.status(scan.co) == "dead" then return "done", result, scan.allSilent, scan.unmeasured end
  return "running"
end

function M.isRedRegion(isrgn, name)
  return isrgn and ((name or ""):match("^%s*(.-)%s*$")):upper() == M.REGION_NAME
end

function M.redRegions(proj)
  local list = {}
  local i = 0
  while true do
    local found, isrgn, pos, rgnend, name, number = reaper.EnumProjectMarkers3(proj, i)
    if found == 0 then break end
    if M.isRedRegion(isrgn, name) then list[#list + 1] = { pos, rgnend, number = number } end
    i = i + 1
  end
  return list
end

function M.mergeCuts(regions, rangeEnd)
  local list = {}
  for _, region in ipairs(regions) do
    local a, b = math.max(0, region[1]), math.min(rangeEnd, region[2])
    if b - a > M.EPS then list[#list + 1] = { a, b } end
  end
  sortRuns(list)
  local merged = {}
  for _, cut in ipairs(list) do
    local last = merged[#merged]
    if last and cut[1] <= last[2] + M.EPS then
      if cut[2] > last[2] then last[2] = cut[2] end
    else
      merged[#merged + 1] = { cut[1], cut[2] }
    end
  end
  return merged
end

local function deleteRedRegions(proj)
  for _, region in ipairs(M.redRegions(proj)) do reaper.DeleteProjectMarker(proj, region.number, true) end
end

function M.regionColor()
  return reaper.ColorToNative(200, 40, 40) | 0x1000000
end

function M.sampleRate(proj)
  if reaper.GetSetProjectInfo(proj, "PROJECT_SRATE_USE", 0, false) == 1 then
    local rate = reaper.GetSetProjectInfo(proj, "PROJECT_SRATE", 0, false)
    if rate > 0 then return rate end
  end
  local ok, text = reaper.GetAudioDeviceInfo("SRATE")
  local rate = ok and tonumber(text) or nil
  if rate and rate > 0 then return rate end
  return nil
end

function M.onSamples(proj, cuts)
  local rate = M.sampleRate(proj)
  if not rate then return cuts end
  local rangeEnd = M.projectEnd(proj)
  local out = {}
  for _, cut in ipairs(cuts) do
    local a = cut[1] <= M.EPS and 0 or math.floor(cut[1] * rate + 0.5) / rate
    local b = cut[2] >= rangeEnd - M.EPS and cut[2] or math.floor(cut[2] * rate + 0.5) / rate
    out[#out + 1] = { a, b }
  end
  return M.mergeCuts(out, rangeEnd)
end

function M.markRegions(proj, cuts)
  cuts = M.onSamples(proj, cuts)
  reaper.Undo_BeginBlock2(proj)
  reaper.PreventUIRefresh(1)
  deleteRedRegions(proj)
  local color = M.regionColor()
  for _, cut in ipairs(cuts) do reaper.AddProjectMarker2(proj, true, cut[1], cut[2], M.REGION_NAME, -1, color) end
  reaper.PreventUIRefresh(-1)
  reaper.Undo_EndBlock2(proj, "Remove Silent Gaps: show silent stretches as red regions", M.UNDO_MARK)
end

function M.removeRegions(proj)
  reaper.Undo_BeginBlock2(proj)
  reaper.PreventUIRefresh(1)
  deleteRedRegions(proj)
  reaper.PreventUIRefresh(-1)
  reaper.Undo_EndBlock2(proj, "Remove Silent Gaps: take back silent regions", M.UNDO_MARK)
end

function M.mapper(cuts)
  local before, total = {}, 0
  for i, cut in ipairs(cuts) do
    before[i] = total
    total = total + (cut[2] - cut[1])
  end
  local function lastStartingBefore(t)
    local lo, hi, found = 1, #cuts, 0
    while lo <= hi do
      local mid = (lo + hi) // 2
      if cuts[mid][1] < t then
        found = mid
        lo = mid + 1
      else
        hi = mid - 1
      end
    end
    return found
  end
  local function map(t)
    local i = lastStartingBefore(t)
    if i == 0 then return t end
    local cut = cuts[i]
    if t < cut[2] then return cut[1] - before[i] end
    return t - before[i] - (cut[2] - cut[1])
  end
  local function inside(t)
    local i = lastStartingBefore(t)
    return i > 0 and t < cuts[i][2]
  end
  return map, inside, total
end

local function overlaps(cuts, from, to)
  local hits = {}
  for _, cut in ipairs(cuts) do
    if cut[1] < to - M.EPS and cut[2] > from + M.EPS then hits[#hits + 1] = cut end
  end
  return hits
end

local function allTracks(proj)
  local tracks = { reaper.GetMasterTrack(proj) }
  for i = 0, reaper.CountTracks(proj) - 1 do tracks[#tracks + 1] = reaper.GetTrack(proj, i) end
  return tracks
end

function M.cutProblem(proj, cuts)
  if #cuts == 0 then return nil end
  for i = 0, reaper.CountTempoTimeSigMarkers(proj) - 1 do
    local _, timepos = reaper.GetTempoTimeSigMarker(proj, i)
    if timepos > M.EPS then
      return "this project has tempo or time signature changes.", "Cut this project by hand."
    end
  end
  local firstCut = cuts[1][1]
  local grouped = 0
  for _, track in ipairs(allTracks(proj)) do
    for i = 0, reaper.CountTrackMediaItems(track) - 1 do
      local item = reaper.GetTrackMediaItem(track, i)
      if reaper.GetMediaItemInfo_Value(item, "I_GROUPID") ~= 0 then grouped = grouped + 1 end
      local from = reaper.GetMediaItemInfo_Value(item, "D_POSITION")
      local to = from + reaper.GetMediaItemInfo_Value(item, "D_LENGTH")
      if #overlaps(cuts, from, to) > 0 then
        if reaper.CountTakes(item) > 1 then
          return "an item on " .. M.trackLabel(track) .. " has more than one take.", "Keep only the take you want, then try again.", item
        end
        local take = reaper.GetActiveTake(item)
        if take then
          if changedSpeed(take) then
            return "an item on " .. M.trackLabel(track) .. SPEED_REASON, SPEED_FIX, item
          end
        end
      end
    end
    for e = 0, reaper.CountTrackEnvelopes(track) - 1 do
      local env = reaper.GetTrackEnvelope(track, e)
      for p = 0, reaper.CountEnvelopePointsEx(env, -1) - 1 do
        local _, time = reaper.GetEnvelopePointEx(env, -1, p)
        if time > firstCut + M.EPS then
          return M.trackLabel(track) .. " has automation after the first red region.", "Remove Silent Gaps does not move automation. Remove it, then try again."
        end
      end
      for a = 0, reaper.CountAutomationItems(env) - 1 do
        local finish = reaper.GetSetAutomationItemInfo(env, a, "D_POSITION", 0, false) + reaper.GetSetAutomationItemInfo(env, a, "D_LENGTH", 0, false)
        if finish > firstCut + M.EPS then
          return M.trackLabel(track) .. " has automation after the first red region.", "Remove Silent Gaps does not move automation. Remove it, then try again."
        end
      end
    end
  end
  if grouped > 0 then
    if grouped == 1 then return "1 item is grouped.", "Ungroup it, then try again." end
    return grouped .. " items are grouped.", "Ungroup them, then try again."
  end
  return nil
end

local FADE_IN_FIELDS = { "C_FADEINSHAPE", "D_FADEINDIR", "D_FADEINDIR_NEW", "D_FADEINDIR2_NEW", "D_FADEINLEN", "D_FADEINLEN_AUTO" }
local FADE_OUT_FIELDS = { "C_FADEOUTSHAPE", "D_FADEOUTDIR", "D_FADEOUTDIR_NEW", "D_FADEOUTDIR2_NEW", "D_FADEOUTLEN", "D_FADEOUTLEN_AUTO" }

local function readFields(item, fields)
  local values = {}
  for i, field in ipairs(fields) do values[i] = reaper.GetMediaItemInfo_Value(item, field) end
  return values
end

local function writeFields(item, fields, values)
  for i, field in ipairs(fields) do reaper.SetMediaItemInfo_Value(item, field, values[i]) end
end

local function cutItem(track, entry, cuts, map, inside)
  local item, from, to = entry.item, entry.pos, entry.pos + entry.len
  local fadeIn, fadeOut = readFields(item, FADE_IN_FIELDS), readFields(item, FADE_OUT_FIELDS)
  local take = reaper.GetActiveTake(item)
  local offset = take and reaper.GetMediaItemTakeInfo_Value(take, "D_STARTOFFS") or 0
  local lock = reaper.GetMediaItemInfo_Value(item, "C_LOCK")
  if lock ~= 0 then reaper.SetMediaItemInfo_Value(item, "C_LOCK", 0) end
  local points = {}
  for _, cut in ipairs(overlaps(cuts, from, to)) do
    for _, p in ipairs({ cut[1], cut[2] }) do
      if p > from + M.EPS and p < to - M.EPS then points[#points + 1] = p end
    end
  end
  table.sort(points)
  local pieces = { item }
  for i = #points, 1, -1 do
    local right = reaper.SplitMediaItem(item, points[i])
    if not right then error("split") end
    table.insert(pieces, 2, right)
  end
  local edges = { from }
  for _, p in ipairs(points) do edges[#edges + 1] = p end
  edges[#edges + 1] = to
  for i, piece in ipairs(pieces) do
    local pieceFrom, pieceTo = edges[i], edges[i + 1]
    if inside((pieceFrom + pieceTo) / 2) then
      if not reaper.DeleteTrackMediaItem(track, piece) then error("delete") end
    else
      local length = pieceTo - pieceFrom
      local pieceTake = reaper.GetActiveTake(piece)
      if pieceTake then reaper.SetMediaItemTakeInfo_Value(pieceTake, "D_STARTOFFS", offset + (pieceFrom - from)) end
      reaper.SetMediaItemInfo_Value(piece, "D_LENGTH", length)
      local fade = math.min(M.FADE, length / 2)
      if pieceFrom == from then
        writeFields(piece, FADE_IN_FIELDS, fadeIn)
      else
        reaper.SetMediaItemInfo_Value(piece, "D_FADEINLEN", fade)
        reaper.SetMediaItemInfo_Value(piece, "D_FADEINLEN_AUTO", 0)
      end
      if pieceTo == to then
        writeFields(piece, FADE_OUT_FIELDS, fadeOut)
      else
        reaper.SetMediaItemInfo_Value(piece, "D_FADEOUTLEN", fade)
        reaper.SetMediaItemInfo_Value(piece, "D_FADEOUTLEN_AUTO", 0)
      end
      reaper.SetMediaItemInfo_Value(piece, "D_POSITION", map(pieceFrom))
      if lock ~= 0 then reaper.SetMediaItemInfo_Value(piece, "C_LOCK", lock) end
    end
  end
end

local function trackLength(track)
  local total = 0
  for i = 0, reaper.CountTrackMediaItems(track) - 1 do
    total = total + reaper.GetMediaItemInfo_Value(reaper.GetTrackMediaItem(track, i), "D_LENGTH")
  end
  return total
end

local function moveMarkers(proj, map)
  local list = {}
  local i = 0
  while true do
    local found, isrgn, pos, rgnend, name, number, color = reaper.EnumProjectMarkers3(proj, i)
    if found == 0 then break end
    list[#list + 1] = { index = i, isrgn = isrgn, pos = pos, rgnend = rgnend, name = name, number = number, color = color }
    i = i + 1
  end
  local deleteRegions, newMarkers = {}, {}
  for _, m in ipairs(list) do
    if M.isRedRegion(m.isrgn, m.name) then
      deleteRegions[#deleteRegions + 1] = m.number
    elseif m.isrgn then
      local newPos, newEnd = map(m.pos), map(m.rgnend)
      if newEnd - newPos <= M.EPS and m.rgnend - m.pos > M.EPS then
        deleteRegions[#deleteRegions + 1] = m.number
        newMarkers[#newMarkers + 1] = { pos = newPos, name = m.name, color = m.color }
      elseif newPos ~= m.pos or newEnd ~= m.rgnend then
        if not reaper.SetProjectMarkerByIndex2(proj, m.index, true, newPos, newEnd, -1, m.name, m.color, 2) then error("region") end
      end
    else
      local newPos = map(m.pos)
      if newPos ~= m.pos then
        if not reaper.SetProjectMarkerByIndex2(proj, m.index, false, newPos, 0, -1, m.name, m.color, 2) then error("marker") end
      end
    end
  end
  reaper.SetProjectMarkerByIndex2(proj, -1, false, 0, 0, -1, "", 0, 2)
  for _, number in ipairs(deleteRegions) do
    if not reaper.DeleteProjectMarker(proj, number, true) then error("region") end
  end
  for _, marker in ipairs(newMarkers) do
    if reaper.AddProjectMarker2(proj, false, marker.pos, 0, marker.name, -1, marker.color) < 0 then error("marker") end
  end
end

local function applyCut(proj, cuts)
  local map, inside = M.mapper(cuts)
  for _, track in ipairs(allTracks(proj)) do
    local entries, expected = {}, 0
    for i = 0, reaper.CountTrackMediaItems(track) - 1 do
      local item = reaper.GetTrackMediaItem(track, i)
      local pos = reaper.GetMediaItemInfo_Value(item, "D_POSITION")
      local len = reaper.GetMediaItemInfo_Value(item, "D_LENGTH")
      entries[#entries + 1] = { item = item, pos = pos, len = len }
      expected = expected + len
      for _, cut in ipairs(overlaps(cuts, pos, pos + len)) do
        expected = expected - (math.min(cut[2], pos + len) - math.max(cut[1], pos))
      end
    end
    table.sort(entries, function(x, y) return x.pos < y.pos end)
    for _, entry in ipairs(entries) do
      if #overlaps(cuts, entry.pos, entry.pos + entry.len) > 0 then
        cutItem(track, entry, cuts, map, inside)
      else
        local newPos = map(entry.pos)
        if newPos ~= entry.pos then reaper.SetMediaItemInfo_Value(entry.item, "D_POSITION", newPos) end
      end
    end
    if math.abs(trackLength(track) - expected) > 0.001 then error("check") end
  end
  moveMarkers(proj, map)
end

function M.cut(proj, cuts)
  cuts = M.onSamples(proj, cuts)
  reaper.Undo_BeginBlock2(proj)
  reaper.PreventUIRefresh(1)
  local ok, problem = pcall(applyCut, proj, cuts)
  reaper.PreventUIRefresh(-1)
  reaper.UpdateArrange()
  if ok then
    reaper.Undo_EndBlock2(proj, "Remove Silent Gaps: cut " .. M.stretches(#cuts), M.UNDO_CUT)
    return nil
  end
  reaper.Undo_EndBlock2(proj, "Remove Silent Gaps: cut stopped part way", M.UNDO_CUT)
  return tostring(problem)
end

function M.stretches(count)
  if count == 1 then return "1 silent stretch" end
  return count .. " silent stretches"
end

function M.clock(seconds)
  local t = math.floor(seconds + 0.5)
  return string.format("%d:%02d:%02d", t // 3600, (t % 3600) // 60, t % 60)
end

function M.duration(seconds)
  local t = math.floor(seconds + 0.5)
  if t < 60 then return t .. " s" end
  if t < 3600 then return (t // 60) .. " min " .. (t % 60) .. " s" end
  return (t // 3600) .. " h " .. ((t % 3600) // 60) .. " min " .. (t % 60) .. " s"
end

function M.rows(cuts)
  local rows, total = {}, 0
  for i, cut in ipairs(cuts) do
    local from, to = math.floor(cut[1] + 0.5), math.floor(cut[2] + 0.5)
    rows[i] = { i .. ".", M.clock(from) .. "  to  " .. M.clock(to), M.duration(to - from) }
    total = total + (to - from)
  end
  return rows, total
end

return M
