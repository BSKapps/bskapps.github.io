-- @description BSK Transport: SAFE REC {MIDI SCENE} (for a desk scene: starts SAFE REC only when stopped on the RECORD tab, with MIDI SCENE on)
-- @author BSK
-- @version 1.0
-- @about For a desk scene to fire through Companion. Stopped with the RECORD toolbar showing: does exactly what SAFE REC does (arm all, monitor off, record from the end, marker, SAFE REC lights). On any other toolbar (VSC PLAYBACK while tweaking scenes before doors), or while playing, paused or recording: does nothing, so recalling a scene outside the show never starts a recording. Does nothing while MIDI SCENE is dark, and never in a project whose file name contains PLUGIN HOST. The SAFE REC button and the Stream Deck REC key are unchanged.

if reaper.set_action_options then reaper.set_action_options(3) end
reaper.defer(function() end)

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")

if not transport.midiSceneOn() then return end
if transport.isPluginHost() then return end
if reaper.GetPlayState() ~= 0 then return end
if transport.currentTab() ~= "RECORD" then return end

dofile(dir .. "BSK_Transport_Safe_Rec.lua")
