-- @description BSK Transport: MUTE ALL (lit while every track is muted, slow blink while only some are; press to mute all, or unmute all when lit)
-- @author BSK
-- @version 1.0
-- @about Unlit or blinking: mutes every track. Lit: unmutes every track. Steady only when every track is muted; a slow blink means some tracks are muted.

if reaper.set_action_options then reaper.set_action_options(3) end
reaper.defer(function() end)

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")

transport.muteAll()
