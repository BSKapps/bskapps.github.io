-- @description BSK Time Left: shared logic for the TIME LEFT window and SAFE REC's low-space stop (not an action)
-- @author BSK
-- @version 1.2
-- @about Works out how long recording can continue on the primary and secondary record paths at the tracks armed right now, from the project's record format and the free space the system reports. Also holds the low-space stop the background check runs while SAFE REC is lit: under 5 minutes or under 5 GB free on a drive in use, whichever comes first, it stops and saves the recording like SAVE REC and says which drive and why; on Dual, when only one drive gets low, it switches the record path to the other drive and keeps recording through a NEW TAKE (a moment's gap and a marker), and only stops when both are low. After a switch the record path stays on that drive for later recordings. If the restart fails, a box says so. Only recordings SAFE REC starts are guarded.

local M = {}

M.SECTION = "BSK_TIME_LEFT"
M.RECPATH_SECTION = "BSK_RECPATH"
M.PRIMARY, M.SECONDARY, M.DUAL = 0, 1, 2
M.CHECK_EVERY = 10
M.RESULT_WAIT = 30
M.AMBER_BELOW = 3600
M.RED_BELOW = 900
M.STOP_BELOW_SECONDS = 300
M.STOP_BELOW_BYTES = 5e9
M.ASSUMED_BITS = 32
M.ASSUMED_RATE = 48000

local B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"

function M.decodeBase64(s)
  local bits, out = "", {}
  for c in (s or ""):gsub("%s", ""):gmatch(".") do
    if c == "=" then break end
    local v = B64:find(c, 1, true)
    if not v then return "" end
    v = v - 1
    for b = 5, 0, -1 do bits = bits .. ((v >> b) & 1) end
  end
  for i = 1, #bits - 7, 8 do
    out[#out + 1] = string.char(tonumber(bits:sub(i, i + 7), 2))
  end
  return table.concat(out)
end

function M.recordBits(cfg)
  local raw = M.decodeBase64(cfg)
  if raw:sub(1, 4) == "evaw" and #raw >= 5 then
    local bits = raw:byte(5)
    if bits == 8 or bits == 16 or bits == 24 or bits == 32 or bits == 64 then return bits, true end
  end
  return M.ASSUMED_BITS, false
end

local function int(v)
  return math.tointeger(math.floor(v)) or 0
end

function M.trackChannels(recmode, input, nchan)
  if recmode == 1 or recmode == 3 or recmode == 13 then return 2 end
  if recmode == 5 or recmode == 6 or recmode == 12 then return 1 end
  if recmode == 10 or recmode == 11 or recmode == 14 then return nchan end
  if recmode ~= 0 then return 0 end
  if input < 0 or input & 4096 ~= 0 then return 0 end
  if input & 2048 ~= 0 then return nchan end
  if input & 1024 ~= 0 then return 2 end
  return 1
end

function M.armedLoad()
  local tracks, channels = 0, 0
  for i = 0, reaper.CountTracks(0) - 1 do
    local track = reaper.GetTrack(0, i)
    if reaper.GetMediaTrackInfo_Value(track, "I_RECARM") == 1 then
      local ch = M.trackChannels(int(reaper.GetMediaTrackInfo_Value(track, "I_RECMODE")),
        int(reaper.GetMediaTrackInfo_Value(track, "I_RECINPUT")),
        int(reaper.GetMediaTrackInfo_Value(track, "I_NCHAN")))
      if ch > 0 then
        tracks = tracks + 1
        channels = channels + ch
      end
    end
  end
  return tracks, channels
end

function M.sampleRate()
  local ok, value = reaper.GetAudioDeviceInfo("SRATE")
  local rate = ok and tonumber(value)
  if rate and rate > 0 then return rate end
  rate = reaper.GetSetProjectInfo(0, "PROJECT_SRATE", 0, false)
  if rate and rate > 0 then return rate end
  return M.ASSUMED_RATE
end

function M.bytesPerSecond(channels, rate, bits)
  return channels * rate * bits / 8
end

function M.secondsLeft(freeKb, bytesPerSecond)
  if not freeKb or bytesPerSecond <= 0 then return nil end
  return freeKb * 1024 / bytesPerSecond
end

function M.secondsUntilStop(freeKb, bytesPerSecond)
  if not freeKb or bytesPerSecond <= 0 then return nil end
  local reserve = math.max(M.STOP_BELOW_BYTES, M.STOP_BELOW_SECONDS * bytesPerSecond)
  return math.max(0, (freeKb * 1024 - reserve) / bytesPerSecond)
end

function M.formatTime(seconds)
  if seconds >= 100 * 3600 then return "99+ h" end
  local minutes = math.floor(seconds / 60)
  return string.format("%d h %02d m", minutes // 60, minutes % 60)
end

function M.formatFree(freeKb)
  local bytes = freeKb * 1024
  if bytes >= 999.5e9 then return string.format("(%.1f TB)", bytes / 1e12) end
  if bytes >= 9.95e9 then return string.format("(%d GB)", math.floor(bytes / 1e9 + 0.5)) end
  return string.format("(%.1f GB)", bytes / 1e9)
end

function M.lowDrives(mode, found, perSecond)
  local low = {}
  for drive = 1, 2 do
    local kb = found[drive]
    if M.inUse(mode, drive) and type(kb) == "number" then
      local bytes = kb * 1024
      local space = bytes < M.STOP_BELOW_BYTES
      local time = perSecond > 0 and bytes / perSecond < M.STOP_BELOW_SECONDS
      if space or time then
        local timeFirst = time and (not space or perSecond * M.STOP_BELOW_SECONDS > M.STOP_BELOW_BYTES)
        low[#low + 1] = { drive = drive, why = timeFirst and "time" or "space" }
      end
    end
  end
  return low
end

function M.fallbackDrive(mode, low, found)
  if mode ~= M.DUAL or #low ~= 1 then return nil end
  local other = 3 - low[1].drive
  if type(found[other]) == "number" then return other end
  return nil
end

function M.restartFailedMessage(low, other)
  local reasons = { space = "under 5 GB free", time = "under 5 minutes left" }
  local names = { "primary", "secondary" }
  return "Failed to keep recording on the " .. names[other] .. " drive: the " .. names[low[1].drive] .. " record drive had " .. reasons[low[1].why] .. ".\n\nThe take so far is saved. Press record to carry on, on the " .. names[other] .. " drive."
end

function M.stopMessage(low)
  local reasons = { space = "under 5 GB free", time = "under 5 minutes left" }
  local which
  if #low == 2 then
    which = "both record drives had " .. (low[1].why == low[2].why and reasons[low[1].why] or "under 5 minutes or 5 GB left")
  else
    which = "the " .. (low[1].drive == 1 and "primary" or "secondary") .. " record drive had " .. reasons[low[1].why]
  end
  return "Recording stopped and saved: " .. which .. ".\n\nFree up space or switch drives, then record again."
end

function M.level(seconds)
  if seconds < M.RED_BELOW then return "red" end
  if seconds < M.AMBER_BELOW then return "amber" end
  return "green"
end

function M.storedMode()
  local ok, value = reaper.GetProjExtState(0, M.RECPATH_SECTION, "mode")
  local mode = ok == 1 and tonumber(value) or nil
  if mode == M.PRIMARY or mode == M.SECONDARY or mode == M.DUAL then return mode end
  return nil
end

function M.inUse(mode, drive)
  if mode == M.DUAL then return true end
  if mode == M.SECONDARY then return drive == 2 end
  return drive == 1
end

function M.drivePaths()
  local primary = reaper.GetProjectPath() or ""
  local _, secondary = reaper.GetSetProjectInfo_String(0, "RECORD_PATH_SECONDARY", "", false)
  secondary = secondary or ""
  if secondary ~= "" and secondary:sub(1, 1) ~= "/" then
    local _, file = reaper.EnumProjects(-1)
    local folder = (file or ""):match("^(.*)/[^/]*$")
    secondary = folder and (folder .. "/" .. secondary) or ""
  end
  return primary, secondary
end

function M.shellQuote(s)
  return "'" .. s:gsub("'", "'\\''") .. "'"
end

function M.checkScript(seq, paths, out)
  local lines = { "{", "echo SEQ " .. seq }
  for i, path in ipairs(paths) do
    lines[#lines + 1] = "p=" .. M.shellQuote(path)
    lines[#lines + 1] = 'if [ -z "$p" ]; then echo "' .. i .. ' NOTSET"; else'
    lines[#lines + 1] = '  case "$p" in /Volumes/*) v=$(printf "%s" "$p" | cut -d/ -f1-3); if [ ! -d "$v" ]; then echo "' .. i .. ' MISSING"; p=""; fi;; esac'
    lines[#lines + 1] = '  if [ -n "$p" ]; then'
    lines[#lines + 1] = '    while [ ! -d "$p" ] && [ "$p" != "/" ]; do'
    lines[#lines + 1] = '      if [ -L "$p" ]; then echo "' .. i .. ' MISSING"; p=""; break; fi'
    lines[#lines + 1] = '      p=$(dirname "$p")'
    lines[#lines + 1] = '    done'
    lines[#lines + 1] = '  fi'
    lines[#lines + 1] = '  if [ -n "$p" ]; then'
    lines[#lines + 1] = '    k=$(/bin/df -kP "$p" 2>/dev/null | tail -1 | awk \'{print $4}\')'
    lines[#lines + 1] = '    echo "' .. i .. ' ${k:-ERR}"'
    lines[#lines + 1] = '  fi'
    lines[#lines + 1] = 'fi'
  end
  local part = out .. "." .. seq .. ".part"
  lines[#lines + 1] = "} > " .. M.shellQuote(part)
  lines[#lines + 1] = "mv -f " .. M.shellQuote(part) .. " " .. M.shellQuote(out)
  return table.concat(lines, "\n") .. "\n"
end

function M.parseResult(text)
  local seq = tonumber((text or ""):match("^SEQ (%d+)"))
  local result = {}
  for i, value in (text or ""):gmatch("\n(%d+) (%S+)") do
    result[tonumber(i)] = tonumber(value) or value
  end
  return seq, result
end

function M.driveRow(label, drive, mode, found, perSecond)
  local row = { label = label, inUse = M.inUse(mode, drive) }
  if found == "MISSING" then
    row.text, row.level = "not connected", row.inUse and "red" or "dim"
  elseif found == "NOTSET" then
    row.text, row.level = "no path set", row.inUse and "red" or "dim"
  elseif found == nil then
    row.text, row.level = "checking", "dim"
  elseif type(found) ~= "number" then
    row.text, row.level = "unknown", row.inUse and "red" or "dim"
  elseif perSecond <= 0 then
    row.text, row.level = "--", "dim"
  else
    local seconds = M.secondsUntilStop(found, perSecond)
    row.text = M.formatTime(seconds)
    row.level = row.inUse and M.level(seconds) or "dim"
    row.time = true
    row.free = M.formatFree(found)
  end
  return row
end

function M.footer(tracks, channels, rate, bits, known)
  if tracks == 0 then return "No tracks armed" end
  local what = tracks == 1 and "1 armed track" or (tracks .. " armed tracks")
  if channels ~= tracks then what = what .. " (" .. channels .. " ch)" end
  return string.format("%s, %s kHz, %d bit%s", what, string.format("%g", rate / 1000), bits, known and "" or " (assumed)")
end

function M.alive()
  local stamp = tonumber(reaper.GetExtState(M.SECTION, "alive"))
  return stamp ~= nil and (reaper.time_precise() - stamp) < 3
end

function M.newChecker(stem)
  local tmp = (os.getenv("TMPDIR") or "/tmp/"):gsub("/*$", "/")
  local out, script = tmp .. stem .. ".txt", tmp .. stem .. ".sh"
  local c = { free = {}, freeKey = nil }
  local seq, waitingSeq, waitingSince, waitingKey = os.time(), nil, 0, nil
  local nextCheck, nextRead = 0, 0

  local function start(now, paths, key)
    seq = seq + 1
    local f = io.open(script .. ".new", "w")
    if not f then return end
    f:write(M.checkScript(seq, paths, out))
    f:close()
    os.rename(script .. ".new", script)
    os.remove(out)
    reaper.ExecProcess("/bin/sh " .. script, -1)
    waitingSeq, waitingSince, waitingKey = seq, now, key
  end

  local function read()
    local f = io.open(out, "r")
    if not f then return false end
    local text = f:read("a")
    f:close()
    local got, result = M.parseResult(text)
    if got ~= waitingSeq then return false end
    c.free, c.freeKey = result, waitingKey
    waitingSeq = nil
    return true
  end

  function c.poll(now, paths, key)
    local fresh = false
    if waitingSeq and now >= nextRead then
      nextRead = now + 0.5
      fresh = read()
    end
    local stale = key ~= c.freeKey and key ~= waitingKey
    if (now >= nextCheck or stale) and (not waitingSeq or now - waitingSince > M.RESULT_WAIT) then
      nextCheck = now + M.CHECK_EVERY
      start(now, paths, key)
    end
    return fresh
  end

  function c.forget()
    c.free, c.freeKey = {}, nil
    waitingSeq, waitingKey, nextCheck = nil, nil, 0
  end

  return c
end

function M.recordLoad()
  local tracks, channels = M.armedLoad()
  local rate = M.sampleRate()
  local _, cfg = reaper.GetSetProjectInfo_String(0, "RECORD_FORMAT", "", false)
  local bits, known = M.recordBits(cfg)
  return tracks, channels, rate, bits, known, M.bytesPerSecond(channels, rate, bits)
end

function M.notice()
  local text = reaper.GetExtState(M.SECTION, "notice")
  return text ~= "" and text or nil
end

function M.newGuard(dir)
  local g = {}
  local checker = M.newChecker("BSK_rec_guard")
  local tried, nextLook, wasActive = false, 0, false

  local function setNotice(text)
    reaper.SetExtState(M.SECTION, "notice", text, false)
  end

  local function act(low, mode, found)
    local other = M.fallbackDrive(mode, low, found)
    local switched = false
    local transport = dofile(dir .. "BSK_Transport_Common.lua")
    local newTake = reaper.NamedCommandLookup(transport.TAKE_ID)
    if other and newTake ~= 0 then
      local recpath = dofile(dir .. "BSK_RecPath_Common.lua")
      local newMode = other == 1 and recpath.PRIMARY or recpath.SECONDARY
      recpath.applyToAllTracks(newMode)
      local actual, _, readable = recpath.projectMode()
      if actual == newMode or readable == 0 then
        recpath.storeMode(newMode)
        recpath.setLights(newMode)
        reaper.DeleteExtState(transport.SECTION, "take_last", false)
        reaper.Main_OnCommand(newTake, 0)
        switched = reaper.GetExtState(transport.SECTION, "take_last") ~= ""
        if not switched then
          recpath.applyToAllTracks(recpath.DUAL)
          recpath.storeMode(recpath.DUAL)
          recpath.setLights(recpath.DUAL)
        elseif reaper.GetPlayState() & 4 == 4 then
          setNotice((other == 1 and "SEC" or "PRI") .. " nearly full: recording to " .. (other == 1 and "PRI" or "SEC") .. " only")
        else
          tried = true
          reaper.ShowMessageBox(M.restartFailedMessage(low, other), "Rec Time Left", 0)
        end
      else
        recpath.applyToAllTracks(recpath.DUAL)
      end
    end
    if #low > 0 and not switched then
      tried = true
      local save = reaper.NamedCommandLookup(transport.SAVE_ACTION)
      transport.stopRecording(transport.SAVE_ID, save ~= 0 and save or 40667)
      if reaper.GetPlayState() & 4 == 0 then
        reaper.ShowMessageBox(M.stopMessage(low), "Rec Time Left", 0)
      else
        setNotice("Failed to stop: " .. (#low == 2 and "PRI and SEC" or (low[1].drive == 1 and "PRI" or "SEC")) .. " nearly full")
      end
    end
  end

  function g.tick(now, active)
    if not active then
      if wasActive then
        wasActive, tried = false, false
        checker.forget()
        reaper.DeleteExtState(M.SECTION, "notice", false)
      end
      return
    end
    wasActive = true
    local primary, secondary = M.drivePaths()
    local key = primary .. "\n" .. secondary
    if checker.poll(now, { primary, secondary }, key) then nextLook = 0 end
    if tried or now < nextLook then return end
    nextLook = now + 1
    local found = key == checker.freeKey and checker.free or {}
    local mode = M.storedMode()
    local perSecond = select(6, M.recordLoad())
    local low = M.lowDrives(mode, found, perSecond)
    if #low > 0 then act(low, mode, found) end
  end

  function g.stop()
    reaper.DeleteExtState(M.SECTION, "notice", false)
  end

  return g
end

return M
