-- @description BSK View: REC TIME LEFT (recording time left on the primary and secondary record paths)
-- @author BSK
-- @version 1.3
-- @about A small window showing how long recording can continue on the primary and secondary record paths at the tracks armed right now (the time until SAFE REC's low-space stop, not until the drive is full), with each drive's free space after its time, and No tracks armed in amber when nothing is armed (locking tracks disarms them). The path the REC PRI / SEC / BOTH buttons are not using is shown dim. Green normally, amber under 1 hour, red under 15 minutes. It only shows: the low-space stop belongs to SAFE REC and runs in the background whether this window is open or not. When that stop switches drives on Dual, or fails to stop, the bottom line says so in amber until recording stops. It watches the project in the front tab only. Free space is checked every 10 seconds in the background, so the window never holds REAPER up, even if a drive is slow. Right-click to dock or undock it; it opens where it was last time. It closes by itself when you leave the RECORD tab, and the RECORD tab opens it again unless you hid it with the REC TIME LEFT button. Close it with its close button or the REC TIME LEFT button.

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local tl = dofile(dir .. "BSK_Time_Left_Common.lua")

if tl.alive() then return end
if reaper.set_action_options then reaper.set_action_options(2) end

local TITLE = "REC TIME LEFT"
local BASE_W, BASE_H = 260, 150
local COLOURS = {
  bg = { 22, 23, 27 }, text = { 159, 159, 159 }, dim = { 95, 97, 103 },
  green = { 90, 200, 110 }, amber = { 235, 170, 60 }, red = { 225, 80, 70 },
}

local checker = tl.newChecker("BSK_time_left")
local nextModel, nextAlive, nextSave = 0, 0, 0
local model, drawn, lastSize = nil, nil, nil
local lastDock, lastPlace = nil, nil
local rightWasDown = false
local lastNotice = nil

local function saved(key, default)
  local v = tonumber(reaper.GetExtState(tl.SECTION, key))
  return v or default
end

local function buildModel(key)
  local tracks, channels, rate, bits, known, perSecond = tl.recordLoad()
  local mode = tl.storedMode()
  local current = key == checker.freeKey and checker.free or {}
  local notice = tl.notice()
  lastNotice = notice
  return {
    rows = {
      tl.driveRow("PRI", 1, mode, current[1], perSecond),
      tl.driveRow("SEC", 2, mode, current[2], perSecond),
    },
    footer = notice or tl.footer(tracks, channels, rate, bits, known),
    footerLevel = (notice or tracks == 0) and "amber" or "text",
  }
end

local function signature(m)
  local parts = { m.footer }
  for _, row in ipairs(m.rows) do parts[#parts + 1] = row.label .. row.text .. row.level .. tostring(row.inUse) .. (row.free or "") end
  return table.concat(parts, "|")
end

local function colour(name)
  local c = COLOURS[name]
  gfx.set(c[1] / 255, c[2] / 255, c[3] / 255, 1)
end

local function draw(m)
  local s = math.max(0.7, math.min(3, math.min(gfx.w / BASE_W, gfx.h / BASE_H)))
  colour("bg")
  gfx.rect(0, 0, gfx.w, gfx.h, 1)
  gfx.setfont(1, "Arial", math.floor(12 * s), string.byte("b"))
  colour("text")
  gfx.x, gfx.y = 12 * s, 10 * s
  gfx.drawstr("REC TIME LEFT")
  local y = 34 * s
  for _, row in ipairs(m.rows) do
    gfx.setfont(2, "Arial", math.floor(15 * s), string.byte("b"))
    colour(row.inUse and "text" or "dim")
    gfx.x, gfx.y = 12 * s, y + 10 * s
    gfx.drawstr(row.label)
    gfx.setfont(3, "Arial", math.floor((row.time and 30 or 18) * s), string.byte("b"))
    colour(row.level)
    gfx.x, gfx.y = 62 * s, y + (row.time and 0 or 8 * s)
    gfx.drawstr(row.text)
    if row.free then
      local x = 62 * s + gfx.measurestr(row.text) + 8 * s
      local size = math.floor(13 * s)
      gfx.setfont(5, "Arial", size, string.byte("b"))
      while size > math.floor(10 * s) and x + gfx.measurestr(row.free) > gfx.w - 12 * s do
        size = size - 1
        gfx.setfont(5, "Arial", size, string.byte("b"))
      end
      if x + gfx.measurestr(row.free) <= gfx.w - 12 * s then
        colour(row.inUse and "text" or "dim")
        gfx.x, gfx.y = x, y + 13 * s + math.floor(13 * s) - size
        gfx.drawstr(row.free)
      end
    end
    y = y + 44 * s
  end
  local size = math.floor(12 * s)
  gfx.setfont(4, "Arial", size, string.byte("b"))
  while size > math.floor(10 * s) and gfx.measurestr(m.footer) > gfx.w - 24 * s do
    size = size - 1
    gfx.setfont(4, "Arial", size, string.byte("b"))
  end
  colour(m.footerLevel)
  gfx.x, gfx.y = 12 * s, y + 4 * s
  gfx.drawstr(m.footer)
end

local function place()
  local dock, x, y, w, h = gfx.dock(-1, 0, 0, 0, 0)
  return dock, x, y, w, h
end

local function savePlace()
  local dock, x, y, w, h = place()
  reaper.SetExtState(tl.SECTION, "dock", tostring(dock), true)
  if dock & 1 == 1 then
    reaper.SetExtState(tl.SECTION, "lastdock", tostring(dock), true)
  else
    reaper.SetExtState(tl.SECTION, "x", tostring(x), true)
    reaper.SetExtState(tl.SECTION, "y", tostring(y), true)
    reaper.SetExtState(tl.SECTION, "w", tostring(w), true)
    reaper.SetExtState(tl.SECTION, "h", tostring(h), true)
  end
end

local function giveBackKeyboard()
  if reaper.BR_Win32_SetFocus and reaper.GetMainHwnd then reaper.BR_Win32_SetFocus(reaper.GetMainHwnd()) end
end

local function rightClickMenu()
  local dock = gfx.dock(-1)
  gfx.x, gfx.y = gfx.mouse_x, gfx.mouse_y
  local choice = gfx.showmenu(dock & 1 == 1 and "Undock window" or "Dock window")
  if choice == 1 then
    if dock & 1 == 1 then
      gfx.dock(0)
    else
      gfx.dock(saved("lastdock", 1))
    end
    savePlace()
    drawn = nil
    giveBackKeyboard()
  end
end

local function leaveNow()
  if reaper.GetExtState(tl.SECTION, "close") ~= "" then
    reaper.DeleteExtState(tl.SECTION, "close", false)
    return true
  end
  local tab = (reaper.GetExtState("BSK_TRANSPORT", "tab"):match("^%s*(.-)%s*$") or ""):upper()
  return tab ~= "" and tab ~= "RECORD"
end

local function loop()
  local now = reaper.time_precise()
  if gfx.getchar() < 0 then return end
  if leaveNow() then
    savePlace()
    gfx.quit()
    return
  end

  if now >= nextAlive then
    nextAlive = now + 0.5
    reaper.SetExtState(tl.SECTION, "alive", tostring(now), false)
  end

  local rightDown = gfx.mouse_cap & 2 == 2
  if rightDown and not rightWasDown then rightClickMenu() end
  rightWasDown = rightDown

  local primary, secondary = tl.drivePaths()
  local key = primary .. "\n" .. secondary
  if checker.poll(now, { primary, secondary }, key) then nextModel = 0 end

  if now >= nextModel or not model or tl.notice() ~= lastNotice then
    nextModel = now + 1
    model = buildModel(key)
  end

  local size = gfx.w .. "x" .. gfx.h
  local sig = signature(model)
  if sig ~= drawn or size ~= lastSize then
    draw(model)
    drawn, lastSize = sig, size
  end

  if now >= nextSave then
    nextSave = now + 1
    local dock, x, y, w, h = place()
    local where = table.concat({ x, y, w, h }, ",")
    if dock ~= lastDock or (dock & 1 == 0 and where ~= lastPlace) then
      savePlace()
      lastDock, lastPlace = dock, where
    end
  end

  gfx.update()
  reaper.defer(loop)
end

reaper.atexit(function()
  reaper.DeleteExtState(tl.SECTION, "alive", false)
  if gfx.getchar() >= 0 then savePlace() end
end)

local function belowMouse(mx, my)
  local _, top, _, bottom = reaper.my_getViewport(0, 0, 0, 0, mx, my, mx, my, true)
  if top and bottom and top > bottom then return my - 60 end
  return my + 60
end

reaper.DeleteExtState(tl.SECTION, "close", false)
local mx, my = reaper.GetMousePosition()
gfx.ext_retina = 1
gfx.init(TITLE, saved("w", BASE_W), saved("h", BASE_H), saved("dock", 0), saved("x", math.max(0, mx - BASE_W // 2)), saved("y", belowMouse(mx, my)))
giveBackKeyboard()
reaper.SetExtState(tl.SECTION, "alive", tostring(reaper.time_precise()), false)
reaper.defer(loop)
