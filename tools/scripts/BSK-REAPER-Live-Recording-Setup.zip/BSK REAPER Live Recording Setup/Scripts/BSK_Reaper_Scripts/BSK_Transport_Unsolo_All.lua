-- @description BSK Transport: UNSOLO ALL (lit while any track is soloed; press to clear every solo)
-- @author BSK
-- @version 1.0
-- @about Clears the solo on every track and the button goes dark. The light comes back on as soon as any track is soloed again.

if reaper.set_action_options then reaper.set_action_options(3) end
reaper.defer(function() end)

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")

transport.unsoloAll()
