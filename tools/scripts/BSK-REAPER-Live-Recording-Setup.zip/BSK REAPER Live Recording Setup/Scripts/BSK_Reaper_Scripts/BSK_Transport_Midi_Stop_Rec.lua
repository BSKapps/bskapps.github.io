-- @description BSK Transport: STOP REC {MIDI SCENE} (for a desk scene: stops and saves only while recording, with MIDI SCENE on)
-- @author BSK
-- @version 1.0
-- @about For a desk scene to fire through Companion. Recording, or a paused recording: does exactly what SAVE REC does (stop, save the recording, the button flashes). Stopped, playing or paused playback: does nothing, so a scene recalled during a VSC rehearsal never stops the playback. Does nothing while MIDI SCENE is dark. The SAVE REC button and the Stream Deck STOP key are unchanged.

if reaper.set_action_options then reaper.set_action_options(3) end
reaper.defer(function() end)

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")

if not transport.midiSceneOn() then return end
if reaper.GetPlayState() & 4 == 0 then return end

dofile(dir .. "BSK_Transport_Save_Rec.lua")
