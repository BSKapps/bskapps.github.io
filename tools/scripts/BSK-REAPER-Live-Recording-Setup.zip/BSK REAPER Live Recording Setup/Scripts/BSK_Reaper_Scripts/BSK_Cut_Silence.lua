-- @description BSK: CUT SILENCE (find long silences across every track, show them as red regions, then cut them from every track)
-- @author BSK
-- @version 1.2
-- @about Find Silence listens to every track, whatever is selected, from 0:00:00 to the end of the last item and shows each silent stretch as a red CUT SILENCE region. Silent means every listened track stays below the Silent below level for at least the Silent for at least time; the Keep each side time of silence is kept next to every sound. Delete or resize a red region to change what goes. Cut removes the red regions from every track at the same times and closes the gaps, with a 10 ms fade either side of each join; markers inside a cut move to the join, later markers move with the audio, and a region wholly inside a cut becomes a marker at the join. Locked items are cut too and stay locked. Undo Silent Regions removes only the red regions. Change Settings opens the settings page: Change Values sets the level, time and keep, and they are remembered; Reset Settings puts back -45 dB, 30 s and 2 s. Recorded files are never changed. Find Silence first lets REAPER finish building any missing peaks, and measures an item with its volume changed at that volume; an item that is sped up, slowed down, stretched or reversed, or whose audio cannot be read, counts as sound for its whole length and is named under the list. It refuses when every track is silent from start to end. Cut refuses with tempo changes, grouped items, automation after the first red region, or cut items with more than one take, a changed speed or reversed. Both refuse while recording, playing or paused, and in a project whose file name contains PLUGIN HOST. The window closes when recording starts or the project changes tab, and after a cut. Each step is one undo.

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local cut = dofile(dir .. "BSK_Cut_Silence_Common.lua")

local TITLE = "Remove Silent Gaps"
local W, PAD, ROWS_Y, ROW_H, NOTE_H, BTN_H = 500, 12, 38, 22, 18, 28
local START_HEIGHT = ROWS_Y + 4 * ROW_H + 6 + 4 * NOTE_H + 12 + BTN_H + 12
local ACCENT = "#2FA39A"
local BOX_PAD, BOX_TITLE_H, BOX_GAP, SHOW_W = 10, 20, 10, 96
local LIST_MAX = 20
local SCAN_BUDGET = 0.008
local PROGRESS_EVERY = 0.2

local proj, projectFile = reaper.EnumProjects(-1)

local blockedReason, blockedFix = cut.blocked(proj, projectFile)
if blockedReason then
  reaper.ShowMessageBox(cut.failure("open Remove Silent Gaps", blockedReason, blockedFix), TITLE, 0)
  return
end

local scan, scanSettings, scanTracks, scanStarted, scanNote, unmeasuredNote, status, lastMode, settingsOpen
local scale, hits, wasDown, pressedKey = 1, {}, false, nil
local dirty, signature, lastProgress, lastW, lastH = true, nil, 0, nil, nil
local content
local heldList, heldHeight = nil, 0

local function plural(count, one, many)
  return count == 1 and one or many
end

local function setStatus(text)
  status = text
  dirty = true
end

local function close()
  return true
end

local function quit()
  if scan then
    cut.stopScan(scan)
    scan = nil
  end
  gfx.quit()
end

local function everyTrack()
  local tracks = {}
  for i = 0, reaper.CountTracks(proj) - 1 do tracks[#tracks + 1] = reaper.GetTrack(proj, i) end
  return tracks
end

local function find()
  local reason, fix = cut.blocked(proj, projectFile)
  if reason then return setStatus(cut.failure("find silence", reason, fix)) end
  local tracks = everyTrack()
  local rangeEnd = cut.projectEnd(proj)
  if #tracks == 0 or rangeEnd <= cut.EPS then
    return setStatus(cut.failure("find silence", "there is no audio to listen to."))
  end
  scanSettings = cut.settings()
  scanTracks = #tracks
  scanStarted = reaper.time_precise()
  scan = cut.startScan(proj, tracks, scanSettings, rangeEnd)
  setStatus(nil)
end

local function openSettings()
  settingsOpen = true
  setStatus(nil)
end

local function closeSettings()
  settingsOpen = false
  setStatus(nil)
end

local function resetSettings()
  cut.saveSettings({ db = cut.DEFAULT_DB, length = cut.DEFAULT_LENGTH, keep = cut.DEFAULT_KEEP })
  setStatus(nil)
end

local function changeSettings()
  local ok, text = reaper.GetUserInputs("Remove Silent Gaps Settings", 3,
    "Silent below (dB),Silent for at least (seconds),Keep each side (seconds),separator=|", cut.settingsText(cut.settings()))
  if not ok then return end
  local settings, problem = cut.parseSettings(text)
  if not settings then return setStatus(problem) end
  cut.saveSettings(settings)
  setStatus(nil)
end

local function cutStretches()
  local reason, fix = cut.blocked(proj, projectFile)
  if reason then return setStatus(cut.failure("cut silence", reason, fix)) end
  local cuts = cut.onSamples(proj, cut.mergeCuts(cut.redRegions(proj), cut.projectEnd(proj)))
  if #cuts == 0 then return setStatus(nil) end
  local problem, problemFix = cut.cutProblem(proj, cuts)
  if problem then return setStatus(cut.failure("cut silence", problem, problemFix)) end
  if cut.cut(proj, cuts) then
    reaper.ShowMessageBox(cut.failure("cut silence", "it stopped part way.", "Press Undo once to put the project back."), TITLE, 0)
  end
  return true
end

local function upperFirst(text)
  return text:sub(1, 1):upper() .. text:sub(2)
end

local function fixBox(problem, fix, item)
  if not item then return { lines = { upperFirst(problem) }, fix = fix } end
  local track = reaper.GetMediaItem_Track(item)
  local where = upperFirst(cut.trackLabel(track)) .. ", item at " .. cut.clock(reaper.GetMediaItemInfo_Value(item, "D_POSITION"))
  local takes = reaper.CountTakes(item)
  if takes > 1 then
    return { lines = { where .. " has " .. takes .. " takes." }, fix = "Right-click it, then Take > Crop to active take.", item = item }
  end
  return { lines = { where .. cut.SPEED_REASON }, fix = fix, item = item }
end

local function showItem(item)
  return function()
    if not reaper.ValidatePtr2(proj, item, "MediaItem*") then return end
    local track = reaper.GetMediaItem_Track(item)
    reaper.PreventUIRefresh(1)
    reaper.Main_OnCommand(40289, 0)
    reaper.SetMediaItemSelected(item, true)
    reaper.SetOnlyTrackSelected(track)
    reaper.Main_OnCommand(40913, 0)
    reaper.SetEditCurPos2(proj, reaper.GetMediaItemInfo_Value(item, "D_POSITION"), true, false)
    reaper.PreventUIRefresh(-1)
    reaper.UpdateArrange()
  end
end

local function removeRegions()
  cut.removeRegions(proj)
  scanNote = nil
  setStatus(nil)
end

local function listTracks(tracks)
  local seen, labels = {}, {}
  table.sort(tracks, function(a, b) return reaper.GetMediaTrackInfo_Value(a, "IP_TRACKNUMBER") < reaper.GetMediaTrackInfo_Value(b, "IP_TRACKNUMBER") end)
  for _, track in ipairs(tracks) do
    if not seen[track] then
      seen[track] = true
      labels[#labels + 1] = cut.trackLabel(track)
    end
  end
  if #labels > 3 then return labels[1] .. ", " .. labels[2] .. " and " .. (#labels - 2) .. " more tracks" end
  if #labels == 1 then return labels[1] end
  return table.concat(labels, ", ", 1, #labels - 1) .. " and " .. labels[#labels]
end

local function stepScanning()
  local state, value, allSilent, unmeasured = cut.stepScan(scan, SCAN_BUDGET)
  if state == "running" then
    local now = reaper.time_precise()
    if now - lastProgress >= PROGRESS_EVERY then
      lastProgress = now
      dirty = true
    end
    return
  end
  local settings = scanSettings
  scan = nil
  unmeasuredNote = nil
  if state == "done" and #unmeasured > 0 then
    unmeasuredNote = "Failed to measure " .. #unmeasured .. plural(#unmeasured, " item", " items") .. " on " .. listTracks(unmeasured) .. "; kept as sound."
  end
  if state == "done" then
    local who = scanTracks == 1 and "the track" or ("the " .. scanTracks .. " tracks")
    if allSilent then
      return setStatus(cut.failure("find silence", who .. (scanTracks == 1 and " is" or " are") .. " silent from start to end."))
    end
    if #value == 0 then
      return setStatus("No silent stretches found. Nothing on " .. who .. " stays below " .. cut.formatNumber(settings.db)
        .. " dB for " .. cut.formatNumber(settings.length) .. " s or more." .. (unmeasuredNote and ("\n" .. unmeasuredNote) or ""))
    end
    cut.markRegions(proj, value)
    setStatus(nil)
    scanNote = string.format("Listened to %d %s in %.1f s.", scanTracks, plural(scanTracks, "track", "tracks"), reaper.time_precise() - scanStarted)
    return
  elseif state == "unreadable" then
    return setStatus(cut.failure("find silence", "the audio on " .. cut.trackLabel(value) .. " cannot be read yet.",
      "Check that its audio file is there, wait a moment, then try again."))
  elseif state == "changed" then
    return setStatus(cut.failure("find silence", "the project changed while listening.", "Press Find Silence again."))
  end
  return setStatus(cut.failure("find silence", "something went wrong while listening.", "Press Find Silence again."))
end

local function statusLines(fallback)
  if not status then return fallback end
  local lines = {}
  for line in (status .. "\n"):gmatch("([^\n]*)\n") do
    if line ~= "" then lines[#lines + 1] = line end
  end
  return lines
end

local function contentA()
  local tracks = everyTrack()
  local total = #tracks
  local settings = cut.settings()
  local listening
  if total == 1 then
    listening = "Listening to:  the only track"
  else
    listening = "Listening to:  all " .. total .. " tracks"
  end
  local cuts = total == 1 and "Cuts:  the only track" or ("Cuts:  all " .. total .. " tracks, at the same times")
  local who = #tracks == 1 and "this track" or ("all " .. #tracks .. " tracks")
  return {
    header = "Finds long silences and cuts them from every track.",
    rows = {
      listening,
      cuts,
      "Silent:  " .. who .. " below " .. cut.formatNumber(settings.db) .. " dB for " .. cut.formatNumber(settings.length) .. " s or more",
      "Keeps:  " .. cut.formatNumber(settings.keep) .. " s of silence on each side of every sound",
    },
    notes = statusLines({ "Find Silence only adds red regions. Nothing is cut yet." }),
    buttons = {
      { label = "Find Silence", action = find },
      { label = "Change Settings", action = openSettings },
      { label = "Close", action = close },
    },
    enter = 1,
  }
end

local function contentSettings()
  local settings = cut.settings()
  return {
    header = "Remove Silent Gaps settings",
    rows = {
      "Silent below:  " .. cut.formatNumber(settings.db) .. " dB",
      "Silent for at least:  " .. cut.formatNumber(settings.length) .. " s",
      "Keep each side:  " .. cut.formatNumber(settings.keep) .. " s",
    },
    notes = statusLines({ "Defaults: " .. cut.formatNumber(cut.DEFAULT_DB) .. " dB, " .. cut.formatNumber(cut.DEFAULT_LENGTH) .. " s, " .. cut.formatNumber(cut.DEFAULT_KEEP) .. " s." }),
    buttons = {
      { label = "Change Values", action = changeSettings },
      { label = "Reset Settings", action = resetSettings },
      { label = "Back", action = closeSettings },
    },
    enter = 1,
  }
end

local function contentScanning()
  return {
    header = "Listening... track " .. math.min(scan.done + 1, scan.total) .. " of " .. scan.total .. ".",
    rows = {},
    notes = { "Close stops it and adds no red regions." },
    buttons = { { label = "Close", action = close } },
  }
end

local function contentB(cuts)
  local total = reaper.CountTracks(proj)
  local rows, seconds = cut.rows(cuts)
  local header
  if #cuts == 1 then
    header = "1 silent stretch shown as a red region, " .. cut.duration(seconds) .. ":"
  else
    header = #cuts .. " silent stretches shown as red regions, " .. cut.duration(seconds) .. " in all:"
  end
  local shown = rows
  if #rows > LIST_MAX + 1 then
    shown = {}
    for i = 1, LIST_MAX do shown[i] = rows[i] end
    shown[#shown + 1] = "...and " .. (#rows - LIST_MAX) .. " more"
  end
  local box
  local problem, problemFix, problemItem = cut.cutProblem(proj, cut.onSamples(proj, cuts))
  if problem then box = fixBox(problem, problemFix, problemItem) end
  local where = total == 1 and "Cuts the only track at these times." or ("Cuts all " .. total .. " tracks at these times.")
  local notes = { where .. " Delete or resize a red region to change what goes." }
  for _, line in ipairs(statusLines({ "After the cut, one undo puts everything back." })) do notes[#notes + 1] = line end
  if unmeasuredNote then notes[#notes + 1] = unmeasuredNote end
  if scanNote and not status then notes[#notes + 1] = scanNote end
  return {
    list = true,
    header = header,
    rows = shown,
    box = box,
    notes = notes,
    buttons = {
      { label = "Cut " .. #cuts .. plural(#cuts, " Stretch", " Stretches"), action = cutStretches, disabled = box ~= nil },
      { label = "Undo Silent Regions", action = removeRegions },
      { label = "Close", action = close },
    },
  }
end

local function buildContent()
  if scan then
    lastMode = "scan"
    return contentScanning()
  end
  if settingsOpen then return contentSettings() end
  local cuts = cut.mergeCuts(cut.redRegions(proj), cut.projectEnd(proj))
  local mode = #cuts > 0 and "B" or "A"
  if (mode == "A" and lastMode == "B") or (mode == "B" and lastMode == "A") then
    status = nil
    scanNote, unmeasuredNote = nil, nil
  end
  lastMode = mode
  if mode == "B" then return contentB(cuts) end
  return contentA()
end

local function setColor(hex, alpha)
  local r, g, b = hex:match("^#(%x%x)(%x%x)(%x%x)$")
  gfx.set(tonumber(r, 16) / 255, tonumber(g, 16) / 255, tonumber(b, 16) / 255, alpha or 1)
end

local function fillRound(x, y, w, h, r)
  x, y, w, h, r = x * scale, y * scale, w * scale, h * scale, r * scale
  gfx.rect(x + r, y, w - 2 * r, h, 1)
  gfx.rect(x, y + r, w, h - 2 * r, 1)
  gfx.circle(x + r, y + r, r, 1, 1)
  gfx.circle(x + w - r - 1, y + r, r, 1, 1)
  gfx.circle(x + r, y + h - r - 1, r, 1, 1)
  gfx.circle(x + w - r - 1, y + h - r - 1, r, 1, 1)
end

local function frameRound(x, y, w, h, r)
  gfx.roundrect(x * scale, y * scale, w * scale, h * scale, r * scale, 1)
end

local function fitText(text, width)
  if gfx.measurestr(text) <= width then return text end
  while #text > 0 and gfx.measurestr(text .. "...") > width do text = text:sub(1, -2) end
  return text .. "..."
end

local function drawText(text, x, y, w, h, flags)
  gfx.x, gfx.y = x * scale, y * scale
  gfx.drawstr(fitText(text, w * scale), flags, (x + w) * scale, (y + h) * scale)
end

local function setFont(size, bold)
  if bold then
    gfx.setfont(1, "Arial", size * scale, string.byte("b"))
  else
    gfx.setfont(1, "Arial", size * scale)
  end
end

local function wrap(lines, width)
  local out = {}
  for _, line in ipairs(lines) do
    local current = ""
    for word in line:gmatch("%S+") do
      local candidate = current == "" and word or (current .. " " .. word)
      if current ~= "" and gfx.measurestr(candidate) > width * scale then
        out[#out + 1] = current
        current = word
      else
        current = candidate
      end
    end
    if current ~= "" then out[#out + 1] = current end
  end
  return out
end

local function addHit(key, x, y, w, h, action)
  hits[#hits + 1] = { key = key, x = x, y = y, w = w, h = h, action = action }
end

local function button(key, label, x, y, w, h, primary, action)
  setColor(primary and ACCENT or "#444444")
  fillRound(x, y, w, h, 4)
  if not primary then
    setColor("#666666")
    frameRound(x, y, w, h, 4)
  end
  setColor(primary and "#FFFFFF" or "#DDDDDD")
  drawText(label, x, y, w, h, 5)
  addHit(key, x, y, w, h, action)
end

local function disabledButton(label, x, y, w, h)
  setColor("#373737")
  fillRound(x, y, w, h, 4)
  setColor("#4B4B4B")
  frameRound(x, y, w, h, 4)
  setColor("#787878")
  drawText(label, x, y, w, h, 5)
end

local function boxLayout(box)
  if not box then return nil end
  setFont(13)
  local width = W - 2 * PAD - 2 * BOX_PAD - (box.item and (SHOW_W + BOX_PAD) or 0)
  local lines = wrap(box.lines, width)
  setFont(12)
  local fixLines = wrap({ box.fix }, width)
  return { lines = lines, fixLines = fixLines, width = width, h = BOX_PAD + BOX_TITLE_H + #lines * ROW_H + #fixLines * NOTE_H + BOX_PAD }
end

local function drawBox(box, layout, y)
  setColor("#3A3224")
  fillRound(PAD, y, W - 2 * PAD, layout.h, 4)
  setColor("#D6A03C")
  frameRound(PAD, y, W - 2 * PAD, layout.h, 4)
  local x = PAD + BOX_PAD
  local lineY = y + BOX_PAD
  setFont(13, true)
  setColor("#F0BE5A")
  drawText("Fix this before cutting:", x, lineY, layout.width, BOX_TITLE_H, 4)
  lineY = lineY + BOX_TITLE_H
  setFont(13)
  setColor("#E6E6E6")
  for _, line in ipairs(layout.lines) do
    drawText(line, x, lineY, layout.width, ROW_H, 4)
    lineY = lineY + ROW_H
  end
  setFont(12)
  setColor("#BEBEBE")
  for _, line in ipairs(layout.fixLines) do
    drawText(line, x, lineY, layout.width, NOTE_H, 4)
    lineY = lineY + NOTE_H
  end
  if box.item then
    setFont(13)
    button("show", "Show Item", W - PAD - BOX_PAD - SHOW_W, y + (layout.h - BTN_H) / 2, SHOW_W, BTN_H, false, showItem(box.item))
  end
end

local function draw()
  scale = (gfx.ext_retina and gfx.ext_retina > 0) and gfx.ext_retina or 1
  content = buildContent()
  local layout = boxLayout(content.box)
  local boxH = layout and (layout.h + BOX_GAP) or 0
  setFont(12)
  local notes = wrap(content.notes, W - 2 * PAD)
  local needed = ROWS_Y + #content.rows * ROW_H + 6 + boxH + #notes * NOTE_H + 12 + BTN_H + 12
  if content.list ~= heldList then heldList, heldHeight = content.list, 0 end
  heldHeight = math.max(heldHeight, START_HEIGHT, needed)
  local height = heldHeight
  if math.abs(gfx.h / scale - height) > 1 then gfx.init("", W, height) end

  hits = {}
  setColor("#2B2B2B")
  gfx.rect(0, 0, gfx.w, gfx.h, 1)

  setFont(14)
  setColor("#EEEEEE")
  drawText(content.header, PAD, 12, W - 2 * PAD, 18, 4)

  setFont(13)
  setColor("#DDDDDD")
  for i, row in ipairs(content.rows) do
    local y = ROWS_Y + (i - 1) * ROW_H
    if type(row) == "table" then
      drawText(row[1], PAD, y, 28, ROW_H, 4)
      drawText(row[2], PAD + 28, y, 220, ROW_H, 4)
      drawText(row[3], W - PAD - 160, y, 160, ROW_H, 6)
    else
      drawText(row, PAD, y, W - 2 * PAD, ROW_H, 4)
    end
  end

  local y = ROWS_Y + #content.rows * ROW_H + 6
  if layout then
    drawBox(content.box, layout, y)
    y = y + boxH
  end
  setFont(12)
  setColor(status and "#DDDDDD" or "#999999")
  for i, line in ipairs(notes) do
    drawText(line, PAD, y + (i - 1) * NOTE_H, W - 2 * PAD, NOTE_H, 4)
  end

  y = height - 12 - BTN_H
  setFont(13)
  local count = #content.buttons
  local buttonW = (W - 2 * PAD - (count - 1) * 8) / count
  for i, b in ipairs(content.buttons) do
    if b.disabled then
      disabledButton(b.label, PAD + (i - 1) * (buttonW + 8), y, buttonW, BTN_H)
    else
      button(i, b.label, PAD + (i - 1) * (buttonW + 8), y, buttonW, BTN_H, i == 1 and count > 1, b.action)
    end
  end
end

local function hitAt(x, y)
  for i = #hits, 1, -1 do
    local hit = hits[i]
    if x >= hit.x and x < hit.x + hit.w and y >= hit.y and y < hit.y + hit.h then return hit end
  end
  return nil
end

local function loop()
  local char = gfx.getchar()
  if char < 0 or char == 27 or cut.anyRecording() or not cut.sameProject(proj, projectFile) then
    quit()
    return
  end

  if scan then stepScanning() end

  local now = reaper.GetProjectStateChangeCount(proj) .. "|" .. reaper.CountSelectedTracks2(proj, false) .. "|" .. reaper.CountTracks(proj)
  if now ~= signature then
    signature = now
    dirty = true
  end

  if char == 13 and content and content.enter then
    if content.buttons[content.enter].action() then
      quit()
      return
    end
    dirty = true
  end

  local x, y = gfx.mouse_x / scale, gfx.mouse_y / scale
  local down = (gfx.mouse_cap & 1) == 1
  if down and not wasDown then
    local hit = hitAt(x, y)
    pressedKey = hit and hit.key
  elseif wasDown and not down then
    local hit = hitAt(x, y)
    local key = pressedKey
    pressedKey = nil
    if hit and key and hit.key == key then
      if hit.action() then
        quit()
        return
      end
      dirty = true
    end
  end
  wasDown = down

  if dirty or gfx.w ~= lastW or gfx.h ~= lastH then
    draw()
    dirty = false
    lastW, lastH = gfx.w, gfx.h
  end

  gfx.update()
  reaper.defer(loop)
end

if reaper.set_action_options then reaper.set_action_options(3) end

local startContent = buildContent()
local startHeight = math.max(START_HEIGHT, ROWS_Y + #startContent.rows * ROW_H + 6 + #startContent.notes * NOTE_H + 12 + BTN_H + 12)
local mouseX, mouseY = reaper.GetMousePosition()
reaper.atexit(function() cut.stopScan(scan) end)
gfx.ext_retina = 1
gfx.init(TITLE, W, startHeight, 0, mouseX - W / 2, mouseY - startHeight / 2)
reaper.defer(loop)
