-- @description BSK Transport: LOCK TRACKS (lock or unlock every track's controls; never while recording, never locks in the plugin host)
-- @author BSK
-- @version 1.3
-- @about Lit after it locked every track (REAPER does not tell scripts a track is locked, so the light shows what the button last did, and follows an undo of it). Pressed: asks REAPER which tracks are locked (inside its one undo step), then unlocks every track when they are all locked, or locks every track otherwise. Locking disarms (REAPER cannot arm a locked track), so the unlock re-arms the tracks this button's lock disarmed. While recording it changes nothing and blinks to show it was blocked, because locking a track disarms it. In the plugin host a press only ever unlocks, for the same reason. With no tracks it does nothing. SAFE REC unlocks every track before it arms. One undo.

if reaper.set_action_options then reaper.set_action_options(3) end
reaper.defer(function() end)

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")

transport.lockTracks()
