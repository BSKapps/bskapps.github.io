-- @description BSK: PREVIEW ITEM
-- @author BSK
-- @version 1.0
-- @about First press previews the selected item and lights; the next press stops the preview and goes dark. Needs the SWS extension.

if reaper.set_action_options then reaper.set_action_options(3) end
reaper.defer(function() end)

local _, _, section, id = reaper.get_action_context()
local on = reaper.GetToggleCommandStateEx(section, id) == 1
local step = reaper.NamedCommandLookup(on and "_SWS_STOPPREVIEW" or "_XENAKIOS_ITEMASPCM1")
if step == 0 then
  reaper.ShowMessageBox("Failed to run Preview Item: the SWS extension is not installed.\n\nInstall SWS, then try again.", "Preview Item", 0)
  return
end
reaper.Main_OnCommand(step, 0)
reaper.SetToggleCommandState(section, id, on and 0 or 1)
reaper.RefreshToolbar2(section, id)
