-- @description BSK View: RECORD tab (shows the RECORD toolbar; opens the meter bridge and TIME LEFT if they are closed)
-- @author BSK
-- @version 1.1
-- @about Shows the RECORD toolbar first. Then, if the mixer is closed, it opens the meter bridge, and if TIME LEFT is closed (and was not hidden with its button) it opens that too. A mixer or TIME LEFT that is already open, docked or floating on another screen, stays exactly where it is. Lit while RECORD was the last tab pressed.

if reaper.set_action_options then reaper.set_action_options(3) end
reaper.defer(function() end)

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")

transport.recordTab()
