-- @description BSK Setup: PREP REC (sets REAPER for live recording)
-- @author BSK
-- @version 1.4
-- @about Checks eight REAPER settings that can spoil a live recording and sets the wrong ones: project length limit off, record mode normal, count-in before recording off, pre-roll before recording off, prompt to save/delete on stop off, new file every N MB off (one file per take), close audio device when stopped and inactive off (so a Stream Deck press with another app in front records straight away), automatic record-arm off on every track. Before: lists what will change and what is already set. After: lists what changed, read back from REAPER, and anything that failed to change. Also shows the audio device rate and block size, and lists what to check by hand (Prep Rec never changes these): block size under 128, device rate different from the project rate (when the project sets its own rate), media buffer under 600 ms, anticipative FX processing off, tracks with input FX switched on (new recordings on them include the effect; up to 5 named). Warns when the audio device follows the Mac's default (REAPER then quietly uses the Mac's own audio if the interface is off), and when armed tracks use inputs the audio device does not have. Also names where it records (Primary, Secondary or Dual) with each drive's recording time left until the low-space stop and its free space, and warns when a drive in use is not connected, has no path set, or has under 1 hour left. Refuses while playing or recording.

if reaper.set_action_options then reaper.set_action_options(3) end
reaper.defer(function() end)

if reaper.GetPlayState() & 5 ~= 0 then
  reaper.ShowMessageBox("Failed to prep: REAPER is playing or recording.\n\nStop first, then prep.", "Prep Rec", 0)
  return
end

if not reaper.SNM_SetIntConfigVar or not reaper.get_config_var_string then
  reaper.ShowMessageBox("Failed to prep: the SWS extension is not installed.", "Prep Rec", 0)
  return
end

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")
local tl = dofile(dir .. "BSK_Time_Left_Common.lua")

local function deviceNumber(name)
  local ok, value = reaper.GetAudioDeviceInfo(name)
  return ok and tonumber(value) or nil
end

local function kHz(rate)
  local k = rate / 1000
  return (k == math.floor(k) and string.format("%d", k) or string.format("%.1f", k)) .. " kHz"
end

local MODE_LABEL = { [tl.PRIMARY] = "Primary", [tl.SECONDARY] = "Secondary", [tl.DUAL] = "Dual" }
local DRIVE_LABEL = { "Primary", "Secondary" }

local function volumeOf(path)
  return path:match("^(/Volumes/[^/]+)")
end

local function mountedVolumes()
  local names = {}
  reaper.EnumerateSubdirectories("/Volumes", -1)
  local index = 0
  while true do
    local name = reaper.EnumerateSubdirectories("/Volumes", index)
    if not name then break end
    names[("/Volumes/" .. name):lower()] = true
    index = index + 1
  end
  return names
end

local function driveCheck(warn)
  if not reaper.GetFreeDiskSpaceForRecordPath then return nil end
  local mode = tl.storedMode() or tl.PRIMARY
  local paths = { tl.drivePaths() }
  local tracks, channels = tl.armedLoad()
  local _, cfg = reaper.GetSetProjectInfo_String(0, "RECORD_FORMAT", "", false)
  local perSecond = tl.bytesPerSecond(channels, tl.sampleRate(), (tl.recordBits(cfg)))
  local mounted = mountedVolumes()
  local status = {}
  for drive = 1, 2 do
    local path = paths[drive]
    local volume = volumeOf(path)
    if path == "" then
      status[drive] = "unset"
    elseif volume and not mounted[volume:lower()] then
      status[drive] = "missing"
    else
      status[drive] = "ok"
    end
  end
  local parts = {}
  for drive = 1, 2 do
    if tl.inUse(mode, drive) and status[drive] == "ok" then
      local volume = volumeOf(paths[drive])
      local name = volume and volume:match("^/Volumes/(.+)$") or "Mac"
      local freeMb = reaper.GetFreeDiskSpaceForRecordPath(0, drive - 1) or 0
      if freeMb <= 0 then
        parts[#parts + 1] = DRIVE_LABEL[drive] .. " " .. name .. " (free space unknown)"
      else
        local freeKb = freeMb * 1024
        local seconds = tracks > 0 and tl.secondsUntilStop(freeKb, perSecond) or nil
        parts[#parts + 1] = DRIVE_LABEL[drive] .. " " .. name .. (seconds and (" " .. tl.formatTime(seconds)) or "") .. " " .. tl.formatFree(freeKb)
        if seconds and seconds < tl.AMBER_BELOW then
          warn[#warn + 1] = "- " .. DRIVE_LABEL[drive] .. " drive: under 1 hour of recording left (" .. tl.formatTime(seconds) .. ")."
        end
      end
    end
  end
  for drive = 1, 2 do
    if tl.inUse(mode, drive) then
      local other = 3 - drive
      local switch = status[other] == "ok" and (", or press " .. DRIVE_LABEL[other] .. " Record") or ""
      if status[drive] == "missing" then
        warn[#warn + 1] = "- " .. DRIVE_LABEL[drive] .. " drive not connected: " .. volumeOf(paths[drive]) .. ". Plug it in" .. switch .. "."
      elseif status[drive] == "unset" then
        warn[#warn + 1] = "- No " .. DRIVE_LABEL[drive]:lower() .. " record path set. Set one in Project Settings > Media" .. switch .. "."
      end
    end
  end
  return "Recording to: " .. MODE_LABEL[mode] .. "." .. (#parts > 0 and (" " .. table.concat(parts, ", ")) or "")
end

local function audioCheck()
  local rate, block = deviceNumber("SRATE"), deviceNumber("BSIZE")
  local text = rate and block and ("Audio device: " .. kHz(rate) .. ", " .. math.floor(block) .. " samples") or "Audio device: not open"
  local warn = {}
  if transport.deviceFollowsMac() then
    warn[#warn + 1] = "- The audio device follows the Mac's default, so REAPER quietly uses the Mac's own audio if the interface is off. Pick your interface in Preferences > Audio > Device."
  end
  local missing = transport.missingInputsMessage(transport.missingInputs())
  if missing then warn[#warn + 1] = missing end
  local driveLine = driveCheck(warn)
  if driveLine then text = text .. "\n" .. driveLine end
  if block and block < 128 then
    warn[#warn + 1] = "- Block size " .. math.floor(block) .. " is low for a long multitrack record. 128 or more is safer. Preferences > Audio > Device."
  end
  local projectRate = reaper.GetSetProjectInfo(0, "PROJECT_SRATE", 0, false)
  if rate and reaper.GetSetProjectInfo(0, "PROJECT_SRATE_USE", 0, false) == 1 and projectRate > 0 and projectRate ~= rate then
    warn[#warn + 1] = "- The device runs at " .. kHz(rate) .. " and the project is set to " .. kHz(projectRate) .. ". Preferences > Audio > Device."
  end
  local buffer = transport.configInt("workbufmsex")
  if buffer and buffer < 600 then
    warn[#warn + 1] = "- Media buffer " .. math.floor(buffer) .. " ms is low for multitrack playback. 600 ms or more is safer. Preferences > Audio > Buffering."
  end
  local render = transport.configInt("workrender")
  if render and render & 1 == 0 then
    warn[#warn + 1] = "- Anticipative FX processing is off. Turning it on helps prevent dropouts. Preferences > Audio > Buffering."
  end
  local withInputFx = {}
  for t = 0, reaper.CountTracks(0) - 1 do
    local track = reaper.GetTrack(0, t)
    for fx = 0, reaper.TrackFX_GetRecCount(track) - 1 do
      if reaper.TrackFX_GetEnabled(track, 0x1000000 + fx) then
        local _, name = reaper.GetSetMediaTrackInfo_String(track, "P_NAME", "", false)
        withInputFx[#withInputFx + 1] = name ~= "" and ((t + 1) .. " " .. name) or tostring(t + 1)
        break
      end
    end
  end
  if #withInputFx > 0 then
    local shown = {}
    for i = 1, math.min(5, #withInputFx) do shown[i] = withInputFx[i] end
    local names = table.concat(shown, ", ") .. (#withInputFx > 5 and (" and " .. (#withInputFx - 5) .. " more") or "")
    warn[#warn + 1] = "- Input FX on " .. #withInputFx .. (#withInputFx == 1 and " track" or " tracks") .. ": " .. names .. ". New recordings on " .. (#withInputFx == 1 and "it" or "them") .. " will include the effect."
  end
  if #warn > 0 then
    text = text .. "\n\nCheck these yourself (Prep Rec does not change them):\n" .. table.concat(warn, "\n")
  end
  return text
end

local settings = transport.liveSettings()
local change, already = {}, {}
for _, setting in ipairs(settings) do
  if setting.wrong then change[#change + 1] = setting else already[#already + 1] = setting end
end

if #change == 0 then
  local lines = {}
  for _, setting in ipairs(settings) do lines[#lines + 1] = "- " .. setting.already end
  reaper.ShowMessageBox("Everything is already set for live recording:\n" .. table.concat(lines, "\n") .. "\n\n" .. audioCheck(), "Prep Rec", 0)
  return
end

local message = "Prep Rec sets REAPER for live recording:"
for _, setting in ipairs(change) do
  message = message .. "\n- " .. setting.label .. " (" .. setting.now .. ")"
end
if #already > 0 then
  message = message .. "\n\nAlready set:"
  for _, setting in ipairs(already) do message = message .. "\n- " .. setting.already end
end
message = message .. "\n\n" .. audioCheck() .. "\n\nContinue?"

if reaper.ShowMessageBox(message, "Prep Rec", 1) ~= 1 then return end

if reaper.GetPlayState() & 5 ~= 0 then
  reaper.ShowMessageBox("Failed to prep: REAPER started playing or recording.\n\nNothing was changed.", "Prep Rec", 0)
  return
end

local changed, failed = {}, {}
for _, setting in ipairs(change) do
  setting.fix()
  if setting.check() then changed[#changed + 1] = "- " .. setting.label else failed[#failed + 1] = "- " .. setting.label end
end

local done = "Prep Rec Complete"
if #changed > 0 then done = done .. "\n\nSettings changed: " .. #changed .. "\n" .. table.concat(changed, "\n") end
if #failed > 0 then done = done .. "\n\nFailed to change:\n" .. table.concat(failed, "\n") end
reaper.ShowMessageBox(done, "Prep Rec", 0)
