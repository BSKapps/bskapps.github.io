-- @description BSK Transport: ADD MARKER (drops a marker where you are; the button flashes so you know it went in)
-- @author BSK
-- @version 1.0
-- @about Runs REAPER's Insert marker at current position (the play position while playing or recording, the edit cursor when stopped) as one undo step, and flashes for half a second.

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")

transport.addMarker()
