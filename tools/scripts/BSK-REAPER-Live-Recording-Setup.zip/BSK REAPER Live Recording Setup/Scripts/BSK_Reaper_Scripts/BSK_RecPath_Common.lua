-- @description BSK Rec Path: shared logic (not an action)
-- @author BSK
-- @version 1.1
-- @about One record destination for the whole project: primary (Mac), secondary (external) or dual (both). Reads the real per-track setting so the toolbar lights never guess. Never reads a track that has plugins (track, input or take FX), so a plugin host is never touched whatever its file is called; those tracks still get the setting when a button sets every track.

local M = {}

M.SECTION = "BSK_RECPATH"
M.PRIMARY, M.SECONDARY, M.DUAL = 0, 1, 2
M.LABEL = { [0] = "PRIMARY", [1] = "SECONDARY", [2] = "DUAL" }
M.SET_ACTION = { [0] = 41321, [1] = 41322, [2] = 41323 }
M.BUTTON_ID = {
  [0] = "_RS862664600f87f39dd5d52e1c759c9a58fe21fdad",
  [1] = "_RS5a8bcdb4c18f49cdaa80e4711b399a58d9760870",
  [2] = "_RS1128c0deb4ca67b5e0e7582b41505069a206f293",
}
M.WATCH_ID = "_RSc33c09db3647fbb75a92022edef4d9d24ceb880e"

local SELECT_ALL_TRACKS = 40296
local UNSELECT_ALL_TRACKS = 40297

local function hasPlugins(track)
  if reaper.TrackFX_GetCount(track) > 0 or reaper.TrackFX_GetRecCount(track) > 0 then return true end
  for i = 0, reaper.CountTrackMediaItems(track) - 1 do
    local item = reaper.GetTrackMediaItem(track, i)
    for k = 0, reaper.CountTakes(item) - 1 do
      local take = reaper.GetTake(item, k)
      if take and reaper.TakeFX_GetCount(take) > 0 then return true end
    end
  end
  return false
end

function M.trackMode(track)
  if hasPlugins(track) then return nil end
  local ok, chunk = reaper.GetTrackStateChunk(track, "", false)
  if not ok then return nil end
  local value = chunk:match("\n%s*REC%s+%S+%s+%S+%s+%S+%s+%S+%s+%S+%s+%S+%s+(%-?%d+)")
  return tonumber(value)
end

function M.projectMode()
  local count = reaper.CountTracks(0)
  local mode, readable = nil, 0
  for i = 0, count - 1 do
    local track = reaper.GetTrack(0, i)
    if not hasPlugins(track) then
      local trackMode = M.trackMode(track)
      if trackMode == nil or (readable > 0 and trackMode ~= mode) then return nil, count, readable + 1 end
      mode, readable = trackMode, readable + 1
    end
  end
  return mode, count, readable
end

function M.isPluginHost()
  local _, file = reaper.EnumProjects(-1)
  return ((file or ""):match("[^/\\]*$") or ""):upper():find("PLUGIN HOST", 1, true) ~= nil
end

function M.storedMode()
  local ok, value = reaper.GetProjExtState(0, M.SECTION, "mode")
  local mode = ok == 1 and tonumber(value) or nil
  if M.LABEL[mode] then return mode end
  return nil
end

function M.armedTracksMatchFrom(mode, first, limit)
  local count, checked, i = reaper.CountTracks(0), 0, first
  while i < count do
    local track = reaper.GetTrack(0, i)
    i = i + 1
    if reaper.GetMediaTrackInfo_Value(track, "I_RECARM") == 1 and not hasPlugins(track) then
      if M.trackMode(track) ~= mode then return false, nil end
      checked = checked + 1
      if checked >= limit then return true, i < count and i or nil end
    end
  end
  return true, nil
end

function M.storeMode(mode)
  reaper.SetProjExtState(0, M.SECTION, "mode", tostring(mode))
end

function M.setLights(mode)
  for m = 0, 2 do
    local cmd = reaper.NamedCommandLookup(M.BUTTON_ID[m])
    if cmd ~= 0 then
      reaper.SetToggleCommandState(0, cmd, (mode == m) and 1 or 0)
      reaper.RefreshToolbar2(0, cmd)
    end
  end
end

function M.applyToAllTracks(mode)
  local count = reaper.CountTracks(0)
  if count == 0 then return end
  local selected = {}
  for i = 0, count - 1 do
    local track = reaper.GetTrack(0, i)
    if reaper.IsTrackSelected(track) then selected[#selected + 1] = track end
  end
  reaper.PreventUIRefresh(1)
  reaper.Undo_BeginBlock()
  reaper.Main_OnCommand(SELECT_ALL_TRACKS, 0)
  reaper.Main_OnCommand(M.SET_ACTION[mode], 0)
  reaper.Main_OnCommand(UNSELECT_ALL_TRACKS, 0)
  for _, track in ipairs(selected) do reaper.SetTrackSelected(track, true) end
  reaper.Undo_EndBlock("BSK Rec Path: " .. M.LABEL[mode], 1)
  reaper.PreventUIRefresh(-1)
  reaper.TrackList_AdjustWindows(false)
end

local function volumeMounted(volume)
  local want = volume:lower()
  reaper.EnumerateSubdirectories("/Volumes", -1)
  local index = 0
  while true do
    local name = reaper.EnumerateSubdirectories("/Volumes", index)
    if not name then return false end
    if ("/Volumes/" .. name):lower() == want then return true end
    index = index + 1
  end
end

function M.secondaryPathProblem()
  local _, path = reaper.GetSetProjectInfo_String(0, "RECORD_PATH_SECONDARY", "", false)
  if path == nil or path == "" then
    return "This project has no secondary record path set."
  end
  local volume = path:match("^(/Volumes/[^/]+)")
  if volume and not volumeMounted(volume) then
    return "Secondary record drive not found:\n" .. path
  end
  return nil
end

function M.sync()
  local actual, count, readable = M.projectMode()
  local stored = M.storedMode()
  if count == 0 or readable == 0 then
    M.setLights(stored)
    return
  end
  if stored == nil then
    if actual ~= nil then M.storeMode(actual) end
    M.setLights(actual)
    return
  end
  if actual ~= stored and reaper.GetPlayState() == 0 then
    M.applyToAllTracks(stored)
    actual = M.projectMode()
  end
  M.setLights(actual)
end

function M.choose(mode)
  if reaper.GetPlayState() & 4 == 4 then return end
  if M.isPluginHost() then
    M.setLights(nil)
    return
  end
  if mode ~= M.PRIMARY then
    local problem = M.secondaryPathProblem()
    if problem then
      local answer = reaper.ShowMessageBox(problem .. "\n\nSwitch to " .. M.LABEL[mode] .. " anyway?", "BSK Rec Path", 1)
      if answer ~= 1 then
        M.sync()
        return
      end
    end
  end
  M.storeMode(mode)
  if reaper.CountTracks(0) == 0 then
    M.setLights(mode)
    M.ensureWatch()
    return
  end
  M.applyToAllTracks(mode)
  local actual, _, readable = M.projectMode()
  if readable == 0 then actual = mode end
  M.setLights(actual)
  if actual ~= mode then
    reaper.ShowMessageBox("Failed to set every track to " .. M.LABEL[mode] .. ".\n\nThe Primary, Secondary and Dual Record lights stay off until every track records to the same place.", "BSK Rec Path", 0)
  end
  M.ensureWatch()
end

function M.watchAlive()
  local stamp = tonumber(reaper.GetExtState(M.SECTION, "alive"))
  return stamp ~= nil and (reaper.time_precise() - stamp) < 3
end

function M.ensureWatch()
  if M.watchAlive() then return end
  local cmd = reaper.NamedCommandLookup(M.WATCH_ID)
  if cmd ~= 0 then reaper.Main_OnCommand(cmd, 0) end
end

return M
