-- @description BSK View: TOOLS (menu of the Automation, Audition, Fade and Split floating toolbars)
-- @author BSK
-- @version 1.0
-- @about Shows Toolbar 10 TOOLS as a menu at the mouse: Automation Tools, Audition Tools, Fade Tools and Split Tools. Picking one that is closed opens that floating toolbar at the mouse; picking one that is open closes it. TOOLS is lit while any of the four is open. Needs REAPER 7.26 or newer.

if reaper.set_action_options then reaper.set_action_options(3) end
reaper.defer(function() end)

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")

transport.toolsMenu()
