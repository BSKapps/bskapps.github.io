-- @description BSK Transport: New Take (save and keep recording from here)
-- @author BSK
-- @version 1.3
-- @about Only while recording: stops and saves, then records a new take from the spot where it was pressed, with a marker, and flashes this button. Cancels a pending first DELETE REC press, so the new take is never deleted by one press. A press within 1 second of the last new take (counted from when its recording restarted), or of TAKE REC starting the recording, is ignored, so a double press never leaves a scrap take. Does nothing if not recording.

if reaper.set_action_options then reaper.set_action_options(3) end
reaper.defer(function() end)

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")

local state = reaper.GetPlayState()

if state & 4 == 0 then
  return
end

local now = reaper.time_precise()
local last = tonumber(reaper.GetExtState(transport.SECTION, "take_last"))
if last and now - last < 1 then
  return
end
reaper.SetExtState(transport.SECTION, "take_last", tostring(now), false)

local pressed = reaper.GetPlayPosition()

reaper.Main_OnCommand(40667, 0) -- Transport: Stop (save all recorded media)
reaper.DeleteExtState(transport.SECTION, transport.DELETE_ARMED_KEY, false)

local start = math.max(pressed, reaper.GetCursorPosition())

for t = 0, reaper.CountTracks(0) - 1 do
  local track = reaper.GetTrack(0, t)
  if reaper.GetMediaTrackInfo_Value(track, "I_RECARM") == 1 then
    local recorded = false
    for i = 0, reaper.CountTrackMediaItems(track) - 1 do
      local item = reaper.GetTrackMediaItem(track, i)
      local s = reaper.GetMediaItemInfo_Value(item, "D_POSITION")
      local e = s + reaper.GetMediaItemInfo_Value(item, "D_LENGTH")
      if s < pressed and math.abs(e - pressed) < 1 then recorded = true end
      if s < pressed and e > start and e < pressed + 1 then
        start = e
      end
    end
    if recorded then break end
  end
end

reaper.SetEditCurPos(start, false, false)
reaper.Main_OnCommand(1013, 0) -- Transport: Record
reaper.Main_OnCommand(40157, 0) -- Markers: Insert marker at current position

if reaper.GetPlayState() & 4 == 4 then
  reaper.SetExtState(transport.SECTION, "take_last", tostring(reaper.time_precise()), false)
  reaper.SetExtState(transport.SECTION, "take_flash", tostring(reaper.time_precise()), false)
  transport.setLight(transport.TAKE_ID, true)
  transport.ensureWatch()
end
