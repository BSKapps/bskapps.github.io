-- @description BSK Transport: LOOP AND PLAY ITEM SOLO (loop the time selection, or the selected item when there is none, with the selected tracks soloed; press again to stop)
-- @author BSK
-- @version 1.0
-- @about With a time selection: loops it from its start with the selected tracks soloed, leaving the selection as it is. With none, or when the time selection is only the one an earlier item audition left behind: sets the loop to the selected item, solos the selected tracks and loops it from the start. While recording it always loops the item. Lit from the press until playback stops. Pressed lit: stops, puts back the loop setting and any solo the press turned on, and keeps the selections. Does not light while recording.

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")

transport.audition("_RS48e324919a1d50d5f2f026b49bc221c98ec516a2")
