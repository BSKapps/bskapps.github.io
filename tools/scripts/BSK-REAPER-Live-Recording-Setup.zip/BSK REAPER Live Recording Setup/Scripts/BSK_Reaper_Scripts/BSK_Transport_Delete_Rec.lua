-- @description BSK Transport: DELETE REC (lit while recording; press twice to stop and delete the take; the button blinks after the first press and flashes when it deletes)
-- @author BSK
-- @version 1.1
-- @about Lit (orange) while recording, dark the rest of the time. While recording, the first press only makes the button blink fast for 3 seconds; a second press within those 3 seconds runs REAPER's Stop (delete all recorded media) and the button flashes for three quarters of a second. A single stray press never deletes a take. Not recording: one press is a plain stop.

if reaper.set_action_options then reaper.set_action_options(3) end
reaper.defer(function() end)

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")

transport.deleteRecording()
