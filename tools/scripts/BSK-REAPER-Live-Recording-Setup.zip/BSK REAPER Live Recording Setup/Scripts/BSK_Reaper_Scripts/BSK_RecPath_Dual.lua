-- @description BSK Rec Path: DUAL (record everything to the Mac and external drive together)
-- @author BSK
-- @version 1.0
-- @about Sets every track's record path to DUAL and lights only this button. The light is read back from the tracks.

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local recpath = dofile(dir .. "BSK_RecPath_Common.lua")

recpath.choose(recpath.DUAL)
