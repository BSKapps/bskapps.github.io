-- @description BSK Rec Path: background check (keeps the three lights true)
-- @author BSK
-- @version 1.1
-- @about Runs in the background, and starts itself afresh after an error (up to 3 times, then REAPER shows the error). Does nothing in a project whose file name contains PLUGIN HOST (its lights stay off there). Only while stopped: re-reads every track when the project, its file or the track count changed, and every 15 s after other changes checks the armed tracks, a few per tick. Keeps every track on the chosen record path; tracks with plugins (track, input or take FX) are set by the buttons but never read.

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local recpath = dofile(dir .. "BSK_RecPath_Common.lua")

if recpath.watchAlive() then return end

if reaper.set_action_options then reaper.set_action_options(2) end

local CHECK_EVERY = 1.0
local RECHECK_CONTENTS_EVERY = 15.0
local ARMED_TRACKS_PER_TICK = 4

local lastProject, lastFile, lastCount, lastChange = nil, nil, -1, -1
local nextCheck, nextContentsCheck = 0, 0
local pending = false
local checkFrom = nil

local function tick()
  local now = reaper.time_precise()
  reaper.SetExtState(recpath.SECTION, "alive", tostring(now), false)
  if now >= nextCheck then
    nextCheck = now + CHECK_EVERY
    local project, projectFile = reaper.EnumProjects(-1)
    local count = reaper.CountTracks(0)
    local change = reaper.GetProjectStateChangeCount(0)
    local stopped = reaper.GetPlayState() == 0
    if project ~= lastProject or projectFile ~= lastFile or count ~= lastCount then
      lastProject, lastFile, lastCount = project, projectFile, count
      pending = true
    end
    local pluginHost = recpath.isPluginHost()
    if stopped and pending then
      pending = false
      nextContentsCheck = now + RECHECK_CONTENTS_EVERY
      if pluginHost then
        recpath.setLights(nil)
      else
        recpath.sync()
      end
      lastChange = reaper.GetProjectStateChangeCount(0)
    elseif stopped and not pluginHost and change ~= lastChange and now >= nextContentsCheck then
      lastChange = change
      nextContentsCheck = now + RECHECK_CONTENTS_EVERY
      checkFrom = 0
    end
  end
  if checkFrom then
    local stored = recpath.storedMode()
    if reaper.GetPlayState() ~= 0 then
      checkFrom, lastChange, nextContentsCheck = nil, -1, 0
    elseif stored == nil or recpath.isPluginHost() then
      checkFrom = nil
    else
      local matches, nextFrom = recpath.armedTracksMatchFrom(stored, checkFrom, ARMED_TRACKS_PER_TICK)
      checkFrom = nextFrom
      if not matches then
        recpath.sync()
        lastChange = reaper.GetProjectStateChangeCount(0)
      end
    end
  end
end

local function loop()
  local ok, problem = pcall(tick)
  if ok then
    reaper.defer(loop)
  elseif (BSK_RECPATH_WATCH_RESTARTS or 0) < 3 then
    BSK_RECPATH_WATCH_RESTARTS = (BSK_RECPATH_WATCH_RESTARTS or 0) + 1
    reaper.DeleteExtState(recpath.SECTION, "alive", false)
    dofile(dir .. "BSK_RecPath_Watch.lua")
  else
    reaper.DeleteExtState(recpath.SECTION, "alive", false)
    error(problem, 0)
  end
end

reaper.atexit(function()
  reaper.DeleteExtState(recpath.SECTION, "alive", false)
  recpath.setLights(nil)
end)

loop()
