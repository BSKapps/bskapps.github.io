-- @description BSK Transport: LOOP AND PLAY ITEM SOLO, WHOLE ITEM (always loop the whole selected item with the selected tracks soloed; press again to stop)
-- @author BSK
-- @version 1.0
-- @about For the Control+Option+Space key. Sets the loop to the selected item, solos the selected tracks and loops it from the start, ignoring any time selection. Lights LOOP AND PLAY ITEM SOLO from the press until playback stops. Pressed while that button is lit: stops, puts back the loop setting and any solo the audition turned on, and keeps the selections. Does not light while recording.

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")

transport.audition("_RS48e324919a1d50d5f2f026b49bc221c98ec516a2", true)
