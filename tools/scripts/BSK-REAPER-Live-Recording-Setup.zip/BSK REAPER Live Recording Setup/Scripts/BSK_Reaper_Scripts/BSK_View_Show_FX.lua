-- @description BSK View: SHOW FX (float the plugins on the selected tracks; if one of theirs already floats, close every floating plugin window)
-- @author BSK
-- @version 1.1
-- @about Floats every plugin on the selected tracks (the master too when selected), even while other plugin windows are open. When a plugin on a selected track already floats, or nothing selected has plugins, closes every floating track and master plugin window instead. Lit while any track or master plugin window floats; closing them with their own close buttons turns it off. Item, input and container plugins are not counted.

if reaper.set_action_options then reaper.set_action_options(3) end
reaper.defer(function() end)

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")

transport.toggleFloatingFx()
