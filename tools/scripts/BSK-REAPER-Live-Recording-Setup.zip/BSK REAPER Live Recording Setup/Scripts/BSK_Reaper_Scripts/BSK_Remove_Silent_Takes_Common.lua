-- @description BSK: REMOVE SILENT TAKES shared logic (not an action)
-- @author BSK
-- @version 1.1
-- @about Used by BSK_Remove_Silent_Takes.lua. Settings, listening to each take from the peak files, and removing the silent ones with their files.

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local cut = dofile(dir .. "BSK_Cut_Silence_Common.lua")

local M = {}

M.SECTION = "BSK_REMOVE_SILENT_TAKES"
M.TITLE = "Remove Silent Takes"
M.PEAK_RATE = 20
M.BLOCK_SECONDS = 300
M.DEFAULT_DB = -45
M.MIN_DB = cut.MIN_DB
M.MAX_DB = cut.MAX_DB
M.SPOT_SECONDS = 0.1
M.PEAK_STALL = 10
M.UNDO_ITEMS = 4
M.TRASH = "/usr/bin/trash"
M.WHOLE_FILE_SLACK = 0.05
M.AUDIO_FILES = { wav = true, w64 = true, aif = true, aiff = true, flac = true, wv = true, caf = true }

M.failure = cut.failure
M.formatNumber = cut.formatNumber
M.anyRecording = cut.anyRecording
M.sameProject = cut.sameProject
M.trackLabel = cut.trackLabel
M.listenedTracks = cut.listenedTracks
M.clock = cut.clock
M.duration = cut.duration

function M.checkDb(db)
  if type(db) ~= "number" or db ~= db or db < M.MIN_DB or db > M.MAX_DB then
    return "Failed to change settings: enter Silent below (dB) as a number from -90 to -30."
  end
  return nil
end

function M.db()
  local db = tonumber(reaper.GetExtState(M.SECTION, "db"))
  if db == nil or M.checkDb(db) then return M.DEFAULT_DB end
  return db
end

function M.saveDb(db)
  reaper.SetExtState(M.SECTION, "db", cut.formatNumber(db), true)
end

function M.parseDb(text)
  local db = tonumber(((text or ""):gsub("^%s+", ""):gsub("%s+$", "")))
  local problem = M.checkDb(db)
  if problem then return nil, problem end
  return db
end

function M.blocked(proj, file)
  if cut.anyRecording() then return "REAPER is recording.", "Stop first, then try again." end
  local state = reaper.GetPlayStateEx(proj)
  if state & 2 == 2 then return "REAPER is paused.", "Stop first, then try again." end
  if state & 1 == 1 then return "REAPER is playing.", "Stop first, then try again." end
  if cut.isPluginHost(file) then
    return "this project's file name contains PLUGIN HOST.", "Remove Silent Takes does nothing in a plugin host project."
  end
  return nil
end

local function rootSource(source)
  while source do
    local parent = reaper.GetMediaSourceParent(source)
    if not parent then return source end
    source = parent
  end
  return nil
end

local function fileOf(take)
  local source = rootSource(reaper.GetMediaItemTake_Source(take))
  if not source then return "" end
  return reaper.GetMediaSourceFileName(source) or ""
end

local function offUnity(vol)
  vol = math.abs(vol)
  if vol <= 0 then return true end
  return math.abs(20 * math.log(vol, 10)) > cut.UNITY_DB
end

local function isReversed(take)
  local ok, _, _, reversed = reaper.PCM_Source_GetSectionInfo(reaper.GetMediaItemTake_Source(take))
  return ok and reversed
end

function M.checkable(item)
  if reaper.CountTakes(item) ~= 1 then return nil end
  local take = reaper.GetActiveTake(item)
  if not take or reaper.TakeIsMIDI(take) then return nil end
  if reaper.GetMediaItemInfo_Value(item, "C_LOCK") & 1 == 1 then return nil end
  local chanmode = reaper.GetMediaItemTakeInfo_Value(take, "I_CHANMODE")
  if chanmode ~= 0 and not (chanmode == 2 and reaper.GetMediaSourceNumChannels(reaper.GetMediaItemTake_Source(take)) == 1) then return nil end
  if math.abs(reaper.GetMediaItemTakeInfo_Value(take, "D_PLAYRATE") - 1) > cut.EPS then return nil end
  if reaper.GetTakeNumStretchMarkers(take) > 0 or isReversed(take) then return nil end
  if reaper.GetMediaItemInfo_Value(item, "B_LOOPSRC") == 1 then
    local offset = reaper.GetMediaItemTakeInfo_Value(take, "D_STARTOFFS")
    local sourceLength = reaper.GetMediaSourceLength(reaper.GetMediaItemTake_Source(take))
    if offset < -cut.EPS or offset + reaper.GetMediaItemInfo_Value(item, "D_LENGTH") > sourceLength + cut.EPS then return nil end
  end
  if offUnity(reaper.GetMediaItemInfo_Value(item, "D_VOL")) or offUnity(reaper.GetMediaItemTakeInfo_Value(take, "D_VOL")) then return nil end
  local file = fileOf(take)
  local extension = file:match("%.([^./\\]+)$")
  if not extension or not M.AUDIO_FILES[extension:lower()] or not M.fileSize(file) then return nil end
  return take, file
end

local buffers = {}
local function peakBuffer(channels)
  local buf = buffers[channels]
  if not buf then
    buf = reaper.new_array(channels * math.ceil(M.BLOCK_SECONDS * M.PEAK_RATE + 1) * 2)
    buffers[channels] = buf
  end
  return buf
end

local function readPeaks(take, at, channels, count)
  local buf = peakBuffer(channels)
  buf.clear()
  local got = reaper.GetMediaItemTake_Peaks(take, M.PEAK_RATE, at, channels, count, 0, buf)
  local size = channels * count
  return got, buf.table(1, size), buf.table(size + 1, size)
end

local function spotCheckSilent(take, length, threshold)
  local accessor = reaper.CreateTakeAudioAccessor(take)
  if not accessor then return false end
  local source = reaper.GetMediaItemTake_Source(take)
  local rate = math.floor(reaper.GetMediaSourceSampleRate(source) + 0.5)
  if rate <= 0 then rate = 48000 end
  local channels = math.max(1, reaper.GetMediaSourceNumChannels(source))
  local window = math.min(M.SPOT_SECONDS, length)
  local count = math.max(1, math.floor(rate * window))
  local first = reaper.GetAudioAccessorStartTime(accessor)
  local buf = reaper.new_array(count * channels)
  local silent = true
  for _, part in ipairs({ 0.25, 0.5, 0.75 }) do
    local start = math.max(0, math.min(length * part - window / 2, length - window))
    buf.clear()
    if reaper.GetAudioAccessorSamples(accessor, rate, channels, first + start, count, buf) <= 0 then
      silent = false
      break
    end
    for _, value in ipairs(buf.table(1, count * channels)) do
      if math.abs(value) >= threshold then
        silent = false
        break
      end
    end
    if not silent then break end
  end
  reaper.DestroyAudioAccessor(accessor)
  return silent
end

local function scanBody(scan, tracks, db)
  local proj = scan.proj
  local threshold = 10 ^ (db / 20)
  local found = {}

  local function due(track, item, take)
    if reaper.time_precise() < scan.deadline then return end
    coroutine.yield()
    if not reaper.ValidatePtr2(proj, track, "MediaTrack*")
      or (item and not reaper.ValidatePtr2(proj, item, "MediaItem*"))
      or (take and not reaper.ValidatePtr2(proj, take, "MediaItem_Take*")) then
      error({ changed = true })
    end
  end

  local function ensurePeaks(track, item, take)
    local source = reaper.GetMediaItemTake_Source(take)
    if reaper.PCM_Source_BuildPeaks(source, 0) == 0 then return end
    scan.building = source
    local ok, problem = pcall(function()
      local best, since = math.huge, reaper.time_precise()
      while true do
        local left = reaper.PCM_Source_BuildPeaks(source, 1)
        if left <= 0 then return end
        if left < best then
          best, since = left, reaper.time_precise()
        elseif reaper.time_precise() - since > M.PEAK_STALL then
          error({ unreadable = track })
        end
        local before = reaper.time_precise()
        due(track, item, take)
        since = since + (reaper.time_precise() - before)
      end
    end)
    scan.building = nil
    if reaper.ValidatePtr2(proj, source, "PCM_source*") then reaper.PCM_Source_BuildPeaks(source, 2) end
    if not ok then error(problem, 0) end
  end

  local function hasSound(track, item, take, from, to)
    local channels = math.max(1, reaper.GetMediaSourceNumChannels(reaper.GetMediaItemTake_Source(take)))
    local nonZero = false
    local at = from
    while at < to - cut.EPS do
      local blockEnd = math.min(to, at + M.BLOCK_SECONDS)
      local count = math.max(1, math.ceil((blockEnd - at) * M.PEAK_RATE - cut.EPS))
      local got, highs, lows = cut.outside(readPeaks, take, at, channels, count)
      local slices = cut.usableSlices(got, count, blockEnd >= to - cut.EPS)
      if not slices then error({ unreadable = track }) end
      for k = 1, channels * slices do
        local level = math.max(math.abs(highs[k]), math.abs(lows[k]))
        if level >= threshold then return true end
        if level ~= 0 then nonZero = true end
      end
      at = blockEnd
      due(track, item, take)
    end
    if not nonZero and not cut.outside(spotCheckSilent, take, to - from, threshold) then error({ unreadable = track }) end
    return false
  end

  for index, track in ipairs(tracks) do
    scan.done = index - 1
    for i = 0, reaper.CountTrackMediaItems(track) - 1 do
      local item = reaper.GetTrackMediaItem(track, i)
      local take, file = M.checkable(item)
      if take then
        local from = reaper.GetMediaItemInfo_Value(item, "D_POSITION")
        local length = reaper.GetMediaItemInfo_Value(item, "D_LENGTH")
        if length > cut.EPS then
          ensurePeaks(track, item, take)
          if not hasSound(track, item, take, from, from + length) then
            local source = reaper.GetMediaItemTake_Source(take)
            local offset = reaper.GetMediaItemTakeInfo_Value(take, "D_STARTOFFS")
            local whole = reaper.GetMediaSourceParent(source) == nil and offset >= -cut.EPS and offset <= M.WHOLE_FILE_SLACK
              and length >= reaper.GetMediaSourceLength(source) - M.WHOLE_FILE_SLACK
            found[#found + 1] = { track = track, item = item, take = take, file = file, pos = from, len = length, whole = whole }
          end
        end
      end
      due(track, item, nil)
    end
  end
  scan.done = #tracks
  return found
end

function M.startScan(proj, tracks, db)
  local scan = { proj = proj, total = #tracks, done = 0, deadline = 0 }
  scan.change = reaper.GetProjectStateChangeCount(proj)
  scan.co = coroutine.create(function() return scanBody(scan, tracks, db) end)
  return scan
end

M.stopScan = cut.stopScan

function M.stepScan(scan, budget)
  if reaper.GetProjectStateChangeCount(scan.proj) ~= scan.change then
    M.stopScan(scan)
    return "changed"
  end
  scan.deadline = reaper.time_precise() + budget
  local ok, result = cut.resume(scan.co)
  if not ok then
    if type(result) == "table" and result.unreadable then return "unreadable", result.unreadable end
    if type(result) == "table" and result.changed then return "changed" end
    return "error", tostring(result)
  end
  if coroutine.status(scan.co) == "dead" then return "done", result end
  return "running"
end

local function folderOf(path)
  return (path or ""):match("^(.*)[/\\][^/\\]*$")
end

local function sameFolder(file, folder)
  if not folder or folder == "" then return false end
  return (folderOf(file) or ""):lower() == folder:gsub("[/\\]+$", ""):lower()
end

M.KEPT_PART = "part of a longer recording"
M.KEPT_OTHER_TAKE = "used by another take"
M.KEPT_OTHER_PROJECT = "used by another project"
M.KEPT_OUTSIDE = "not in the project folder"

function M.fileSize(path)
  local handle = io.open(path, "rb")
  if not handle then return nil end
  local size = handle:seek("end")
  handle:close()
  return size
end

local function keepUsedInOpenProjects(removing, wanted)
  local p = 0
  while true do
    local other = reaper.EnumProjects(p)
    if not other then return end
    for i = 0, reaper.CountMediaItems(other) - 1 do
      local item = reaper.GetMediaItem(other, i)
      if not removing[item] then
        for t = 0, reaper.CountTakes(item) - 1 do
          local take = reaper.GetTake(item, t)
          if take then wanted[fileOf(take):lower()] = nil end
        end
      end
    end
    p = p + 1
  end
end

local SUBFOLDER_DEPTH = 3

local function listing(enumerate, folder)
  local names, i = {}, 0
  enumerate(folder, -1)
  while true do
    local name = enumerate(folder, i)
    if not name then return names end
    names[#names + 1] = name
    i = i + 1
  end
end

local function projectFilesIn(folder, depth, list)
  for _, name in ipairs(listing(reaper.EnumerateFiles, folder)) do
    if name:lower():match("%.rpp$") then list[#list + 1] = folder .. "/" .. name end
  end
  if depth >= SUBFOLDER_DEPTH or not reaper.EnumerateSubdirectories then return end
  for _, sub in ipairs(listing(reaper.EnumerateSubdirectories, folder)) do
    projectFilesIn(folder .. "/" .. sub, depth + 1, list)
  end
end

local function recentProjects(list)
  local ini = reaper.get_ini_file and reaper.get_ini_file()
  local handle = ini and io.open(ini, "r")
  if not handle then return end
  local inRecent = false
  for line in handle:lines() do
    local section = line:match("^%[(.-)%]")
    if section then
      inRecent = section == "Recent"
    elseif inRecent then
      local file = line:match("^recent%d+=(.-)%s*$")
      if file and file ~= "" then list[#list + 1] = file end
    end
  end
  handle:close()
end

local function keepNamedInOtherProjects(projectFile, paths, wanted)
  local seen = { [(projectFile or ""):lower()] = true }
  for _, path in ipairs(paths) do
    if next(wanted) == nil then return end
    local key = path:lower()
    if not seen[key] then
      seen[key] = true
      local handle = io.open(path, "rb")
      if handle then
        local text = handle:read("a")
        handle:close()
        text = text and text:lower() or ""
        for file in pairs(wanted) do
          if text:find(file:match("[^/\\]*$"), 1, true) then wanted[file] = nil end
        end
      end
    end
  end
end

function M.filesToTrash(proj, projectFile, found)
  local removing, wanted = {}, {}
  for _, entry in ipairs(found) do removing[entry.item] = true end
  for _, entry in ipairs(found) do
    local key = entry.file:lower()
    if wanted[key] == nil then wanted[key] = entry.file end
  end
  local reasons = {}
  local function keepGone(reason)
    for _, entry in ipairs(found) do
      local key = entry.file:lower()
      if wanted[key] == nil and reasons[key] == nil then reasons[key] = reason end
    end
  end
  for _, entry in ipairs(found) do
    if not entry.whole then wanted[entry.file:lower()] = nil end
  end
  keepGone(M.KEPT_PART)
  keepUsedInOpenProjects(removing, wanted)
  keepGone(M.KEPT_OTHER_TAKE)
  local projectFolder = folderOf(projectFile)
  local recordFolder = (reaper.GetProjectPathEx(proj) or ""):gsub("[/\\]+$", "")
  local folders = {}
  if projectFolder then folders[#folders + 1] = projectFolder end
  if recordFolder ~= "" and recordFolder:lower() ~= (projectFolder or ""):lower() then folders[#folders + 1] = recordFolder end
  if next(wanted) ~= nil then
    local paths = {}
    for _, folder in ipairs(folders) do projectFilesIn(folder, 0, paths) end
    recentProjects(paths)
    keepNamedInOtherProjects(projectFile, paths, wanted)
  end
  keepGone(M.KEPT_OTHER_PROJECT)
  local files = {}
  for _, file in pairs(wanted) do
    if sameFolder(file, recordFolder) or sameFolder(file, projectFolder) then files[file] = M.fileSize(file) end
  end
  for key, file in pairs(wanted) do
    if not files[file] then wanted[key] = nil end
  end
  keepGone(M.KEPT_OUTSIDE)
  return files, reasons
end

function M.size(bytes)
  if bytes <= 0 then return "0 MB" end
  if bytes >= 1e9 then return string.format("%.1f GB", bytes / 1e9) end
  if bytes >= 1e6 then return string.format("%d MB", math.floor(bytes / 1e6 + 0.5)) end
  return string.format("%d KB", math.max(1, math.floor(bytes / 1e3 + 0.5)))
end

function M.rows(found, files, reasons)
  local trashRows, keptRows, tracks, bytes, fileCount = {}, {}, {}, 0, 0
  local counted, sizes = {}, {}
  for file, size in pairs(files) do sizes[file:lower()] = size end
  for _, entry in ipairs(found) do
    local number = math.floor(reaper.GetMediaTrackInfo_Value(entry.track, "IP_TRACKNUMBER") + 0.5)
    local _, name = reaper.GetTrackName(entry.track)
    local key = entry.file:lower()
    local size = sizes[key]
    local row = { tostring(number), (name or ""):match("^%s*(.-)%s*$"), "take at " .. cut.clock(entry.pos), cut.duration(entry.len) }
    if size then
      row[5] = M.size(size)
      trashRows[#trashRows + 1] = row
    else
      row[5] = (reasons and reasons[key]) or M.KEPT_OUTSIDE
      row.stays = true
      keptRows[#keptRows + 1] = row
    end
    tracks[entry.track] = true
    if size and not counted[key] then
      counted[key] = true
      bytes = bytes + size
      fileCount = fileCount + 1
    end
  end
  local trackCount = 0
  for _ in pairs(tracks) do trackCount = trackCount + 1 end
  return trashRows, keptRows, trackCount, bytes, fileCount
end

local function quote(path)
  return "'" .. path:gsub("'", "'\\''") .. "'"
end

function M.remove(proj, found)
  reaper.PreventUIRefresh(1)
  reaper.Undo_BeginBlock2(proj)
  for _, entry in ipairs(found) do
    if reaper.ValidatePtr2(proj, entry.item, "MediaItem*") then reaper.DeleteTrackMediaItem(entry.track, entry.item) end
  end
  reaper.Undo_EndBlock2(proj, "Remove " .. #found .. (#found == 1 and " silent take" or " silent takes"), M.UNDO_ITEMS)
  reaper.PreventUIRefresh(-1)
  reaper.UpdateArrange()
end

function M.trash(files)
  local paths = {}
  for file in pairs(files) do
    paths[#paths + 1] = file
    local peaks = file .. ".reapeaks"
    if M.fileSize(peaks) then paths[#paths + 1] = peaks end
  end
  if #paths == 0 then return 0 end
  table.sort(paths)
  local parts = { M.TRASH }
  for _, path in ipairs(paths) do parts[#parts + 1] = quote(path) end
  os.execute(table.concat(parts, " "))
  local left = 0
  for file in pairs(files) do
    if M.fileSize(file) then left = left + 1 end
  end
  return left
end

return M
