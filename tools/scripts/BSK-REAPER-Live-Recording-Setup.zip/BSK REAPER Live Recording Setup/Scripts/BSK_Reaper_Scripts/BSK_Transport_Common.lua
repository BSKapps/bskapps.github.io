-- @description BSK Transport: shared logic for the SAFE REC, NEW TAKE, SAVE REC, DELETE REC, UNSOLO ALL, ARM ALL, LOCK TRACKS, MUTE ALL, REC MONITOR, SELECT ALL TRACKS, SELECT ALL ITEMS, OUTS FOLLOW FADERS, MIX DOWN, VSC UNITY, mixer view, Fade/Split/Audition/Automation Tools, SETUP/RECORD/VSC/EDIT tabs, TIME LEFT, MIDI SCENE, SHOW FX, FX CHAIN, track height, ZOOM PROJECT, FOLLOW PLAYHEAD, ICON and audition button lights (not an action)
-- @author BSK
-- @version 1.1
-- @about SAFE REC stays lit from its press until recording stops, including across NEW TAKE. NEW TAKE flashes when it starts a new take. SAVE REC and DELETE REC flash when they stop a recording. DELETE REC is lit while recording; there it needs a second press within 3 seconds to delete, and NEW TAKE cancels a pending first press. ADD MARKER flashes for a fifth of a second when it drops a marker. UNSOLO ALL lights while any track is soloed. ARM ALL lights while every track is armed and blinks slowly while only some are; it never disarms while recording. LOCK TRACKS asks REAPER which tracks are locked (REAPER does not report track locks to scripts, so inside its own undo step it uses Select all tracks that have controls locked and puts the selection back), then unlocks them all when all are locked or locks every track otherwise; locking disarms (REAPER cannot arm a locked track), so its unlock re-arms the tracks its own lock disarmed; in the plugin host a press only ever unlocks (locking disarms) and its light stays dark; elsewhere its light shows what it last did (and follows an undo of it) and never decides anything; it refuses while recording or with no tracks, and blinks fast. ARM ALL blinks fast when some tracks would not arm (locked tracks cannot be armed). SAFE REC unlocks every track before it arms, clears that light and forgets those disarmed tracks. MUTE ALL lights while every track is muted and blinks slowly while only some are. REC MONITOR does the same for record monitoring. SELECT ALL TRACKS lights while every track is selected, SELECT ALL ITEMS while every item is. OUTS FOLLOW FADERS lights while every hardware output is post-fader and blinks slowly while only some are; pressed again it puts the outputs back how they were, and it does nothing while recording. MIX DOWN lights while every track goes to the master and blinks slowly while only some do; it also shows the master track in the mixer and hides it again when MIX DOWN goes off (only if it was hidden before); pressed while blinking with no mixdown of its own to put back, it lists those tracks to take off the master. VSC UNITY is lit while what goes back to the console is as it went in: levels at 0 dB and centre, and the patch, mutes, solos, polarity, monitoring, master sends and playrate as they were when recording stopped, and no output switched to or from after the plugins on a track with a plugin playing (a stop while MIX DOWN is on keeps the setup from before); it is dark while anything changed and always lit in the plugin host. DEFAULT MIXER, STRIP MIXER and METER BRIDGE light while the mixer is open with their layout showing. Fade Tools, Split Tools, Audition Tools and Env Tools light while their floating toolbar is open; pressed unlit they open it at the mouse, pressed lit they close it. TOOLS lights while any of those four is open; pressed it shows Toolbar 10 TOOLS (Automation, Audition, Fade and Split Tools) as a menu at the mouse, and picking one does what that button does. The SETUP, RECORD, VSC and EDIT tabs light for the last tab pressed (REAPER does not tell scripts which toolbar is showing, so switching through the right-click menu is not seen). RECORD shows its toolbar, then opens the meter bridge if the mixer is closed and TIME LEFT if it is closed and was not hidden with its button; a mixer or TIME LEFT that is already open, docked or floating, stays exactly where it is. SETUP, VSC and EDIT hide the mixer if it is docked, leave a floating mixer where it is, then show their toolbar. TIME LEFT lights while its window is open; pressed it hides the window and keeps it hidden, or shows it again. MIDI SCENE lights while desk scene recalls are allowed to drive REAPER; pressed it switches them on or off and remembers it, also after a restart. SHOW FX lights while any track or master plugin window floats and FX CHAIN while any track or master FX chain window is open (item, input and container plugins are not counted); pressed they open them for the selected tracks that have plugins (FX CHAIN also opens a single selected track with none), and when one of those is already open, or there is nothing to open, they close every one. MIN, THIN, NORMAL and BIG set every track whose height is not locked to 25, 44, 175 or 351 px, whatever the zoom, and each lights only while every such track has exactly that height; when shrinking leaves the view below the tracks it scrolls back so they stay in sight. ZOOM PROJECT lights while the view is still the one its own press gave and the whole project still fits in it; pressed unlit it zooms out to the whole project, pressed lit it goes back to the previous zoom and scroll. FOLLOW PLAYHEAD lights while the view follows the play cursor in both playback and recording and blinks slowly while only one is on; pressed it turns both on, or both off when both are on. ICON lights while any track shows an icon; pressed lit it remembers every track's icon in the project and clears them, pressed dark it puts the remembered icons back and keeps remembering them, so an undo that clears them again can still be put back. AUDITION TIME SELECTION, LOOP TIME SELECTION and LOOP AND PLAY ITEM SOLO light from their press until playback stops, never while recording; pressed lit, they stop and put back the loop setting and any solo the audition turned on (across a switch from one audition button to another), keeping the selections. LOOP AND PLAY ITEM SOLO loops the time selection when there is one, the whole item when there is none or when the time selection is only the one an item audition left behind; its whole-item key always loops the whole item. While recording both run the item loop exactly as they always did. STOP AUDITION RESET also unselects every item and stops Preview Item.

local M = {}

M.SECTION = "BSK_TRANSPORT"
M.SAFE_ID = "_RS49df4c143990fd9f144444152fc737d840d1f4f7"
M.TAKE_ID = "_RSac9ea41db05d6de2abf9f86b3aa2f6ff20159cd1"
M.WATCH_ID = "_RS4eefd25da5887f6a53b44f499cdbe1f01244550b"
M.SAFE_ACTION = "_739195121d5140b082bd284064970dae"
M.SAVE_ID = "_RS92eea8930efc735b3713a25a8d2dcae5e8fcc0b9"
M.SAVE_ACTION = "_703a050ba1de4882a817cc7d335d6649"
M.DELETE_ID = "_RS9881009d2479fbff837d2273991f6da4641fb069"
M.DELETE_REC = 40668
M.MARKER_ID = "_RScccdc395518021a814634215e2d7bb30f0721a24"
M.INSERT_MARKER = 40157
M.MARKER_FLASH = 0.2
M.FLASH_BUTTONS = { M.SAVE_ID, M.DELETE_ID, M.MARKER_ID }
M.DELETE_ARMED_KEY = "delete_armed"
M.DELETE_ARM_FOR = 3
M.DELETE_BLINK_EVERY = 0.15
M.UNSOLO_ID = "_RS88e319d60aa035ad41ab1f5ae8a88170f37acfb0"
M.UNSOLO_ALL = 40340
M.ARM_ID = "_RS29e50f73cbc0707b7085cb9ca499d413e888b79c"
M.LOCK_TRACKS_ID = "_RScfd71cbd8eacff384304f2c2775ace863baa6415"
M.LOCK_TRACKS = 41312
M.UNLOCK_TRACKS = 41313
M.SELECT_LOCKED_TRACKS = 41324
M.BLOCKED_FOR = 0.6
M.BLOCKED_BLINK_EVERY = 0.1
M.ARM_ALL = 40490
M.UNARM_ALL = 40491
M.MUTE_ID = "_RS79e5f19e0738bc0e6c426f41be2303e19fa1db32"
M.MUTE_ALL = 40341
M.UNMUTE_ALL = 40339
M.MONITOR_ID = "_RSe9a85aee20f75aacc9e71369caee255f836207d9"
M.MONITOR_ON = "_a135ba1d63a8482a954871bdc7b0dfbb"
M.MONITOR_OFF = "_d5eeff6f7f8846a192651cdd4856deb1"
M.UNSELECT_ALL = 40297
M.SELECT_TRACKS_ID = "_RSaaede21e4c4b50bd9b7f48d9bb76dbbbb8fb8e92"
M.SELECT_ALL_TRACKS = 40296
M.SELECT_ITEMS_ID = "_RS266fdbcec09a509adda9d2c13e7b318d147d0ee6"
M.SELECT_ALL_ITEMS = 40182
M.UNSELECT_ALL_ITEMS = 40289
M.OUTS_ID = "_RS8988a0d7bc2905e0f7ab789ba1cca4d4e7da501d"
M.POST_FADER = 0
M.PRE_FX = 1
M.PRE_FADER_POST_FX = 3
M.MIX_ID = "_RSe5c2676baeb1ae6ac0bc5618222ced6bbe6fe089"
M.PRE_FADER_METERING = 42076
M.MIXER_MASTER = 41209
M.UNITY_ID = "_RSe482d6074ff1d897dde67b14c4969318e1a47e51"
M.UNITY_DB = 0.05
M.UNITY_PAN = 0.005
M.UNITY_LIST_MAX = 20
M.SETUP_KEY = "vsc_setup"
M.BLINK_EVERY = 0.5

M.TOGGLE_MIXER = 40078
M.TOGGLE_DOCK = 40083
M.DOCK_ID = "_RSf4c445cc74ddc4126ff23b88b7346c78dd78ef52"
M.KEEP_HIDDEN_FOR = 0.5
M.MIXER_BUTTONS = {
  { id = "_RS544c75f04508c4bbef32bc94f19a56107aa91d93", windowSet = 41698, layout = "aa - Standard" },
  { id = "_RScc10efdb05089327f969c7996d31558c4b9a5a54", windowSet = 41697, layout = "eb --- Strip Full Controls" },
  { id = "_RS22788612feb96b702b6837b6ac09ec0f74798cea", windowSet = 41696, layout = "ed --- Strip Meter Bridge" },
}
M.TOOLBAR_BUTTONS = {
  { id = "_RS9ec2cb96d75333d14a605fd3e4e896d537263093", openClose = 41684, atMouse = 41656 },
  { id = "_RSf4a7792e87c07276470f01fa46355d8393b82731", openClose = 41685, atMouse = 41657 },
  { id = "_RS6bb3fdfa03707986e1def28fe7e7a942bec8a7f1", openClose = 41683, atMouse = 41655 },
  { id = "_RS6409fbac8a8ddeb15f1989bd94c64915afe68e45", openClose = 41681, atMouse = 41113 },
}
M.TOOLS_ID = "_RS37dac6ac69624c85afc815dc0077538cd2b4796b"
M.TOOLS_MENU = 43410
M.TOOLS_MENU_NAME = "toolbars: show toolbar 10 as menu"
M.RECORD_TAB_ID = "_RS601abcb808e1787edd8399b59a3e661e92870633"
M.RECORD_TOOLBAR = 41650
M.VSC_TAB_ID = "_RS130a1a37bf0e6a56d96e45ef8d5cc3bb99b32cf1"
M.VSC_TOOLBAR = 41948
M.MIDI_SCENE_ID = "_RSa5dcb01b05e07b77da789df1f8a0869bb1885e92"
M.MIDI_SCENE_KEY = "midi_scene"
M.SETUP_TAB_ID = "_RS66c741d52cc343e604f64c5fb86939b8d0c273d2"
M.EDIT_TAB_ID = "_RS289682efa3276a10e88ebb5ca8fc087ab2046f5a"
M.TAB_KEY = "tab"
M.TABS = {
  { name = "SETUP", id = M.SETUP_TAB_ID, switch = 41646 },
  { name = "RECORD", id = M.RECORD_TAB_ID, switch = M.RECORD_TOOLBAR },
  { name = "VSC", id = M.VSC_TAB_ID, switch = M.VSC_TOOLBAR },
  { name = "EDIT", id = M.EDIT_TAB_ID, switch = 41105 },
}
M.TIME_LEFT_BUTTON_ID = "_RS5ed6157faec73f9ee35262c7de7045d30855bf0b"
M.TIME_LEFT_ID = "_RSd8fce357babe9736cdfaadb24ce5fc45d4f110a9"
M.TIME_LEFT_SECTION = "BSK_TIME_LEFT"
M.SHOW_FX_ID = "_RSd6e8c3ecb6edb25bd19b463f2efa2e0711c1dfa7"
M.FX_CHAIN_ID = "_RS6d53b3f1921997bcf463e110c4c1d2a6d77fcd48"
M.HEIGHT_BUTTONS = {
  { id = "_RS4c9a2d5ec92029af826ac3e1ac2c930e31d29920", kind = "min", px = 25 },
  { id = "_RSf91b075373663ccd915bbef0708e359ed2f40603", kind = "thin", px = 44 },
  { id = "_RS02b099eada4e3051ad457f425dbd3929060a737a", kind = "normal", px = 175 },
  { id = "_RSf06d0f80fa428a7d393e988086be91eec9deaa72", kind = "big", px = 351 },
}
M.SCROLL_SELECTED_INTO_VIEW = 40913
M.FOLLOW_ID = "_RS678edb201ca052aced4cf7f3966c185582e0280d"
M.FOLLOW_ACTIONS = { 40036, 40262 }
M.ZOOM_ID = "_RS29a329f21340fe322af077794140a7057fee080a"
M.ZOOM_PROJECT = 40295
M.ICONS_ID = "_RS3c4c00c1d93b0847922d5dd74b76552e66313e9d"
M.ICONS_KEY = "hidden_icons"
M.AUDITION_BUTTONS = {
  { id = "_RS78e2502909765363524f2a15f4a22d45a01bae3a", action = "_0e11144447e64d8b883f98dcfd0d7163" },
  { id = "_RS049bd08fa0260e9130d4186a245d209307741e35", action = "_a26f447ca26a421cbc2c22988a06b7d1" },
  { id = "_RS48e324919a1d50d5f2f026b49bc221c98ec516a2", action = "_1aed951c2a8640479d48ccca35c38ba2", selectionSolo = true },
}
M.AUDITION_RESET = "_0991b5ed9d9c4b998066527054fce23e"
M.PREVIEW_ITEM = "_RSd34b720fa3af67c626d14a6afaab6983aad373dc"
M.RECORD_MODE_NORMAL = 40252
M.AUDITION_KEY = "audition"
M.AUDITION_GRACE = 0.5
M.SET_REPEAT = "_SWS_SETREPEAT"
M.SOLO_SELECTED_TRACKS = 40728
M.GO_TO_TIME_SELECTION_START = 40630
M.PLAY = 1007

local function fold(s)
  return (s or ""):match("^%s*(.-)%s*$"):lower()
end

function M.setLight(id, on)
  local cmd = reaper.NamedCommandLookup(id)
  if cmd ~= 0 then
    reaper.SetToggleCommandState(0, cmd, on and 1 or 0)
    reaper.RefreshToolbar2(0, cmd)
  end
end

local function mixerShowing(button)
  if reaper.GetToggleCommandStateEx(0, M.TOGGLE_MIXER) ~= 1 then return false end
  local ok, layout = reaper.ThemeLayout_GetLayout("mcp", -1)
  return ok and fold(layout) == fold(button.layout)
end

function M.mixerLights()
  local docked = reaper.GetToggleCommandStateEx(0, M.TOGGLE_DOCK) == 1
  local dockCmd = reaper.NamedCommandLookup(M.DOCK_ID)
  if dockCmd ~= 0 and (reaper.GetToggleCommandStateEx(0, dockCmd) == 1) ~= docked then
    M.setLight(M.DOCK_ID, docked)
  end
  for _, button in ipairs(M.MIXER_BUTTONS) do
    local on = mixerShowing(button)
    local cmd = reaper.NamedCommandLookup(button.id)
    if cmd ~= 0 and (reaper.GetToggleCommandStateEx(0, cmd) == 1) ~= on then
      M.setLight(button.id, on)
    end
  end
end

function M.toolbarLights()
  local anyOpen = false
  for _, button in ipairs(M.TOOLBAR_BUTTONS) do
    local on = reaper.GetToggleCommandStateEx(0, button.openClose) == 1
    anyOpen = anyOpen or on
    local cmd = reaper.NamedCommandLookup(button.id)
    if cmd ~= 0 and (reaper.GetToggleCommandStateEx(0, cmd) == 1) ~= on then
      M.setLight(button.id, on)
    end
  end
  local tools = reaper.NamedCommandLookup(M.TOOLS_ID)
  if tools ~= 0 and (reaper.GetToggleCommandStateEx(0, tools) == 1) ~= anyOpen then
    M.setLight(M.TOOLS_ID, anyOpen)
  end
  M.tabLights()
end

local function syncLight(id, on)
  local cmd = reaper.NamedCommandLookup(id)
  if cmd ~= 0 and (reaper.GetToggleCommandStateEx(0, cmd) == 1) ~= on then
    M.setLight(id, on)
  end
end

function M.currentTab()
  return fold(reaper.GetExtState(M.SECTION, M.TAB_KEY)):upper()
end

function M.tabLights()
  local current = M.currentTab()
  for _, tab in ipairs(M.TABS) do
    syncLight(tab.id, current == tab.name)
  end
  syncLight(M.TIME_LEFT_BUTTON_ID, M.timeLeftAlive() and reaper.GetExtState(M.TIME_LEFT_SECTION, "close") == "")
end

function M.showTab(name)
  for _, tab in ipairs(M.TABS) do
    if tab.name == name then
      reaper.Main_OnCommand(tab.switch, 0)
      reaper.SetExtState(M.SECTION, M.TAB_KEY, name, true)
    end
  end
  M.tabLights()
end

local function fxTracks()
  local tracks = { reaper.GetMasterTrack(0) }
  for t = 0, reaper.CountTracks(0) - 1 do tracks[#tracks + 1] = reaper.GetTrack(0, t) end
  return tracks
end

local function anyFloating(tracks)
  for _, track in ipairs(tracks) do
    for fx = 0, reaper.TrackFX_GetCount(track) - 1 do
      if reaper.TrackFX_GetFloatingWindow(track, fx) then return true end
    end
  end
  return false
end

local function anyChain(tracks)
  for _, track in ipairs(tracks) do
    if reaper.TrackFX_GetChainVisible(track) ~= -1 then return true end
  end
  return false
end

function M.fxLights()
  local tracks = fxTracks()
  syncLight(M.SHOW_FX_ID, anyFloating(tracks))
  syncLight(M.FX_CHAIN_ID, anyChain(tracks))
end

local function selectedFxTracks(needFx)
  local list = {}
  for _, track in ipairs(fxTracks()) do
    if reaper.IsTrackSelected(track) and (not needFx or reaper.TrackFX_GetCount(track) > 0) then list[#list + 1] = track end
  end
  return list
end

local function heightTracks()
  local list = {}
  for t = 0, reaper.CountTracks(0) - 1 do
    local track = reaper.GetTrack(0, t)
    if reaper.GetMediaTrackInfo_Value(track, "B_HEIGHTLOCK") == 0 then list[#list + 1] = track end
  end
  return list
end

function M.heightLights()
  local tracks = heightTracks()
  local shared = tracks[1] and reaper.GetMediaTrackInfo_Value(tracks[1], "I_HEIGHTOVERRIDE")
  for i = 2, #tracks do
    if reaper.GetMediaTrackInfo_Value(tracks[i], "I_HEIGHTOVERRIDE") ~= shared then
      shared = nil
      break
    end
  end
  for _, button in ipairs(M.HEIGHT_BUTTONS) do
    syncLight(button.id, shared == button.px)
  end
end

local function projectKey()
  local project, file = reaper.EnumProjects(-1)
  return tostring(project) .. "|" .. (file or "")
end

local function onZoomView()
  local key, s, e = reaper.GetExtState(M.SECTION, "zoom_view"):match("^(.*);(%-?[%d%.]+);(%-?[%d%.]+)$")
  if key ~= projectKey() then return false end
  s, e = tonumber(s), tonumber(e)
  local startTime, endTime = reaper.GetSet_ArrangeView2(0, false, 0, 0)
  local slack = math.max(0.001, (e - s) * 0.005)
  return math.abs(startTime - s) <= slack and math.abs(endTime - e) <= slack and endTime >= reaper.GetProjectLength(0) - 0.001
end

function M.zoomLight()
  syncLight(M.ZOOM_ID, onZoomView())
end

local function followState()
  local on = 0
  for _, action in ipairs(M.FOLLOW_ACTIONS) do
    if reaper.GetToggleCommandStateEx(0, action) == 1 then on = on + 1 end
  end
  if on == 0 then return "none" end
  return on == #M.FOLLOW_ACTIONS and "all" or "some"
end

local function trackState(key)
  local count, on = reaper.CountTracks(0), 0
  for i = 0, count - 1 do
    if reaper.GetMediaTrackInfo_Value(reaper.GetTrack(0, i), key) ~= 0 then on = on + 1 end
  end
  if on == 0 then return "none" end
  return on == count and "all" or "some"
end

local function allTracksSelected()
  local count = reaper.CountTracks(0)
  return count > 0 and reaper.CountSelectedTracks(0) == count
end

local function allItemsSelected()
  local count = reaper.CountMediaItems(0)
  return count > 0 and reaper.CountSelectedMediaItems(0) == count
end

local function outsState()
  local total, post = 0, 0
  for t = 0, reaper.CountTracks(0) - 1 do
    local track = reaper.GetTrack(0, t)
    for s = 0, reaper.GetTrackNumSends(track, 1) - 1 do
      total = total + 1
      if reaper.GetTrackSendInfo_Value(track, 1, s, "I_SENDMODE") == M.POST_FADER then post = post + 1 end
    end
  end
  if post == 0 then return "none", total end
  return post == total and "all" or "some", total
end

local function blinkLit(state)
  if state == "some" then return math.floor(reaper.time_precise() / M.BLINK_EVERY) % 2 == 0 end
  return state == "all"
end

local function blockedLit(id)
  local started = tonumber(reaper.GetExtState(M.SECTION, "blocked" .. id))
  if not started then return nil end
  local age = reaper.time_precise() - started
  if age < 0 or age >= M.BLOCKED_FOR then
    reaper.DeleteExtState(M.SECTION, "blocked" .. id, false)
    return nil
  end
  return math.floor(age / M.BLOCKED_BLINK_EVERY) % 2 == 0
end

function M.blocked(id)
  reaper.SetExtState(M.SECTION, "blocked" .. id, tostring(reaper.time_precise()), false)
  M.ensureWatch()
end

function M.blinkLights(states)
  for id, state in pairs(states) do
    local blocked = blockedLit(id)
    if blocked ~= nil then syncLight(id, blocked) else syncLight(id, blinkLit(state)) end
  end
end

local function lockState()
  if M.isPluginHost() then return "none" end
  local redo = reaper.Undo_CanRedo2(0)
  if redo == "Lock all tracks" then return "none" end
  if redo == "Unlock all tracks" then return "all" end
  local ok, value = reaper.GetProjExtState(0, M.SECTION, "tracks_locked")
  return (ok == 1 and value == "1") and "all" or "none"
end
M.lockState = lockState

function M.trackLights()
  syncLight(M.UNSOLO_ID, reaper.AnyTrackSolo(0))
  syncLight(M.SELECT_TRACKS_ID, allTracksSelected())
  syncLight(M.SELECT_ITEMS_ID, allItemsSelected())
  local states = { [M.LOCK_TRACKS_ID] = lockState(), [M.ARM_ID] = trackState("I_RECARM"), [M.MUTE_ID] = trackState("B_MUTE"), [M.MONITOR_ID] = trackState("I_RECMON"), [M.OUTS_ID] = (outsState()), [M.MIX_ID] = trackState("B_MAINSEND"), [M.FOLLOW_ID] = followState() }
  M.blinkLights(states)
  return states
end

local function afterTrackPress()
  M.trackLights()
  reaper.SetExtState(M.SECTION, "tracks_changed", "1", false)
  M.ensureWatch()
end

function M.unsoloAll()
  reaper.Undo_BeginBlock()
  reaper.Main_OnCommand(M.UNSOLO_ALL, 0)
  reaper.Undo_EndBlock("Unsolo all tracks", 1)
  afterTrackPress()
end

local function keepSelection(fn)
  local selected = {}
  for i = 0, reaper.CountTracks(0) - 1 do
    local track = reaper.GetTrack(0, i)
    if reaper.IsTrackSelected(track) then selected[#selected + 1] = track end
  end
  local master = reaper.GetMasterTrack(0)
  local masterSelected = master and reaper.IsTrackSelected(master)
  local result = fn()
  reaper.Main_OnCommand(M.UNSELECT_ALL, 0)
  for _, track in ipairs(selected) do reaper.SetTrackSelected(track, true) end
  if masterSelected then reaper.SetTrackSelected(master, true) end
  return result
end

local function onEveryTrack(cmd)
  keepSelection(function()
    reaper.Main_OnCommand(M.SELECT_ALL_TRACKS, 0)
    reaper.Main_OnCommand(cmd, 0)
  end)
end

local function lockedTracks()
  return keepSelection(function()
    reaper.Main_OnCommand(M.UNSELECT_ALL, 0)
    reaper.Main_OnCommand(M.SELECT_LOCKED_TRACKS, 0)
    local guids = {}
    for i = 0, reaper.CountSelectedTracks(0) - 1 do guids[#guids + 1] = reaper.GetTrackGUID(reaper.GetSelectedTrack(0, i)) end
    return guids
  end)
end

local function armedGuids(locked)
  local guids = {}
  local ok, before = reaper.GetProjExtState(0, M.SECTION, "armed_before_lock")
  if ok == 1 then
    for _, guid in ipairs(locked) do
      if before:find(guid, 1, true) then guids[#guids + 1] = guid end
    end
  end
  for i = 0, reaper.CountTracks(0) - 1 do
    local track = reaper.GetTrack(0, i)
    if reaper.GetMediaTrackInfo_Value(track, "I_RECARM") == 1 then guids[#guids + 1] = reaper.GetTrackGUID(track) end
  end
  return table.concat(guids, " ")
end

local function rearmLockedOut()
  local ok, value = reaper.GetProjExtState(0, M.SECTION, "armed_before_lock")
  if ok ~= 1 or value == "" then return end
  for i = 0, reaper.CountTracks(0) - 1 do
    local track = reaper.GetTrack(0, i)
    if value:find(reaper.GetTrackGUID(track), 1, true) then reaper.SetMediaTrackInfo_Value(track, "I_RECARM", 1) end
  end
  reaper.SetProjExtState(0, M.SECTION, "armed_before_lock", "")
end

function M.lockTracks()
  local count = reaper.CountTracks(0)
  if reaper.GetPlayState() & 4 == 4 or count == 0 then
    M.blocked(M.LOCK_TRACKS_ID)
    return
  end
  reaper.PreventUIRefresh(1)
  reaper.Undo_BeginBlock()
  local host = M.isPluginHost()
  local locked = not host and lockedTracks() or {}
  local unlock = host or #locked == count
  local armed = not unlock and armedGuids(locked)
  onEveryTrack(unlock and M.UNLOCK_TRACKS or M.LOCK_TRACKS)
  if unlock then rearmLockedOut() end
  reaper.Undo_EndBlock(unlock and "Unlock all tracks" or "Lock all tracks", 1)
  reaper.PreventUIRefresh(-1)
  reaper.SetProjExtState(0, M.SECTION, "tracks_locked", unlock and "" or "1")
  if armed then reaper.SetProjExtState(0, M.SECTION, "armed_before_lock", armed) end
  afterTrackPress()
end

function M.unlockAllTracks()
  onEveryTrack(M.UNLOCK_TRACKS)
  local ok, value = reaper.GetProjExtState(0, M.SECTION, "tracks_locked")
  if ok == 1 and value ~= "" then reaper.SetProjExtState(0, M.SECTION, "tracks_locked", "") end
  ok, value = reaper.GetProjExtState(0, M.SECTION, "armed_before_lock")
  if ok == 1 and value ~= "" then reaper.SetProjExtState(0, M.SECTION, "armed_before_lock", "") end
end

function M.armAll()
  local all = trackState("I_RECARM") == "all"
  if not (all and reaper.GetPlayState() & 4 == 4) then
    reaper.Undo_BeginBlock()
    reaper.Main_OnCommand(all and M.UNARM_ALL or M.ARM_ALL, 0)
    reaper.Undo_EndBlock(all and "Unarm all tracks" or "Arm all tracks", 1)
    if not all and reaper.CountTracks(0) > 0 and trackState("I_RECARM") ~= "all" then M.blocked(M.ARM_ID) end
  end
  afterTrackPress()
end

function M.muteAll()
  local all = trackState("B_MUTE") == "all"
  reaper.Undo_BeginBlock()
  reaper.Main_OnCommand(all and M.UNMUTE_ALL or M.MUTE_ALL, 0)
  reaper.Undo_EndBlock(all and "Unmute all tracks" or "Mute all tracks", 1)
  afterTrackPress()
end

function M.selectAllTracks()
  local all = allTracksSelected()
  reaper.Undo_BeginBlock()
  reaper.Main_OnCommand(all and M.UNSELECT_ALL or M.SELECT_ALL_TRACKS, 0)
  reaper.Undo_EndBlock(all and "Unselect all tracks" or "Select all tracks", 1)
  afterTrackPress()
end

function M.selectAllItems()
  local all = allItemsSelected()
  reaper.Undo_BeginBlock()
  reaper.Main_OnCommand(all and M.UNSELECT_ALL_ITEMS or M.SELECT_ALL_ITEMS, 0)
  reaper.Undo_EndBlock(all and "Unselect all items" or "Select all items", 4)
  afterTrackPress()
end

function M.auditionLights()
  local id, started = reaper.GetExtState(M.SECTION, M.AUDITION_KEY):match("^(.-);([%d%.]+)$")
  started = tonumber(started)
  if started then
    local state = reaper.GetPlayState()
    local stopped = state & 3 == 0 and reaper.time_precise() - started > M.AUDITION_GRACE
    if state & 4 == 4 or stopped then
      reaper.DeleteExtState(M.SECTION, M.AUDITION_KEY, false)
      reaper.DeleteExtState(M.SECTION, M.AUDITION_KEY .. "_undo", false)
      id = nil
    end
  else
    id = nil
  end
  for _, button in ipairs(M.AUDITION_BUTTONS) do
    syncLight(button.id, button.id == id)
  end
end

local function auditionStop()
  reaper.Main_OnCommand(1016, 0)
  local repeatWas, soloed = reaper.GetExtState(M.SECTION, M.AUDITION_KEY .. "_undo"):match("^(%d);(.*)$")
  if repeatWas then
    reaper.Undo_BeginBlock()
    reaper.GetSetRepeat(tonumber(repeatWas))
    local guids = {}
    for guid in soloed:gmatch("[^,]+") do guids[guid] = true end
    for i = 0, reaper.CountTracks(0) - 1 do
      local track = reaper.GetTrack(0, i)
      if guids[reaper.GetTrackGUID(track)] then reaper.SetMediaTrackInfo_Value(track, "I_SOLO", 0) end
    end
    reaper.Undo_EndBlock("Stop audition", 1)
  end
  reaper.DeleteExtState(M.SECTION, M.AUDITION_KEY, false)
  reaper.DeleteExtState(M.SECTION, M.AUDITION_KEY .. "_undo", false)
  M.auditionLights()
end

local function itemAuditionRange()
  local startTime, endTime = reaper.GetSet_LoopTimeRange(false, false, 0, 0, false)
  return string.format("%.9f;%.9f", startTime, endTime)
end

local function loopSelectionSolo()
  local startTime, endTime = reaper.GetSet_LoopTimeRange(false, false, 0, 0, false)
  if endTime <= startTime then return false end
  if reaper.GetExtState(M.SECTION, M.AUDITION_KEY .. "_item_range") == itemAuditionRange() then return false end
  local setRepeat = reaper.NamedCommandLookup(M.SET_REPEAT)
  if setRepeat == 0 then return false end
  reaper.GetSet_LoopTimeRange(true, true, startTime, endTime, false)
  reaper.Main_OnCommand(setRepeat, 0)
  reaper.Main_OnCommand(M.SOLO_SELECTED_TRACKS, 0)
  reaper.Main_OnCommand(M.GO_TO_TIME_SELECTION_START, 0)
  reaper.Main_OnCommand(M.PLAY, 0)
  return true
end

function M.audition(id, wholeItem)
  for _, button in ipairs(M.AUDITION_BUTTONS) do
    if button.id == id then
      local cmd = reaper.NamedCommandLookup(button.action)
      if cmd == 0 then return end
      M.auditionLights()
      local litId = reaper.GetExtState(M.SECTION, M.AUDITION_KEY):match("^(.-);")
      if litId == id then
        auditionStop()
        return
      end
      local wasRecording = reaper.GetPlayState() & 4 == 4
      local repeatWas = reaper.GetSetRepeat(-1) == 1 and "1" or "0"
      local soloed = {}
      if litId then
        local keptRepeat, keptSoloed = reaper.GetExtState(M.SECTION, M.AUDITION_KEY .. "_undo"):match("^(%d);(.*)$")
        if keptRepeat then
          repeatWas = keptRepeat
          for guid in keptSoloed:gmatch("[^,]+") do soloed[#soloed + 1] = guid end
        end
      end
      local soloWas = {}
      if not wasRecording then
        for i = 0, reaper.CountTracks(0) - 1 do
          local track = reaper.GetTrack(0, i)
          soloWas[track] = reaper.GetMediaTrackInfo_Value(track, "I_SOLO")
        end
      end
      local usedSelection = not wasRecording and button.selectionSolo and not wholeItem and loopSelectionSolo()
      if not usedSelection then reaper.Main_OnCommand(cmd, 0) end
      if wasRecording or reaper.GetPlayState() & 4 == 4 then return end
      if button.selectionSolo and not usedSelection then
        reaper.SetExtState(M.SECTION, M.AUDITION_KEY .. "_item_range", itemAuditionRange(), false)
      end
      for track, was in pairs(soloWas) do
        if was == 0 and reaper.ValidatePtr(track, "MediaTrack*") and reaper.GetMediaTrackInfo_Value(track, "I_SOLO") ~= 0 then
          soloed[#soloed + 1] = reaper.GetTrackGUID(track)
        end
      end
      reaper.SetExtState(M.SECTION, M.AUDITION_KEY, id .. ";" .. tostring(reaper.time_precise()), false)
      reaper.SetExtState(M.SECTION, M.AUDITION_KEY .. "_undo", repeatWas .. ";" .. table.concat(soloed, ","), false)
      M.auditionLights()
      M.ensureWatch()
    end
  end
end

function M.auditionReset()
  if reaper.GetPlayState() & 4 == 4 then return end
  local reset = reaper.NamedCommandLookup(M.AUDITION_RESET)
  if reset ~= 0 then reaper.Main_OnCommand(reset, 0) end
  reaper.Undo_BeginBlock()
  reaper.Main_OnCommand(M.UNSELECT_ALL_ITEMS, 0)
  local preview = reaper.NamedCommandLookup(M.PREVIEW_ITEM)
  if preview ~= 0 and reaper.GetToggleCommandStateEx(0, preview) == 1 then
    reaper.Main_OnCommand(preview, 0)
  end
  reaper.Undo_EndBlock("Unselect all items", 4)
  reaper.DeleteExtState(M.SECTION, M.AUDITION_KEY, false)
  reaper.DeleteExtState(M.SECTION, M.AUDITION_KEY .. "_undo", false)
  M.auditionLights()
end

local function sendKeys(track)
  local keys, seen = {}, {}
  local guid = reaper.GetTrackGUID(track)
  for s = 0, reaper.GetTrackNumSends(track, 1) - 1 do
    local dst = math.floor(reaper.GetTrackSendInfo_Value(track, 1, s, "I_DSTCHAN"))
    seen[dst] = (seen[dst] or 0) + 1
    keys[s + 1] = guid .. ":" .. dst .. ":" .. seen[dst]
  end
  return keys
end

local function savedOutModes()
  local modes, any = {}, false
  local ok, value = reaper.GetProjExtState(0, M.SECTION, "outs_modes")
  if ok == 1 then
    for key, mode in value:gmatch("([^;=]+)=(%d+)") do
      modes[key] = tonumber(mode)
      any = true
    end
  end
  return modes, any
end

local function liveOutModes()
  local saved, any = savedOutModes()
  if not any then return nil end
  for t = 0, reaper.CountTracks(0) - 1 do
    local track = reaper.GetTrack(0, t)
    for s, key in ipairs(sendKeys(track)) do
      local was = saved[key]
      if was and was ~= M.POST_FADER and reaper.GetTrackSendInfo_Value(track, 1, s - 1, "I_SENDMODE") == M.POST_FADER then return saved end
    end
  end
  return nil
end

local function rememberOutModes()
  local parts = {}
  for t = 0, reaper.CountTracks(0) - 1 do
    local track = reaper.GetTrack(0, t)
    for s, key in ipairs(sendKeys(track)) do
      parts[#parts + 1] = key .. "=" .. math.floor(reaper.GetTrackSendInfo_Value(track, 1, s - 1, "I_SENDMODE"))
    end
  end
  reaper.SetProjExtState(0, M.SECTION, "outs_modes", table.concat(parts, ";"))
end

local applyMeters

function M.outsFollowFaders()
  if reaper.GetPlayState() & 4 == 4 then return end
  local state, total = outsState()
  if total == 0 then
    reaper.ShowMessageBox("No track has a hardware output.", "Outs Follow Faders", 0)
    return
  end
  local saved = liveOutModes()
  local back = saved ~= nil or state == "all"
  local question
  if saved then
    question = "Put every track's outputs back how they were before they followed the faders?\n\nEach output goes back to its own setting from before. The meters go back to how they were, unless MIX DOWN is on."
  elseif back then
    question = "Switch every track's outputs to pre-fader?\n\nFaders and pan will no longer change what goes out."
  else
    question = "Switch every track's outputs to follow the faders?\n\nFaders and pan will change what goes out. The meters show post-fader to match."
  end
  if reaper.ShowMessageBox(question, back and "Turn Off Outs Follow Faders" or "Outs Follow Faders", 1) ~= 1 then return end
  if not back then rememberOutModes() end
  reaper.PreventUIRefresh(1)
  reaper.Undo_BeginBlock()
  for t = 0, reaper.CountTracks(0) - 1 do
    local track = reaper.GetTrack(0, t)
    for s, key in ipairs(sendKeys(track)) do
      local mode = M.POST_FADER
      if saved then
        mode = saved[key]
      elseif back then
        mode = M.PRE_FADER_POST_FX
      end
      if mode then reaper.SetTrackSendInfo_Value(track, 1, s - 1, "I_SENDMODE", mode) end
    end
  end
  local undoName = "Outputs follow faders"
  if saved then undoName = "Outputs back as they were" elseif back then undoName = "Outputs pre-fader" end
  reaper.Undo_EndBlock(undoName, 1)
  reaper.PreventUIRefresh(-1)
  if saved then reaper.SetProjExtState(0, M.SECTION, "outs_modes", "") end
  applyMeters()
  afterTrackPress()
end

local function mixMemory()
  local tracks, sends, metering, master = {}, {}, nil, nil
  local ok, value = reaper.GetProjExtState(0, M.SECTION, "mix_state")
  if ok ~= 1 or value == "" then return nil end
  for entry in value:gmatch("[^;]+") do
    local kind, key, rest = entry:match("^(%a)([^=]*)=(.*)$")
    if kind == "T" then
      local main, mon = rest:match("^(%-?%d+),(%-?%d+)$")
      tracks[key] = { main = tonumber(main), mon = tonumber(mon) }
    elseif kind == "S" then
      sends[key] = tonumber(rest)
    elseif kind == "M" then
      metering = tonumber(rest)
    elseif kind == "V" then
      master = tonumber(rest)
    end
  end
  return { tracks = tracks, sends = sends, metering = metering, master = master }
end

local function inMixState(track, keys)
  if reaper.GetMediaTrackInfo_Value(track, "B_MAINSEND") ~= 1 or reaper.GetMediaTrackInfo_Value(track, "I_RECMON") ~= 0 then return false end
  for s = 1, #keys do
    if reaper.GetTrackSendInfo_Value(track, 1, s - 1, "B_MUTE") ~= 1 then return false end
  end
  return true
end

local function liveMixMemory()
  local memory = mixMemory()
  if not memory then return nil end
  for t = 0, reaper.CountTracks(0) - 1 do
    local track = reaper.GetTrack(0, t)
    local was = memory.tracks[reaper.GetTrackGUID(track)]
    if was then
      local keys = sendKeys(track)
      local wasMixing = was.main == 1 and was.mon == 0
      for _, key in ipairs(keys) do
        if memory.sends[key] ~= nil and memory.sends[key] ~= 1 then wasMixing = false end
      end
      if not wasMixing and inMixState(track, keys) then return memory end
    end
  end
  return nil
end

local function rememberMix()
  local parts = { "V=" .. reaper.GetToggleCommandStateEx(0, M.MIXER_MASTER) }
  for t = 0, reaper.CountTracks(0) - 1 do
    local track = reaper.GetTrack(0, t)
    parts[#parts + 1] = "T" .. reaper.GetTrackGUID(track) .. "=" .. math.floor(reaper.GetMediaTrackInfo_Value(track, "B_MAINSEND")) .. "," .. math.floor(reaper.GetMediaTrackInfo_Value(track, "I_RECMON"))
    for s, key in ipairs(sendKeys(track)) do
      parts[#parts + 1] = "S" .. key .. "=" .. math.floor(reaper.GetTrackSendInfo_Value(track, 1, s - 1, "B_MUTE"))
    end
  end
  reaper.SetProjExtState(0, M.SECTION, "mix_state", table.concat(parts, ";"))
end

local function applyMix(memory)
  local back = memory ~= nil
  for t = 0, reaper.CountTracks(0) - 1 do
    local track = reaper.GetTrack(0, t)
    local keys = sendKeys(track)
    if back then
      local saved = memory.tracks[reaper.GetTrackGUID(track)]
      if saved then
        reaper.SetMediaTrackInfo_Value(track, "B_MAINSEND", saved.main)
        reaper.SetMediaTrackInfo_Value(track, "I_RECMON", saved.mon)
      end
      for s, key in ipairs(keys) do
        local mute = memory.sends[key]
        if mute then reaper.SetTrackSendInfo_Value(track, 1, s - 1, "B_MUTE", mute) end
      end
    else
      reaper.SetMediaTrackInfo_Value(track, "B_MAINSEND", 1)
      reaper.SetMediaTrackInfo_Value(track, "I_RECMON", 0)
      for s = 1, #keys do
        reaper.SetTrackSendInfo_Value(track, 1, s - 1, "B_MUTE", 1)
      end
    end
  end
  local master = reaper.GetToggleCommandStateEx(0, M.MIXER_MASTER)
  local wantMaster = 1
  if back then wantMaster = memory.master or master end
  if master >= 0 and wantMaster >= 0 and master ~= wantMaster then
    reaper.Main_OnCommand(M.MIXER_MASTER, 0)
  end
end

applyMeters = function(fallback, mixPressedOn)
  local metering = reaper.GetToggleCommandStateEx(0, M.PRE_FADER_METERING)
  if metering < 0 then return end
  local before = reaper.GetExtState(M.SECTION, "meters_before")
  local want
  if mixPressedOn or liveMixMemory() or liveOutModes() then
    if before == "" then
      local mix = liveMixMemory()
      reaper.SetExtState(M.SECTION, "meters_before", tostring(mix and mix.metering or metering), true)
    end
    want = 0
  else
    want = tonumber(before) or fallback
    reaper.DeleteExtState(M.SECTION, "meters_before", true)
  end
  if want and want >= 0 and metering ~= want then reaper.Main_OnCommand(M.PRE_FADER_METERING, 0) end
end

function M.mixDown(confirmed)
  if reaper.GetPlayState() & 4 == 4 then return end
  local memory = liveMixMemory()
  local back = memory ~= nil
  local question = back
    and "Put every track back how it was before the mixdown?\n\nMaster sends, hardware output mutes, record monitoring and the mixer master go back as they were. The meters go back to how they were too, unless OUTS FOLLOW FADERS is on."
    or "Set every track up for a mixdown?\n\nEvery track goes to the master, its hardware outputs are muted, record monitoring goes off, the meters show post-fader and the master shows in the mixer. Press again to put it all back."
  if not confirmed and reaper.ShowMessageBox(question, back and "Turn Off Mix Down" or "Mix Down", 1) ~= 1 then return end
  if not back then rememberMix() end
  reaper.PreventUIRefresh(1)
  reaper.Undo_BeginBlock()
  applyMix(memory)
  reaper.Undo_EndBlock(back and "Back from mix down" or "Mix down setup", 1)
  reaper.PreventUIRefresh(-1)
  if back then reaper.SetProjExtState(0, M.SECTION, "mix_state", "") end
  applyMeters(back and memory.metering or nil, not back)
  afterTrackPress()
end

local function gainDb(vol)
  return 20 * math.log(math.abs(vol), 10)
end

local function offUnity(vol)
  return math.abs(gainDb(vol)) > M.UNITY_DB
end

local function dbText(db)
  if db == -math.huge then return "-inf dB" end
  return string.format("%+.1f dB", db)
end

local function addParts(rows, number, track, parts)
  if #parts == 0 then return end
  local row = rows[number]
  if not row then
    local _, name = reaper.GetTrackName(track)
    row = { name = name, parts = {} }
    rows[number] = row
  end
  for _, part in ipairs(parts) do row.parts[#row.parts + 1] = part end
end

local function levelScan(fix, rows)
  for t = 0, reaper.CountTracks(0) - 1 do
    local track = reaper.GetTrack(0, t)
    local sends = reaper.GetTrackNumSends(track, 1)
    if sends > 0 then
      local worstDb, panned, itemsOff, followsFader = nil, false, 0, false
      for s = 0, sends - 1 do
        local vol = reaper.GetTrackSendInfo_Value(track, 1, s, "D_VOL")
        local pan = reaper.GetTrackSendInfo_Value(track, 1, s, "D_PAN")
        local volOff, panOff = offUnity(vol), math.abs(pan) > M.UNITY_PAN
        if volOff and (worstDb == nil or math.abs(gainDb(vol)) > math.abs(worstDb)) then worstDb = gainDb(vol) end
        if panOff then panned = true end
        if reaper.GetTrackSendInfo_Value(track, 1, s, "I_SENDMODE") == M.POST_FADER then followsFader = true end
        if fix and (volOff or panOff) then
          reaper.SetTrackSendInfo_Value(track, 1, s, "D_VOL", 1.0)
          reaper.SetTrackSendInfo_Value(track, 1, s, "D_PAN", 0.0)
        end
      end
      local faderDb, faderPanned = nil, false
      if followsFader then
        local vol = reaper.GetMediaTrackInfo_Value(track, "D_VOL")
        if offUnity(vol) then faderDb = gainDb(vol) end
        faderPanned = math.abs(reaper.GetMediaTrackInfo_Value(track, "D_PAN")) > M.UNITY_PAN
        if fix and (faderDb or faderPanned) then
          reaper.SetMediaTrackInfo_Value(track, "D_VOL", 1.0)
          reaper.SetMediaTrackInfo_Value(track, "D_PAN", 0.0)
        end
      end
      for i = 0, reaper.CountTrackMediaItems(track) - 1 do
        local item = reaper.GetTrackMediaItem(track, i)
        local off = false
        if offUnity(reaper.GetMediaItemInfo_Value(item, "D_VOL")) then
          off = true
          if fix then reaper.SetMediaItemInfo_Value(item, "D_VOL", 1.0) end
        end
        for k = 0, reaper.CountTakes(item) - 1 do
          local take = reaper.GetTake(item, k)
          if take then
            local vol = reaper.GetMediaItemTakeInfo_Value(take, "D_VOL")
            if offUnity(vol) or math.abs(reaper.GetMediaItemTakeInfo_Value(take, "D_PAN")) > M.UNITY_PAN then
              off = true
              if fix then
                reaper.SetMediaItemTakeInfo_Value(take, "D_VOL", vol < 0 and -1.0 or 1.0)
                reaper.SetMediaItemTakeInfo_Value(take, "D_PAN", 0.0)
              end
            end
          end
        end
        if off then itemsOff = itemsOff + 1 end
      end
      if not fix then
        local parts = {}
        if worstDb then parts[#parts + 1] = "output " .. dbText(worstDb) end
        if panned then parts[#parts + 1] = "output panned" end
        if faderDb then parts[#parts + 1] = "fader " .. dbText(faderDb) end
        if faderPanned then parts[#parts + 1] = "fader panned" end
        if itemsOff > 0 then parts[#parts + 1] = itemsOff .. (itemsOff == 1 and " item" or " items") end
        addParts(rows, t + 1, track, parts)
      end
    end
  end
end

local SETUP_VERSION = "v3|"
local SEND_PROPS = { "I_SENDMODE", "B_MUTE", "B_PHASE", "B_MONO", "D_VOL", "D_PAN", "D_PANLAW", "I_AUTOMODE" }
local TRACK_STATES = { { key = "B_MUTE", field = "mute" }, { key = "I_SOLO", field = "solo" }, { key = "B_PHASE", field = "phase" }, { key = "I_RECMON", field = "recmon" }, { key = "B_MAINSEND", field = "main" } }
local setupMemory = {}

local function isPluginHost()
  local _, file = reaper.EnumProjects(-1)
  return ((file or ""):match("[^/\\]*$") or ""):upper():find("PLUGIN HOST", 1, true) ~= nil
end
M.isPluginHost = isPluginHost

function M.missingInputs()
  local inputs = reaper.GetNumAudioInputs()
  local count = 0
  for i = 0, reaper.CountTracks(0) - 1 do
    local track = reaper.GetTrack(0, i)
    if reaper.GetMediaTrackInfo_Value(track, "I_RECARM") == 1 and reaper.GetMediaTrackInfo_Value(track, "I_RECMODE") == 0 then
      local input = math.tointeger(math.floor(reaper.GetMediaTrackInfo_Value(track, "I_RECINPUT"))) or -1
      if input >= 0 and input & 4096 == 0 and input & 1023 < 512 then
        local width = 1
        if input & 2048 ~= 0 then
          width = math.tointeger(math.floor(reaper.GetMediaTrackInfo_Value(track, "I_NCHAN"))) or 2
        elseif input & 1024 ~= 0 then
          width = 2
        end
        if (input & 1023) + width > inputs then count = count + 1 end
      end
    end
  end
  return inputs, count
end

function M.missingInputsMessage(inputs, count)
  if inputs <= 0 or count == 0 then return nil end
  local tracks = count == 1 and "1 armed track uses" or (count .. " armed tracks use")
  return "- " .. tracks .. " inputs the audio device does not have (it has " .. inputs .. "). Connect the right interface, or run AUTO PATCH."
end

local function outName(dst)
  local n = dst & 511
  if dst & 1024 ~= 0 then return "Out " .. (n + 1) end
  return "Out " .. (n + 1) .. "/" .. (n + 2)
end

local function outChannels(dst)
  local n = dst & 511
  if dst & 1024 ~= 0 then return { n } end
  return { n, n + 1 }
end

local function readSetup()
  local tracks = {}
  for t = 0, reaper.CountTracks(0) - 1 do
    local track = reaper.GetTrack(0, t)
    local outs = {}
    for s = 0, reaper.GetTrackNumSends(track, 1) - 1 do
      outs[#outs + 1] = {
        src = math.floor(reaper.GetTrackSendInfo_Value(track, 1, s, "I_SRCCHAN")),
        dst = math.floor(reaper.GetTrackSendInfo_Value(track, 1, s, "I_DSTCHAN")),
        mode = math.floor(reaper.GetTrackSendInfo_Value(track, 1, s, "I_SENDMODE")),
        mute = math.floor(reaper.GetTrackSendInfo_Value(track, 1, s, "B_MUTE")),
        index = s,
      }
    end
    local entry = { track = track, number = t + 1, outs = outs }
    for _, state in ipairs(TRACK_STATES) do entry[state.field] = math.floor(reaper.GetMediaTrackInfo_Value(track, state.key)) end
    tracks[reaper.GetTrackGUID(track)] = entry
  end
  return { rate = reaper.Master_GetPlayRate(0), tracks = tracks }
end

function M.outsSignature()
  local parts = {}
  for t = 0, reaper.CountTracks(0) - 1 do
    local track = reaper.GetTrack(0, t)
    parts[#parts + 1] = "|"
    for s = 0, reaper.GetTrackNumSends(track, 1) - 1 do
      for _, key in ipairs({ "I_SRCCHAN", "I_DSTCHAN", "I_SENDMODE", "B_MUTE" }) do
        parts[#parts + 1] = math.floor(reaper.GetTrackSendInfo_Value(track, 1, s, key))
      end
    end
  end
  return table.concat(parts, ",")
end

local function encodeSetup(setup)
  local parts = {}
  for guid, entry in pairs(setup.tracks) do
    local outs = {}
    for _, out in ipairs(entry.outs) do outs[#outs + 1] = out.src .. ">" .. out.dst .. ">" .. out.mode .. ">" .. out.mute end
    parts[#parts + 1] = guid .. "=" .. entry.mute .. "/" .. entry.solo .. "/" .. entry.phase .. "/" .. entry.recmon .. "/" .. entry.main .. ":" .. table.concat(outs, ",")
  end
  table.sort(parts)
  return SETUP_VERSION .. "rate=" .. string.format("%.6f", setup.rate) .. ";" .. table.concat(parts, ";")
end

local function decodeSetup(text)
  if text:sub(1, #SETUP_VERSION) ~= SETUP_VERSION then return nil end
  local body = text:sub(#SETUP_VERSION + 1)
  local setup = { rate = tonumber(body:match("^rate=([%d%.]+)")) or 1, tracks = {} }
  for guid, mute, solo, phase, recmon, main, outs in body:gmatch("([^;=]+)=(-?%d+)/(-?%d+)/(-?%d+)/(-?%d+)/(-?%d+):([^;]*)") do
    local list = {}
    for src, dst, mode, outMute in outs:gmatch("(-?%d+)>(-?%d+)>(-?%d+)>(-?%d+)") do
      list[#list + 1] = { src = tonumber(src), dst = tonumber(dst), mode = tonumber(mode), mute = tonumber(outMute) }
    end
    setup.tracks[guid] = { mute = tonumber(mute), solo = tonumber(solo), phase = tonumber(phase), recmon = tonumber(recmon), main = tonumber(main), outs = list }
  end
  return setup
end

local function storedSetup()
  local ok, value = reaper.GetProjExtState(0, M.SECTION, M.SETUP_KEY)
  if ok ~= 1 or value == "" then return nil end
  return decodeSetup(value)
end

local function storeSetup(setup)
  reaper.SetProjExtState(0, M.SECTION, M.SETUP_KEY, encodeSetup(setup))
end

function M.rememberSetup()
  if isPluginHost() then return end
  storeSetup(readSetup())
end

function M.mixDownOn()
  return liveMixMemory() ~= nil
end

function M.configInt(name)
  if not reaper.get_config_var_string then return nil end
  local ok, value = reaper.get_config_var_string(name)
  return ok and tonumber(value) or nil
end

local configInt = M.configInt

local function clockText(seconds)
  seconds = math.floor(seconds + 0.5)
  local h, m, s = seconds // 3600, seconds // 60 % 60, seconds % 60
  if h > 0 then return string.format("%d:%02d:%02d", h, m, s) end
  return string.format("%d:%02d", m, s)
end

local function configString(name)
  if not reaper.get_config_var_string then return nil end
  local ok, value = reaper.get_config_var_string(name)
  return ok and value or nil
end

function M.deviceFollowsMac()
  return configString("coreaudioindevnew") == "<default>" or configString("coreaudiooutdevnew") == "<default>"
end

function M.liveSettings()
  local list = {}
  if not reaper.SNM_SetIntConfigVar then return list end
  local function add(name, bits, label, now, already)
    local value = configInt(name)
    if not value then return end
    list[#list + 1] = { label = label, now = now, already = already or label, wrong = value & bits ~= 0,
      fix = function() reaper.SNM_SetIntConfigVar(name, configInt(name) & ~bits) end,
      check = function() return configInt(name) & bits == 0 end }
  end
  add("projmaxlenuse", 1, "Project length limit: off", "now on, stops at " .. clockText(configInt("projmaxlen") or 0))
  local mode = configInt("projrecmode")
  if mode then
    list[#list + 1] = { label = "Record mode: normal", now = "now auto-punch", already = "Record mode: normal", wrong = mode ~= 1,
      fix = function() reaper.Main_OnCommand(M.RECORD_MODE_NORMAL, 0) end,
      check = function() return configInt("projrecmode") == 1 end }
  end
  add("projmetroen", 16, "Count-in before recording: off", "now on")
  add("preroll", 2, "Pre-roll before recording: off", "now on")
  add("promptendrec", 3, "Prompt to save/delete on stop: off", "now on")
  add("maxrecsize_use", 1, "New file every " .. math.floor(configInt("maxrecsize") or 0) .. " MB: off", "now on", "One file per take (no new file every N MB)")
  add("audiocloseinactive", 1, "Close audio device when stopped and inactive: off", "now on")
  local function autoArmed()
    local tracks = {}
    for t = 0, reaper.CountTracks(0) - 1 do
      local track = reaper.GetTrack(0, t)
      if reaper.GetMediaTrackInfo_Value(track, "B_AUTO_RECARM") ~= 0 then tracks[#tracks + 1] = track end
    end
    return tracks
  end
  local armed = #autoArmed()
  list[#list + 1] = { label = "Automatic record-arm: off", now = "now on for " .. armed .. (armed == 1 and " track" or " tracks"), already = "Automatic record-arm: off", wrong = armed > 0,
    fix = function()
      local tracks = autoArmed()
      if #tracks == 0 then return end
      reaper.Undo_BeginBlock()
      for _, track in ipairs(tracks) do reaper.SetMediaTrackInfo_Value(track, "B_AUTO_RECARM", 0) end
      reaper.Undo_EndBlock("Automatic record-arm off", 1)
    end,
    check = function() return #autoArmed() == 0 end }
  return list
end

function M.fixRecordMode()
  local mode = configInt("projrecmode")
  if mode and mode ~= 1 then reaper.Main_OnCommand(M.RECORD_MODE_NORMAL, 0) end
end

function M.forgetSetup()
  reaper.SetProjExtState(0, M.SECTION, M.SETUP_KEY, "")
  reaper.SetExtState(M.SECTION, "setup_reset", tostring(reaper.time_precise()), false)
end

function M.mixStrays()
  if liveMixMemory() or trackState("B_MAINSEND") ~= "some" then return nil end
  local strays = {}
  for t = 0, reaper.CountTracks(0) - 1 do
    local track = reaper.GetTrack(0, t)
    if reaper.GetMediaTrackInfo_Value(track, "B_MAINSEND") ~= 0 then
      local _, name = reaper.GetTrackName(track)
      strays[#strays + 1] = { guid = reaper.GetTrackGUID(track), line = (t + 1) .. ": " .. name }
    end
  end
  return strays
end

function M.takeOffMaster(strays)
  if reaper.GetPlayState() & 4 == 4 then return false end
  local wanted = {}
  for _, stray in ipairs(strays) do wanted[stray.guid] = true end
  reaper.PreventUIRefresh(1)
  reaper.Undo_BeginBlock()
  for t = 0, reaper.CountTracks(0) - 1 do
    local track = reaper.GetTrack(0, t)
    if wanted[reaper.GetTrackGUID(track)] then reaper.SetMediaTrackInfo_Value(track, "B_MAINSEND", 0) end
  end
  local saved = storedSetup()
  if saved then
    for guid in pairs(wanted) do
      if saved.tracks[guid] then saved.tracks[guid].main = 0 end
    end
    storeSetup(saved)
  else
    local project, file = reaper.EnumProjects(-1)
    local guids = {}
    for guid in pairs(wanted) do guids[#guids + 1] = guid end
    reaper.SetExtState(M.SECTION, "main_off_key", tostring(project) .. "|" .. (file or ""), false)
    reaper.SetExtState(M.SECTION, "main_off", string.format("%.6f", reaper.time_precise()) .. ";" .. table.concat(guids, ","), false)
  end
  reaper.Undo_EndBlock("Take tracks off master", 1)
  reaper.PreventUIRefresh(-1)
  afterTrackPress()
  return true
end

local function sharesTrack(known, now)
  for guid in pairs(known) do
    if now[guid] then return true end
  end
  return false
end

local function knownSetup(now)
  local saved = storedSetup()
  if saved then return saved, true end
  if reaper.CountMediaItems(0) == 0 then return nil, false end
  local project, file = reaper.EnumProjects(-1)
  local key = tostring(project) .. "|" .. (file or "")
  local reset = reaper.GetExtState(M.SECTION, "setup_reset")
  local known = setupMemory[key]
  if not known or known.reset ~= reset or not sharesTrack(known.tracks, now.tracks) then
    if liveMixMemory() then return nil, false end
    known = { rate = now.rate, reset = reset, tracks = {}, built = reaper.time_precise() }
    for guid, entry in pairs(now.tracks) do known.tracks[guid] = entry end
    setupMemory[key] = known
  end
  local stamp, guids = reaper.GetExtState(M.SECTION, "main_off"):match("^([^;]+);(.*)$")
  stamp = tonumber(stamp)
  if stamp and reaper.GetExtState(M.SECTION, "main_off_key") == key and known.built < stamp and known.offStamp ~= stamp then
    known.offStamp = stamp
    for guid in guids:gmatch("[^,]+") do
      if known.tracks[guid] then known.tracks[guid].main = 0 end
    end
  end
  return known, false
end

local function sameOut(a, b)
  return a.src == b.src and a.dst == b.dst
end

local function compareOuts(was, now)
  local used, missing, extra, pairs_ = {}, {}, {}, {}
  for _, w in ipairs(was) do
    local found = false
    for i, n in ipairs(now) do
      if not used[i] and sameOut(w, n) then
        used[i], found = true, true
        pairs_[#pairs_ + 1] = { was = w, now = n }
        break
      end
    end
    if not found then missing[#missing + 1] = w end
  end
  for i, n in ipairs(now) do
    if not used[i] then extra[#extra + 1] = n end
  end
  return missing, extra, pairs_
end

local function sharesChannel(a, b)
  for _, x in ipairs(outChannels(a.dst)) do
    for _, y in ipairs(outChannels(b.dst)) do
      if x == y then return true end
    end
  end
  return false
end

local function usedElsewhere(out, guid, now, known)
  for _, tracks in ipairs({ now, known }) do
    for other, entry in pairs(tracks) do
      if other ~= guid then
        for _, o in ipairs(entry.outs) do
          if sharesChannel(out, o) then return true end
        end
      end
    end
  end
  return false
end

local function clashingOuts(guid, entry, now, known)
  local clashes = {}
  for _, out in ipairs(entry.outs) do
    if usedElsewhere(out, guid, now, known) then clashes[#clashes + 1] = out end
  end
  return clashes
end

local function describePatch(missing, extra)
  local gone, added, parts = {}, {}, {}
  for _, m in ipairs(missing) do gone[#gone + 1] = m end
  for _, e in ipairs(extra) do added[#added + 1] = e end
  for i = #gone, 1, -1 do
    for j, e in ipairs(added) do
      if e.dst == gone[i].dst then
        parts[#parts + 1] = outName(e.dst) .. " source changed"
        table.remove(added, j)
        table.remove(gone, i)
        break
      end
    end
  end
  if #gone == 1 and #added == 1 then
    parts[#parts + 1] = outName(gone[1].dst) .. " changed to " .. outName(added[1].dst)
    return parts
  end
  for _, m in ipairs(gone) do parts[#parts + 1] = outName(m.dst) .. " gone" end
  for _, e in ipairs(added) do parts[#parts + 1] = outName(e.dst) .. " added" end
  return parts
end

local function playsPlugins(track)
  if reaper.GetMediaTrackInfo_Value(track, "I_FXEN") == 0 then return false end
  for fx = 0, reaper.TrackFX_GetCount(track) - 1 do
    if reaper.TrackFX_GetEnabled(track, fx) and not reaper.TrackFX_GetOffline(track, fx) then return true end
  end
  return false
end

local function pluginsHeardChanged(pair, track)
  return (pair.was.mode ~= M.PRE_FX) ~= (pair.now.mode ~= M.PRE_FX) and playsPlugins(track)
end

local function describeTrack(was, now, matched)
  local parts = {}
  for _, pair in ipairs(matched) do
    if pair.was.mute ~= pair.now.mute then parts[#parts + 1] = outName(pair.now.dst) .. (pair.now.mute ~= 0 and " muted" or " unmuted") end
    if pluginsHeardChanged(pair, now.track) then parts[#parts + 1] = outName(pair.now.dst) .. (pair.now.mode ~= M.PRE_FX and " after plugins" or " before plugins") end
  end
  if was.mute ~= now.mute then parts[#parts + 1] = now.mute ~= 0 and "muted" or "unmuted" end
  if was.solo ~= now.solo then parts[#parts + 1] = now.solo ~= 0 and "soloed" or "solo off" end
  if was.phase ~= now.phase then parts[#parts + 1] = "polarity changed" end
  if was.recmon ~= now.recmon then parts[#parts + 1] = now.recmon ~= 0 and "monitoring on" or "monitoring off" end
  if was.main ~= now.main then parts[#parts + 1] = now.main ~= 0 and "master send on" or "master send off" end
  return parts
end

local function rateChanged(was, now)
  return math.abs(was - now) > 0.0005
end

local function setupScan(rows, extraLines)
  local now = readSetup()
  local known, saved = knownSetup(now)
  if not known then return false, false end
  local changed, restorable, grew = false, false, false
  for guid, entry in pairs(now.tracks) do
    local was = known.tracks[guid]
    local parts
    if was then
      local missing, extra, matched = compareOuts(was.outs, entry.outs)
      parts = describePatch(missing, extra)
      for _, part in ipairs(describeTrack(was, entry, matched)) do parts[#parts + 1] = part end
    else
      parts = {}
      local clashes = clashingOuts(guid, entry, now.tracks, known.tracks)
      for _, out in ipairs(clashes) do parts[#parts + 1] = outName(out.dst) .. " added" end
      if #clashes == 0 then
        known.tracks[guid] = entry
        grew = true
      end
    end
    if #parts > 0 then
      addParts(rows, entry.number, entry.track, parts)
      changed, restorable = true, true
    end
  end
  if rateChanged(known.rate, now.rate) then
    extraLines[#extraLines + 1] = string.format("Project playrate %.2fx (recorded at %.2fx)", now.rate, known.rate)
    changed, restorable = true, true
  end
  for guid, was in pairs(known.tracks) do
    if not now.tracks[guid] and #was.outs > 0 then
      local names = {}
      for _, out in ipairs(was.outs) do names[#names + 1] = outName(out.dst) .. " gone" end
      extraLines[#extraLines + 1] = "Deleted track - " .. table.concat(names, ", ") .. " (can't put back)"
      changed = true
    end
  end
  if (saved and grew) or (not saved and changed) then storeSetup(known) end
  return changed, restorable
end

local function findMove(out, guid, extraBy, known)
  for other, extras in pairs(extraBy) do
    if other ~= guid and known[other] then
      for i, e in ipairs(extras) do
        if sameOut(out, e) then return other, i end
      end
    end
  end
  return nil
end

local function restoreSetup()
  local now = readSetup()
  local known = knownSetup(now)
  if not known then return end
  local missingBy, extraBy, removals = {}, {}, {}
  for guid, entry in pairs(now.tracks) do
    removals[guid] = {}
    local was = known.tracks[guid]
    if was then
      local matched
      missingBy[guid], extraBy[guid], matched = compareOuts(was.outs, entry.outs)
      for _, pair in ipairs(matched) do
        if pair.was.mute ~= pair.now.mute then reaper.SetTrackSendInfo_Value(entry.track, 1, pair.now.index, "B_MUTE", pair.was.mute) end
        if pluginsHeardChanged(pair, entry.track) then reaper.SetTrackSendInfo_Value(entry.track, 1, pair.now.index, "I_SENDMODE", pair.was.mode) end
      end
      for _, state in ipairs(TRACK_STATES) do
        if was[state.field] ~= entry[state.field] then reaper.SetMediaTrackInfo_Value(entry.track, state.key, was[state.field]) end
      end
    else
      missingBy[guid], extraBy[guid] = {}, clashingOuts(guid, entry, now.tracks, known.tracks)
    end
  end
  for guid, missing in pairs(missingBy) do
    local track = now.tracks[guid].track
    for i = #missing, 1, -1 do
      local other, e = findMove(missing[i], guid, extraBy, known.tracks)
      if other then
        local from, index = now.tracks[other].track, extraBy[other][e].index
        local send = reaper.CreateTrackSend(track, nil)
        for _, key in ipairs(SEND_PROPS) do
          reaper.SetTrackSendInfo_Value(track, 1, send, key, reaper.GetTrackSendInfo_Value(from, 1, index, key))
        end
        reaper.SetTrackSendInfo_Value(track, 1, send, "I_SRCCHAN", missing[i].src)
        reaper.SetTrackSendInfo_Value(track, 1, send, "I_DSTCHAN", missing[i].dst)
        reaper.SetTrackSendInfo_Value(track, 1, send, "B_MUTE", missing[i].mute)
        removals[other][#removals[other] + 1] = index
        table.remove(extraBy[other], e)
        table.remove(missing, i)
      end
    end
  end
  for guid, missing in pairs(missingBy) do
    local track, extras = now.tracks[guid].track, extraBy[guid]
    for i = #missing, 1, -1 do
      for j, e in ipairs(extras) do
        if e.dst == missing[i].dst then
          reaper.SetTrackSendInfo_Value(track, 1, e.index, "I_SRCCHAN", missing[i].src)
          reaper.SetTrackSendInfo_Value(track, 1, e.index, "B_MUTE", missing[i].mute)
          table.remove(extras, j)
          table.remove(missing, i)
          break
        end
      end
    end
    while #missing > 0 and #extras > 0 do
      local m, e = table.remove(missing, 1), table.remove(extras, 1)
      reaper.SetTrackSendInfo_Value(track, 1, e.index, "I_SRCCHAN", m.src)
      reaper.SetTrackSendInfo_Value(track, 1, e.index, "I_DSTCHAN", m.dst)
      reaper.SetTrackSendInfo_Value(track, 1, e.index, "I_SENDMODE", m.mode)
      reaper.SetTrackSendInfo_Value(track, 1, e.index, "B_MUTE", m.mute)
    end
    for _, m in ipairs(missing) do
      local send = reaper.CreateTrackSend(track, nil)
      reaper.SetTrackSendInfo_Value(track, 1, send, "I_SRCCHAN", m.src)
      reaper.SetTrackSendInfo_Value(track, 1, send, "I_DSTCHAN", m.dst)
      reaper.SetTrackSendInfo_Value(track, 1, send, "I_SENDMODE", m.mode)
      reaper.SetTrackSendInfo_Value(track, 1, send, "B_MUTE", m.mute)
      reaper.SetTrackSendInfo_Value(track, 1, send, "D_VOL", 1.0)
      reaper.SetTrackSendInfo_Value(track, 1, send, "D_PAN", 0.0)
    end
    for _, e in ipairs(extras) do removals[guid][#removals[guid] + 1] = e.index end
  end
  for guid, list in pairs(removals) do
    table.sort(list, function(a, b) return a > b end)
    for _, index in ipairs(list) do reaper.RemoveTrackSend(now.tracks[guid].track, 1, index) end
  end
  if rateChanged(known.rate, now.rate) then reaper.CSurf_OnPlayRateChange(known.rate) end
end

function M.unityReport()
  local report = { lines = {}, changed = false, restorable = false }
  if isPluginHost() then return report end
  local rows, extraLines = {}, {}
  levelScan(false, rows)
  report.changed, report.restorable = setupScan(rows, extraLines)
  local numbers = {}
  for number in pairs(rows) do numbers[#numbers + 1] = number end
  table.sort(numbers)
  for _, number in ipairs(numbers) do
    report.lines[#report.lines + 1] = number .. ": " .. rows[number].name .. " - " .. table.concat(rows[number].parts, ", ")
  end
  for _, line in ipairs(extraLines) do report.lines[#report.lines + 1] = line end
  return report
end

function M.unityState()
  return #M.unityReport().lines == 0 and "all" or "none"
end

function M.unityLitPress()
  afterTrackPress()
end

function M.unityApply(choice)
  if reaper.GetPlayState() & 4 == 4 or isPluginHost() then return false end
  local mixMemory = liveMixMemory()
  if mixMemory and choice == "keep" then return false end
  local mixStaysOn = mixMemory ~= nil and choice ~= "put_back"
  reaper.PreventUIRefresh(1)
  reaper.Undo_BeginBlock()
  if choice == "put_back" then
    if mixMemory then applyMix(mixMemory) end
    restoreSetup()
  end
  levelScan(true, {})
  if not mixStaysOn and (choice ~= "levels" or storedSetup()) then M.rememberSetup() end
  local names = { put_back = "Put back as recorded", keep = "Keep changes" }
  reaper.Undo_EndBlock(names[choice] or "Back to unity", 5)
  reaper.PreventUIRefresh(-1)
  if mixMemory and not mixStaysOn then reaper.SetProjExtState(0, M.SECTION, "mix_state", "") end
  if choice == "put_back" or (mixMemory and not mixStaysOn) then applyMeters(mixMemory and mixMemory.metering or nil) end
  if choice == "put_back" then reaper.TrackList_AdjustWindows(false) end
  reaper.UpdateArrange()
  afterTrackPress()
  return true
end

function M.recMonitor()
  local all = trackState("I_RECMON") == "all"
  local action = all and M.MONITOR_OFF or M.MONITOR_ON
  reaper.Undo_BeginBlock()
  reaper.Main_OnCommand(reaper.NamedCommandLookup(action), 0)
  reaper.Main_OnCommand(M.UNSELECT_ALL, 0)
  reaper.Undo_EndBlock(all and "Record monitoring off for all tracks" or "Record monitoring on for all tracks", 1)
  afterTrackPress()
end

function M.toggleDock()
  local wasDocked = reaper.GetToggleCommandStateEx(0, M.TOGGLE_DOCK) == 1
  local wasShowing = reaper.GetToggleCommandStateEx(0, M.TOGGLE_MIXER) == 1
  reaper.Main_OnCommand(M.TOGGLE_DOCK, 0)
  local showing = reaper.GetToggleCommandStateEx(0, M.TOGGLE_MIXER) == 1
  if wasDocked then
    if not wasShowing then
      if showing then reaper.Main_OnCommand(M.TOGGLE_MIXER, 0) end
      reaper.SetExtState(M.SECTION, "keep_mixer_hidden", tostring(reaper.time_precise() + M.KEEP_HIDDEN_FOR), false)
    end
  elseif not showing then
    reaper.Main_OnCommand(M.TOGGLE_MIXER, 0)
  end
  M.mixerLights()
  M.ensureWatch()
end

function M.showMixer(index)
  local button = M.MIXER_BUTTONS[index]
  if mixerShowing(button) then
    reaper.Main_OnCommand(M.TOGGLE_MIXER, 0)
  else
    reaper.Main_OnCommand(button.windowSet, 0)
    if reaper.GetToggleCommandStateEx(0, M.TOGGLE_MIXER) ~= 1 then
      reaper.Main_OnCommand(M.TOGGLE_MIXER, 0)
    end
  end
  M.mixerLights()
  M.ensureWatch()
end

function M.toggleToolbar(index)
  local button = M.TOOLBAR_BUTTONS[index]
  if reaper.GetToggleCommandStateEx(0, button.openClose) == 1 then
    reaper.Main_OnCommand(button.openClose, 0)
  else
    reaper.Main_OnCommand(button.atMouse, 0)
  end
  M.toolbarLights()
  M.ensureWatch()
end

function M.toolsMenu()
  local name = reaper.kbd_getTextFromCmd(M.TOOLS_MENU, reaper.SectionFromUniqueID(0)) or ""
  if name:lower() ~= M.TOOLS_MENU_NAME then
    reaper.ShowMessageBox("Failed to open the TOOLS menu: it needs REAPER 7.26 or newer.", "TOOLS", 0)
    return
  end
  reaper.Main_OnCommand(M.TOOLS_MENU, 0)
  M.toolbarLights()
  M.ensureWatch()
end

function M.midiSceneOn()
  return fold(reaper.GetExtState(M.SECTION, M.MIDI_SCENE_KEY)) ~= "0"
end

function M.midiSceneLight()
  syncLight(M.MIDI_SCENE_ID, M.midiSceneOn())
end

function M.toggleMidiScene()
  reaper.SetExtState(M.SECTION, M.MIDI_SCENE_KEY, M.midiSceneOn() and "0" or "1", true)
  M.midiSceneLight()
  M.ensureWatch()
end

function M.timeLeftAlive()
  local stamp = tonumber(reaper.GetExtState(M.TIME_LEFT_SECTION, "alive"))
  return stamp ~= nil and (reaper.time_precise() - stamp) < 3
end

function M.timeLeftHidden()
  return fold(reaper.GetExtState(M.TIME_LEFT_SECTION, "hidden")) == "1"
end

function M.recordTab()
  M.showTab("RECORD")
  if reaper.GetToggleCommandStateEx(0, M.TOGGLE_MIXER) ~= 1 then
    M.showMixer(3)
  end
  if not M.timeLeftAlive() and not M.timeLeftHidden() then
    local cmd = reaper.NamedCommandLookup(M.TIME_LEFT_ID)
    if cmd ~= 0 then reaper.Main_OnCommand(cmd, 0) end
  end
  M.toolbarLights()
  M.ensureWatch()
end

local function hideDockedMixer()
  if reaper.GetToggleCommandStateEx(0, M.TOGGLE_MIXER) == 1 and reaper.GetToggleCommandStateEx(0, M.TOGGLE_DOCK) == 1 then
    reaper.Main_OnCommand(M.TOGGLE_MIXER, 0)
  end
end

function M.vscTab()
  hideDockedMixer()
  M.showTab("VSC")
  M.mixerLights()
  M.toolbarLights()
  M.ensureWatch()
end

function M.setupTab()
  hideDockedMixer()
  M.showTab("SETUP")
  M.mixerLights()
  M.ensureWatch()
end

function M.editTab()
  hideDockedMixer()
  M.showTab("EDIT")
  M.mixerLights()
  M.ensureWatch()
end

function M.toggleTimeLeft()
  local open = M.timeLeftAlive()
  if open then
    reaper.SetExtState(M.TIME_LEFT_SECTION, "hidden", "1", true)
    reaper.SetExtState(M.TIME_LEFT_SECTION, "close", tostring(reaper.time_precise()), false)
  else
    reaper.SetExtState(M.TIME_LEFT_SECTION, "hidden", "0", true)
    local cmd = reaper.NamedCommandLookup(M.TIME_LEFT_ID)
    if cmd ~= 0 then reaper.Main_OnCommand(cmd, 0) end
  end
  M.setLight(M.TIME_LEFT_BUTTON_ID, not open)
  M.ensureWatch()
end

function M.toggleFloatingFx()
  local toOpen = selectedFxTracks(true)
  local close = #toOpen == 0 or anyFloating(toOpen)
  for _, track in ipairs(close and fxTracks() or toOpen) do
    for fx = 0, reaper.TrackFX_GetCount(track) - 1 do
      reaper.TrackFX_Show(track, fx, close and 2 or 3)
    end
  end
  M.fxLights()
  M.ensureWatch()
end

function M.toggleFxChains()
  local selected = selectedFxTracks(false)
  local toOpen = #selected == 1 and selected or selectedFxTracks(true)
  if #toOpen == 0 or anyChain(selected) then
    for _, track in ipairs(fxTracks()) do
      if reaper.TrackFX_GetChainVisible(track) ~= -1 then reaper.TrackFX_Show(track, 0, 0) end
    end
  else
    for _, track in ipairs(toOpen) do reaper.TrackFX_Show(track, 0, 1) end
  end
  M.fxLights()
  M.ensureWatch()
end

local function topTrackInView()
  for t = 0, reaper.CountTracks(0) - 1 do
    local track = reaper.GetTrack(0, t)
    if reaper.GetMediaTrackInfo_Value(track, "B_SHOWINTCP") ~= 0
      and reaper.GetMediaTrackInfo_Value(track, "I_TCPY") + reaper.GetMediaTrackInfo_Value(track, "I_WNDH") > 0 then
      return track
    end
  end
  return reaper.GetTrack(0, 0)
end

local function keepAtTop(track)
  if reaper.GetPlayState() & 4 == 4 then return end
  if not reaper.ValidatePtr(track, "MediaTrack*") or reaper.GetMediaTrackInfo_Value(track, "I_TCPY") >= 0 then return end
  local master = reaper.GetMasterTrack(0)
  local masterSelected = reaper.IsTrackSelected(master)
  local selected = {}
  for i = 0, reaper.CountSelectedTracks(0) - 1 do selected[#selected + 1] = reaper.GetSelectedTrack(0, i) end
  reaper.PreventUIRefresh(1)
  reaper.SetOnlyTrackSelected(track)
  reaper.Main_OnCommand(M.SCROLL_SELECTED_INTO_VIEW, 0)
  reaper.SetTrackSelected(track, false)
  for _, t in ipairs(selected) do reaper.SetTrackSelected(t, true) end
  if masterSelected then reaper.SetTrackSelected(master, true) end
  reaper.PreventUIRefresh(-1)
end

function M.setHeights(kind)
  local target
  for _, button in ipairs(M.HEIGHT_BUTTONS) do
    if button.kind == kind then target = button.px end
  end
  local tracks = heightTracks()
  if not target or #tracks == 0 then return end
  local top = topTrackInView()
  reaper.PreventUIRefresh(1)
  for _, track in ipairs(tracks) do
    if reaper.GetMediaTrackInfo_Value(track, "I_HEIGHTOVERRIDE") ~= target then reaper.SetMediaTrackInfo_Value(track, "I_HEIGHTOVERRIDE", target) end
  end
  reaper.PreventUIRefresh(-1)
  reaper.TrackList_AdjustWindows(false)
  M.heightLights()
  M.ensureWatch()
  reaper.defer(function() keepAtTop(top) end)
end

function M.toggleZoomProject()
  if onZoomView() then
    local s, e = reaper.GetExtState(M.SECTION, "zoom_back"):match("^.*;(%-?[%d%.]+);(%-?[%d%.]+)$")
    if s then reaper.GetSet_ArrangeView2(0, true, 0, 0, tonumber(s), tonumber(e)) end
    reaper.DeleteExtState(M.SECTION, "zoom_view", false)
    reaper.DeleteExtState(M.SECTION, "zoom_back", false)
    M.zoomLight()
  else
    local backStart, backEnd = reaper.GetSet_ArrangeView2(0, false, 0, 0)
    reaper.SetExtState(M.SECTION, "zoom_back", projectKey() .. ";" .. string.format("%.6f;%.6f", backStart, backEnd), false)
    reaper.Main_OnCommand(M.ZOOM_PROJECT, 0)
    reaper.defer(function()
      local startTime, endTime = reaper.GetSet_ArrangeView2(0, false, 0, 0)
      reaper.SetExtState(M.SECTION, "zoom_view", projectKey() .. ";" .. string.format("%.6f;%.6f", startTime, endTime), false)
      M.zoomLight()
    end)
  end
  M.ensureWatch()
end

local function trackIcon(track)
  local _, icon = reaper.GetSetMediaTrackInfo_String(track, "P_ICON", "", false)
  return icon or ""
end

local function anyIcon()
  for t = 0, reaper.CountTracks(0) - 1 do
    if trackIcon(reaper.GetTrack(0, t)) ~= "" then return true end
  end
  return false
end

function M.iconLight()
  syncLight(M.ICONS_ID, anyIcon())
end

local function encodeIcon(s)
  return (s:gsub("[%%;=|%s]", function(c) return string.format("%%%02X", c:byte()) end))
end

local function decodeIcon(s)
  return (s:gsub("%%(%x%x)", function(h) return string.char(tonumber(h, 16)) end))
end

local function iconMemory()
  local stored = {}
  local _, value = reaper.GetProjExtState(0, M.SECTION, M.ICONS_KEY)
  value = value or ""
  local state, list = value:match("^(%a+)|(.*)$")
  if state then
    for guid, icon in list:gmatch("([^;=]+)=([^;]+)") do stored[guid] = decodeIcon(icon) end
  else
    state = value ~= "" and "hidden" or nil
    for rawGuid, rawIcon in value:gmatch("([^\t\n]+)\t([^\n]+)") do
      local guid, icon = rawGuid:match("^%s*(.-)%s*$"), rawIcon:match("^%s*(.-)%s*$")
      if guid ~= "" and icon ~= "" then stored[guid] = icon end
    end
  end
  return stored, state
end

local function saveIconMemory(stored, state)
  local parts = {}
  for guid, icon in pairs(stored) do parts[#parts + 1] = guid .. "=" .. encodeIcon(icon) end
  table.sort(parts)
  reaper.SetProjExtState(0, M.SECTION, M.ICONS_KEY, state .. "|" .. table.concat(parts, ";"))
end

function M.toggleIcons()
  local stored, state = iconMemory()
  local hide = anyIcon()
  if not hide and next(stored) == nil then return end
  if hide and state ~= "hidden" then stored = {} end
  reaper.PreventUIRefresh(1)
  for t = 0, reaper.CountTracks(0) - 1 do
    local track = reaper.GetTrack(0, t)
    local guid = reaper.GetTrackGUID(track)
    local icon = trackIcon(track)
    if hide and icon ~= "" then
      stored[guid] = icon
      reaper.GetSetMediaTrackInfo_String(track, "P_ICON", "", true)
    elseif not hide and stored[guid] then
      reaper.GetSetMediaTrackInfo_String(track, "P_ICON", stored[guid], true)
    end
  end
  reaper.PreventUIRefresh(-1)
  saveIconMemory(stored, hide and "hidden" or "shown")
  reaper.TrackList_AdjustWindows(false)
  M.iconLight()
  M.ensureWatch()
  reaper.defer(function() end)
end

function M.toggleFollow()
  local turnOff = followState() == "all"
  for _, action in ipairs(M.FOLLOW_ACTIONS) do
    if (reaper.GetToggleCommandStateEx(0, action) == 1) == turnOff then reaper.Main_OnCommand(action, 0) end
  end
  afterTrackPress()
end

function M.customAction(id, title)
  local command = reaper.NamedCommandLookup(id)
  if command == 0 then
    reaper.ShowMessageBox("Failed to run " .. title .. ": its custom action is missing.\n\nImport BSK_Actions.ReaperKeyMap in the Actions list, then try again.", title, 0)
    return nil
  end
  return command
end

function M.stopRecording(id, command)
  local wasRecording = reaper.GetPlayState() & 4 == 4
  reaper.Main_OnCommand(command, 0)
  if wasRecording and reaper.GetPlayState() & 4 == 0 then
    reaper.SetExtState(M.SECTION, "flash" .. id, tostring(reaper.time_precise()), false)
    M.setLight(id, true)
    M.ensureWatch()
  end
end

function M.addMarker()
  reaper.Undo_BeginBlock()
  reaper.Main_OnCommand(M.INSERT_MARKER, 0)
  reaper.Undo_EndBlock("Insert marker", 8)
  reaper.SetExtState(M.SECTION, "flash" .. M.MARKER_ID, tostring(reaper.time_precise()), false)
  M.setLight(M.MARKER_ID, true)
  M.ensureWatch()
end

function M.deleteRecording()
  if reaper.GetPlayState() & 4 == 4 then
    local armed = tonumber(reaper.GetExtState(M.SECTION, M.DELETE_ARMED_KEY))
    if not (armed and reaper.time_precise() - armed <= M.DELETE_ARM_FOR) then
      reaper.SetExtState(M.SECTION, M.DELETE_ARMED_KEY, tostring(reaper.time_precise()), false)
      M.setLight(M.DELETE_ID, true)
      M.ensureWatch()
      return
    end
  end
  reaper.DeleteExtState(M.SECTION, M.DELETE_ARMED_KEY, false)
  M.stopRecording(M.DELETE_ID, M.DELETE_REC)
end

function M.watchAlive()
  local stamp = tonumber(reaper.GetExtState(M.SECTION, "alive"))
  return stamp ~= nil and (reaper.time_precise() - stamp) < 3
end

function M.ensureWatch()
  if M.watchAlive() then return end
  local cmd = reaper.NamedCommandLookup(M.WATCH_ID)
  if cmd ~= 0 then reaper.Main_OnCommand(cmd, 0) end
end

return M
