-- @description BSK Transport: background check (keeps the SAFE REC, NEW TAKE, SAVE REC, DELETE REC, UNSOLO ALL, ARM ALL, LOCK TRACKS, MUTE ALL, REC MONITOR, SELECT ALL TRACKS, SELECT ALL ITEMS, OUTS FOLLOW FADERS, MIX DOWN, VSC UNITY, mixer view, Fade/Split/Audition/Automation Tools, SETUP/RECORD/VSC/EDIT tabs, TIME LEFT, MIDI SCENE, SHOW FX, FX CHAIN, track height, ZOOM PROJECT, FOLLOW PLAYHEAD, ICON and audition button lights true)
-- @author BSK
-- @version 1.4
-- @about Runs in the background, and starts itself afresh after an error (up to 3 times, then REAPER shows the error). SAFE REC is lit from its press until recording stops, and for that whole time it guards the record drives: under 5 minutes or 5 GB free on a drive in use, it stops and saves (or on Dual, when only one drive is low, moves to the other drive), whether the REC TIME LEFT window is open or not. While the recording project is in a background tab it waits, and picks up again when that tab is in front. NEW TAKE, SAVE REC and DELETE REC flash for three quarters of a second, ADD MARKER for half a second. DELETE REC is lit (orange) while recording, blinks fast for 3 seconds after a first press while recording, and goes dark when recording stops. UNSOLO ALL is lit while any track is soloed. ARM ALL is lit while every track is armed and blinks slowly while only some are. LOCK TRACKS is lit after its press locked every track (dark in the plugin host) and blinks fast for a moment when a press is refused. ARM ALL blinks fast for a moment when some tracks would not arm. MUTE ALL is lit while every track is muted and blinks slowly while only some are; REC MONITOR the same for record monitoring. SELECT ALL TRACKS and SELECT ALL ITEMS are lit while everything is selected. OUTS FOLLOW FADERS is lit while every hardware output is post-fader and blinks slowly while only some are. MIX DOWN is lit while every track goes to the master and blinks slowly while only some do. VSC UNITY is lit while what goes back to the console is as it went in and dark while anything changed; it remembers the setup each time recording stops (not while MIX DOWN is on), re-checks only after a project change or a different project file, and never while recording. The mixer view buttons follow what the mixer is showing. Fade Tools, Split Tools, Audition Tools and Env Tools follow whether their floating toolbar is open. The tabs follow the last tab pressed; TIME LEFT follows whether its window is open. MIDI SCENE follows whether desk scene recalls are switched on. SHOW FX follows whether any track or master plugin window floats, FX CHAIN whether any track or master FX chain window is open. MIN, THIN, NORMAL and BIG light only while every unlocked track has exactly their height (25, 44, 175, 351 px). ZOOM PROJECT lights while the view is still the one its own press gave and the whole project still fits in it. FOLLOW PLAYHEAD is lit while the view follows the play cursor in playback and recording and blinks slowly while only one is on. ICON is lit while any track shows an icon. AUDITION TIME SELECTION, LOOP TIME SELECTION and LOOP AND PLAY ITEM SOLO are lit from their press until playback stops.

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")
local timeLeft = dofile(dir .. "BSK_Time_Left_Common.lua")

if transport.watchAlive() then return end

if reaper.set_action_options then reaper.set_action_options(2) end

local TAKE_FLASH = 0.75
local SAFE_START_GRACE = 2.0
local MIXER_CHECK_EVERY = 0.2
local UNITY_CHECK_EVERY = 0.5

local seenRecording = false
local nextMixerCheck = 0
local trackStates = {}
local nextUnityCheck, lastUnityChange, lastUnityProject, lastUnityFile, lastUnityRate, lastUnityOuts = 0, nil, nil, nil, nil, nil
local wasRecording, recordingProject = false, nil
local unityState = "all"
local guard = timeLeft.newGuard(dir)

local function isLit(id)
  return reaper.GetToggleCommandStateEx(0, reaper.NamedCommandLookup(id)) == 1
end

local function recordingElsewhere()
  return recordingProject ~= nil and recordingProject ~= reaper.EnumProjects(-1)
    and reaper.ValidatePtr(recordingProject, "ReaProject*") and reaper.GetPlayStateEx(recordingProject) & 4 == 4
end

local function tick()
  local now = reaper.time_precise()
  reaper.SetExtState(transport.SECTION, "alive", tostring(now), false)

  local recording = reaper.GetPlayState() & 4 == 4
  if recording then recordingProject = reaper.EnumProjects(-1) end
  if wasRecording and not recording then
    if reaper.EnumProjects(-1) == recordingProject and not transport.mixDownOn() then transport.rememberSetup() end
    lastUnityChange = nil
  end
  wasRecording = recording
  local pressed = tonumber(reaper.GetExtState(transport.SECTION, "safe_pressed"))
  local lit = false
  if pressed then
    if recording then
      seenRecording = true
      lit = true
    elseif not recordingElsewhere() and (seenRecording or now - pressed > SAFE_START_GRACE) then
      reaper.DeleteExtState(transport.SECTION, "safe_pressed", false)
      seenRecording = false
    end
  end
  if isLit(transport.SAFE_ID) ~= lit then
    transport.setLight(transport.SAFE_ID, lit)
  end
  guard.tick(now, lit)

  local flash = tonumber(reaper.GetExtState(transport.SECTION, "take_flash"))
  if flash and now - flash >= TAKE_FLASH then
    reaper.DeleteExtState(transport.SECTION, "take_flash", false)
    flash = nil
  end
  if not flash and isLit(transport.TAKE_ID) then
    transport.setLight(transport.TAKE_ID, false)
  end

  local deleteArmed = tonumber(reaper.GetExtState(transport.SECTION, transport.DELETE_ARMED_KEY))
  if deleteArmed and (not recording or now - deleteArmed > transport.DELETE_ARM_FOR) then
    reaper.DeleteExtState(transport.SECTION, transport.DELETE_ARMED_KEY, false)
    deleteArmed = nil
  end
  for _, id in ipairs(transport.FLASH_BUTTONS) do
    local started = tonumber(reaper.GetExtState(transport.SECTION, "flash" .. id))
    if started and now - started >= (id == transport.MARKER_ID and transport.MARKER_FLASH or TAKE_FLASH) then
      reaper.DeleteExtState(transport.SECTION, "flash" .. id, false)
      started = nil
    end
    if not started then
      local on = false
      if id == transport.DELETE_ID then
        if deleteArmed then on = math.floor((now - deleteArmed) / transport.DELETE_BLINK_EVERY) % 2 == 0 else on = recording end
      end
      if isLit(id) ~= on then transport.setLight(id, on) end
    end
  end

  local keepHidden = tonumber(reaper.GetExtState(transport.SECTION, "keep_mixer_hidden"))
  if keepHidden then
    if reaper.GetToggleCommandStateEx(0, transport.TOGGLE_MIXER) == 1 then
      reaper.Main_OnCommand(transport.TOGGLE_MIXER, 0)
      reaper.DeleteExtState(transport.SECTION, "keep_mixer_hidden", false)
    elseif now > keepHidden then
      reaper.DeleteExtState(transport.SECTION, "keep_mixer_hidden", false)
    end
  end

  local tracksChanged = reaper.GetExtState(transport.SECTION, "tracks_changed") ~= ""
  if tracksChanged then reaper.DeleteExtState(transport.SECTION, "tracks_changed", false) end
  if now >= nextMixerCheck then
    nextMixerCheck = now + MIXER_CHECK_EVERY
    transport.mixerLights()
    transport.toolbarLights()
    transport.midiSceneLight()
    transport.fxLights()
    transport.heightLights()
    transport.zoomLight()
    transport.iconLight()
    transport.auditionLights()
    trackStates = transport.trackLights()
  elseif tracksChanged then
    trackStates = transport.trackLights()
  end
  if tracksChanged then lastUnityChange, nextUnityCheck = nil, 0 end
  if not recording and now >= nextUnityCheck then
    nextUnityCheck = now + UNITY_CHECK_EVERY
    local change = reaper.GetProjectStateChangeCount(0)
    local project, file = reaper.EnumProjects(-1)
    local rate = reaper.Master_GetPlayRate(0)
    local outs = transport.outsSignature()
    if change ~= lastUnityChange or project ~= lastUnityProject or file ~= lastUnityFile or rate ~= lastUnityRate or outs ~= lastUnityOuts then
      lastUnityChange, lastUnityProject, lastUnityFile, lastUnityRate, lastUnityOuts = change, project, file, rate, outs
      unityState = transport.unityState()
    end
  end
  trackStates[transport.UNITY_ID] = unityState
  transport.blinkLights(trackStates)

end

local function loop()
  local ok, problem = pcall(tick)
  if ok then
    reaper.defer(loop)
  elseif (BSK_LIGHTS_WATCH_RESTARTS or 0) < 3 then
    BSK_LIGHTS_WATCH_RESTARTS = (BSK_LIGHTS_WATCH_RESTARTS or 0) + 1
    reaper.DeleteExtState(transport.SECTION, "alive", false)
    dofile(dir .. "BSK_Transport_Lights_Watch.lua")
  else
    reaper.DeleteExtState(transport.SECTION, "alive", false)
    error(problem, 0)
  end
end

reaper.atexit(function()
  reaper.DeleteExtState(transport.SECTION, "alive", false)
  guard.stop()
  transport.setLight(transport.SAFE_ID, false)
  transport.setLight(transport.TAKE_ID, false)
  for _, id in ipairs(transport.FLASH_BUTTONS) do
    transport.setLight(id, false)
  end
  for _, button in ipairs(transport.MIXER_BUTTONS) do
    transport.setLight(button.id, false)
  end
  for _, button in ipairs(transport.TOOLBAR_BUTTONS) do
    transport.setLight(button.id, false)
  end
  transport.setLight(transport.TOOLS_ID, false)
  for _, tab in ipairs(transport.TABS) do
    transport.setLight(tab.id, false)
  end
  transport.setLight(transport.TIME_LEFT_BUTTON_ID, false)
  transport.setLight(transport.SHOW_FX_ID, false)
  transport.setLight(transport.MIDI_SCENE_ID, false)
  transport.setLight(transport.ZOOM_ID, false)
  transport.setLight(transport.FOLLOW_ID, false)
  transport.setLight(transport.ICONS_ID, false)
  reaper.DeleteExtState(transport.SECTION, transport.AUDITION_KEY, false)
  reaper.DeleteExtState(transport.SECTION, transport.AUDITION_KEY .. "_undo", false)
  for _, button in ipairs(transport.AUDITION_BUTTONS) do
    transport.setLight(button.id, false)
  end
  for _, button in ipairs(transport.HEIGHT_BUTTONS) do
    transport.setLight(button.id, false)
  end
  transport.setLight(transport.FX_CHAIN_ID, false)
  transport.setLight(transport.DOCK_ID, false)
  transport.setLight(transport.UNSOLO_ID, false)
  transport.setLight(transport.ARM_ID, false)
  transport.setLight(transport.LOCK_TRACKS_ID, false)
  transport.setLight(transport.MUTE_ID, false)
  transport.setLight(transport.MONITOR_ID, false)
  transport.setLight(transport.SELECT_TRACKS_ID, false)
  transport.setLight(transport.SELECT_ITEMS_ID, false)
  transport.setLight(transport.OUTS_ID, false)
  transport.setLight(transport.MIX_ID, false)
  transport.setLight(transport.UNITY_ID, false)
end)

reaper.SetExtState(transport.SECTION, "alive", tostring(reaper.time_precise()), false)
reaper.defer(loop)
