-- @description BSK Transport: SAFE REC press marker (first step of the Safe Record with Marker custom action)
-- @author BSK
-- @version 1.1
-- @about Notes that SAFE REC was pressed, from the toolbar or anything else that runs the custom action, so the SAFE REC button lights while that recording runs. Also unlocks every locked track first, because REAPER cannot arm a locked track.

if reaper.set_action_options then reaper.set_action_options(3) end
reaper.defer(function() end)

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")

transport.unlockAllTracks()
reaper.SetExtState(transport.SECTION, "safe_pressed", tostring(reaper.time_precise()), false)
transport.ensureWatch()
