-- @description BSK Transport: ARM ALL (lit while every track is armed, slow blink while only some are; press to arm all, or disarm all when lit)
-- @author BSK
-- @version 1.2
-- @about Unlit or blinking: arms every track. Lit: disarms every track, except while recording, when it changes nothing. The light follows the tracks, however they were armed. When some tracks would not arm (REAPER cannot arm a locked track, see LOCK TRACKS) it arms the rest and blinks fast; SAFE REC unlocks every track first.

if reaper.set_action_options then reaper.set_action_options(3) end
reaper.defer(function() end)

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")

transport.armAll()
