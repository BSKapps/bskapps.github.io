-- @description BSK Transport: LOOP TIME SELECTION (loop the time selection; press again to stop)
-- @author BSK
-- @version 1.0
-- @about Plays the time selection from its start, loop on. Lit from the press until playback stops. Pressed lit: stops, puts back the loop setting and any solo the press turned on, and keeps the selections. Does not light while recording.

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")

transport.audition("_RS049bd08fa0260e9130d4186a245d209307741e35")
