-- @description BSK Transport: MIDI SCENE (lit: desk scene recalls drive REAPER; dark: REAPER ignores them)
-- @author BSK
-- @version 1.1
-- @about Lit: the actions a desk scene fires through Companion work (SCENE REC new takes, SAFE REC {MIDI SCENE}, STOP REC {MIDI SCENE}, PAUSE REC {MIDI SCENE}). Dark: they all do nothing, so scenes can be recalled and tweaked without touching REAPER. Your own SAFE REC, TAKE and SAVE REC buttons and Stream Deck keys always work. Remembers how you left it, also after REAPER restarts; lit until first switched off.

if reaper.set_action_options then reaper.set_action_options(3) end
reaper.defer(function() end)

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")

transport.toggleMidiScene()
