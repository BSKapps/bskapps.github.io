-- @description BSK View: ZOOM PROJECT (unlit: zoom out to the whole project; lit: back to the previous zoom)
-- @author BSK
-- @version 1.2
-- @about Unlit: zooms out so the whole project is in view (REAPER's Zoom out project). Lit: goes back to exactly the view it had before the zoom out. Lit only while the view is still the one this press gave and the whole project still fits: scrolling, zooming or recording past the right edge turns it off.

if reaper.set_action_options then reaper.set_action_options(3) end
reaper.defer(function() end)

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")

transport.toggleZoomProject()
