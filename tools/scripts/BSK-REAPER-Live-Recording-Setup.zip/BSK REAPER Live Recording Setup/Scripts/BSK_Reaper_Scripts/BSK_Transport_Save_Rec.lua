-- @description BSK Transport: SAVE REC (stop and save the recording; the button flashes)
-- @author BSK
-- @version 1.0
-- @about Runs FINISH RECORD STOP/SAVE. Flashes for three quarters of a second when it stops a recording. No popup, unless the FINISH RECORD STOP/SAVE custom action is missing: then it says it failed and changes nothing.

if reaper.set_action_options then reaper.set_action_options(3) end
reaper.defer(function() end)

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")

local save = transport.customAction(transport.SAVE_ACTION, "SAVE REC")
if save then transport.stopRecording(transport.SAVE_ID, save) end
