-- @description BSK Transport: SCENE REC (for a console scene change: SAFE REC when stopped, NEW TAKE while recording)
-- @author BSK
-- @version 1.1
-- @about For the Stream Deck TAKE REC key. Not switched by MIDI SCENE, so desk scenes should fire the {MIDI SCENE} actions instead (SAFE REC, STOP REC, PAUSE REC and the SCENE REC custom action). Stopped or playing: does exactly what SAFE REC does (arm all, monitor off, record from the end, marker, SAFE REC lights), and a second press within 1 second is ignored so a double press never cuts a new take straight away. Recording: does exactly what NEW TAKE does (save, carry on from the end of the last take, marker, NEW TAKE flashes).

if reaper.set_action_options then reaper.set_action_options(3) end
reaper.defer(function() end)

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")

if reaper.GetPlayState() & 4 == 4 then
  dofile(dir .. "BSK_Transport_New_Take.lua")
else
  dofile(dir .. "BSK_Transport_Safe_Rec.lua")
  if reaper.GetPlayState() & 4 == 4 then
    reaper.SetExtState("BSK_TRANSPORT", "take_last", tostring(reaper.time_precise()), false)
  end
end
