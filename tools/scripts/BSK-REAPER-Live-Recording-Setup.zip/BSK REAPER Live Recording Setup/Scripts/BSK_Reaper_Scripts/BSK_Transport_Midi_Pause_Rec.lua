-- @description BSK Transport: PAUSE REC {MIDI SCENE} (for a desk scene: pauses only an active recording, with MIDI SCENE on)
-- @author BSK
-- @version 1.0
-- @about For a desk scene to fire through Companion. Actively recording with MIDI SCENE lit: pauses the recording. Already paused, stopped, playing or paused playback: does nothing, so a scene recalled during a VSC rehearsal never pauses the playback and a second pause scene never un-pauses. The next scene's new take carries on recording. Your Pause key and buttons are unchanged.

if reaper.set_action_options then reaper.set_action_options(3) end
reaper.defer(function() end)

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")

if not transport.midiSceneOn() then return end
if reaper.GetPlayState() ~= 5 then return end

reaper.Main_OnCommand(1008, 0) -- Transport: Pause
