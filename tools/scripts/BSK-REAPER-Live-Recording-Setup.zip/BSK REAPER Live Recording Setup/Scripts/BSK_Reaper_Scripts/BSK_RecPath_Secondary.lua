-- @description BSK Rec Path: SECONDARY (record everything to the external drive only)
-- @author BSK
-- @version 1.0
-- @about Sets every track's record path to SECONDARY and lights only this button. The light is read back from the tracks.

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local recpath = dofile(dir .. "BSK_RecPath_Common.lua")

recpath.choose(recpath.SECONDARY)
