-- @description BSK View: BIG HEIGHT (every track to 351 px)
-- @author BSK
-- @version 1.1
-- @about Sets every track to 351 px, whatever the zoom, leaving tracks whose height is locked alone. Lit only while every unlocked track is exactly 351 px, so resizing any track by hand turns it off. When shrinking leaves the view below the tracks, it scrolls back so they stay in sight.

if reaper.set_action_options then reaper.set_action_options(3) end
reaper.defer(function() end)

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")

transport.setHeights("big")
