-- @description BSK View: EDIT tab (hides docked meters, shows the EDIT toolbar)
-- @author BSK
-- @version 1.2
-- @about Hides the meters if they are docked, so the track waveforms have the room (a floating meter bridge stays where it is), then shows the EDIT toolbar (Toolbar 1). Lit while EDIT was the last tab pressed.

if reaper.set_action_options then reaper.set_action_options(3) end
reaper.defer(function() end)

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")

transport.editTab()
