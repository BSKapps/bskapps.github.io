-- @description BSK Transport: MIX DOWN (lit while every track goes to the master, slow blink while only some do; press to set up a mixdown or put it all back, asks first; blinking with nothing of its own to put back lists the tracks on the master to take off)
-- @author BSK
-- @version 1.2
-- @about Every track, no selection needed. Unlit, or lit with every track on the master by hand: remembers each track's setup, then sends every track to the master, mutes its hardware outputs, turns record monitoring off and turns pre-fader metering off. After it set up a mixdown (lit, or blinking once some tracks changed): puts master sends, hardware output mutes and record monitoring back exactly as they were, and the meters back to how they were unless OUTS FOLLOW FADERS is on (the meters are post-fader while either is on). Both ask first (OK/Cancel). Blinking with no mixdown of its own to put back: a window lists the tracks that go to the master. Take Off Master turns their master send off and VSC UNITY keeps them as fine, Set Up Mix Down sets up the mixdown, Cancel changes nothing. Does nothing while recording. One undo. It also shows the master track in the mixer while the mixdown is on, and hides it again afterwards if it was hidden before.

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")

if reaper.GetPlayState() & 4 == 4 then return end

local strays = transport.mixStrays()
if not strays then
  transport.mixDown()
  return
end

local TITLE = "Mix Down"
local W, PAD, ROWS_Y, ROW_H, NOTE_H, BTN_H = 480, 12, 38, 22, 18, 28
local ACCENT = "#2FA39A"
local project, projectFile = reaper.EnumProjects(-1)

local lines = {}
for i = 1, math.min(#strays, transport.UNITY_LIST_MAX) do lines[i] = strays[i].line end
if #strays > #lines then lines[#lines + 1] = "...and " .. (#strays - #lines) .. " more" end

local buttons = { { label = "Take Off Master", choice = "take_off" }, { label = "Set Up Mix Down", choice = "setup" }, { label = "Cancel" } }
local note = "Take Off Master changes only the tracks listed."

local height = ROWS_Y + #lines * ROW_H + 6 + NOTE_H + 12 + BTN_H + 12
local scale, hits, wasDown, pressedKey = 1, {}, false, nil

local function setColor(hex, alpha)
  local r, g, b = hex:match("^#(%x%x)(%x%x)(%x%x)$")
  gfx.set(tonumber(r, 16) / 255, tonumber(g, 16) / 255, tonumber(b, 16) / 255, alpha or 1)
end

local function fillRound(x, y, w, h, r)
  x, y, w, h, r = x * scale, y * scale, w * scale, h * scale, r * scale
  gfx.rect(x + r, y, w - 2 * r, h, 1)
  gfx.rect(x, y + r, w, h - 2 * r, 1)
  gfx.circle(x + r, y + r, r, 1, 1)
  gfx.circle(x + w - r - 1, y + r, r, 1, 1)
  gfx.circle(x + r, y + h - r - 1, r, 1, 1)
  gfx.circle(x + w - r - 1, y + h - r - 1, r, 1, 1)
end

local function frameRound(x, y, w, h, r)
  gfx.roundrect(x * scale, y * scale, w * scale, h * scale, r * scale, 1)
end

local function fitText(text, width)
  if gfx.measurestr(text) <= width then return text end
  while #text > 0 and gfx.measurestr(text .. "...") > width do text = text:sub(1, -2) end
  return text .. "..."
end

local function drawText(text, x, y, w, h, flags)
  gfx.x, gfx.y = x * scale, y * scale
  gfx.drawstr(fitText(text, w * scale), flags, (x + w) * scale, (y + h) * scale)
end

local function addHit(key, x, y, w, h, action)
  hits[#hits + 1] = { key = key, x = x, y = y, w = w, h = h, action = action }
end

local function setFont(size)
  gfx.setfont(1, "Arial", size * scale)
end

local function button(key, label, x, y, w, h, primary, action)
  setColor(primary and ACCENT or "#444444")
  fillRound(x, y, w, h, 4)
  if not primary then
    setColor("#666666")
    frameRound(x, y, w, h, 4)
  end
  setColor(primary and "#FFFFFF" or "#DDDDDD")
  drawText(label, x, y, w, h, 5)
  addHit(key, x, y, w, h, action)
end

local function choose(chosen)
  local nowProject, nowFile = reaper.EnumProjects(-1)
  if chosen.choice and nowProject == project and nowFile == projectFile then
    if chosen.choice == "take_off" then transport.takeOffMaster(strays) else transport.mixDown(transport.mixStrays() ~= nil) end
  end
  return true
end

local function draw()
  scale = (gfx.ext_retina and gfx.ext_retina > 0) and gfx.ext_retina or 1
  hits = {}
  setColor("#2B2B2B")
  gfx.rect(0, 0, gfx.w, gfx.h, 1)

  setFont(14)
  setColor("#EEEEEE")
  drawText("Only these tracks go to the master:", PAD, 12, W - 2 * PAD, 18, 4)

  setFont(13)
  setColor("#DDDDDD")
  for i, line in ipairs(lines) do
    drawText(line, PAD, ROWS_Y + (i - 1) * ROW_H, W - 2 * PAD, ROW_H, 4)
  end

  local y = ROWS_Y + #lines * ROW_H + 6
  setFont(12)
  setColor("#999999")
  drawText(note, PAD, y, W - 2 * PAD, NOTE_H, 4)

  y = y + NOTE_H + 12
  setFont(13)
  local buttonW = (W - 2 * PAD - (#buttons - 1) * 8) / #buttons
  for i, b in ipairs(buttons) do
    button(i, b.label, PAD + (i - 1) * (buttonW + 8), y, buttonW, BTN_H, i == 1, function() return choose(b) end)
  end
end

local function hitAt(x, y)
  for i = #hits, 1, -1 do
    local hit = hits[i]
    if x >= hit.x and x < hit.x + hit.w and y >= hit.y and y < hit.y + hit.h then return hit end
  end
  return nil
end

local function loop()
  local char = gfx.getchar()
  if char < 0 or char == 27 then
    gfx.quit()
    return
  end
  if char == 13 then
    choose(buttons[1])
    gfx.quit()
    return
  end

  draw()

  local x, y = gfx.mouse_x / scale, gfx.mouse_y / scale
  local down = (gfx.mouse_cap & 1) == 1
  if down and not wasDown then
    local hit = hitAt(x, y)
    pressedKey = hit and hit.key
  elseif wasDown and not down then
    local hit = hitAt(x, y)
    local key = pressedKey
    pressedKey = nil
    if hit and key and hit.key == key and hit.action() then
      gfx.quit()
      return
    end
  end
  wasDown = down

  gfx.update()
  reaper.defer(loop)
end

if reaper.set_action_options then reaper.set_action_options(3) end

local mouseX, mouseY = reaper.GetMousePosition()
gfx.ext_retina = 1
gfx.init(TITLE, W, height, 0, mouseX - W / 2, mouseY - height / 2)
reaper.defer(loop)
