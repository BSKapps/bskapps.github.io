-- @description BSK: REMOVE SILENT TAKES (find recorded takes with no sound and remove them with their files)
-- @author BSK
-- @version 1.1
-- @about Find Silent Takes listens to every take on every track, whatever is selected, and lists the ones whose loudest moment stays below the Silent below level for the whole take. Remove takes those takes out in one undo; tracks, names, routing and every other take stay exactly where they are. Their files go to the Trash, where Finder can put them back; a file stays when another take in any open project uses it, or another project file names it (in the project or recording folder or up to 3 subfolders below, or in REAPER's recent projects list), when a take is trimmed, slipped or a section of its file, or was listed under File stays, or when it is not directly in the project or recording folder. Files that are missing, video or subprojects are never listed. An undo brings the takes back offline until their files come back out of the Trash. Takes with more than one take, MIDI, locked, playing only some of their channels or a mono downmix of a stereo or wider file, sped up, slowed down, stretched, reversed, looped past the end of their file or with their volume changed are never listed. Change Settings opens the settings page: Change Value sets the level, and it is remembered; Reset Settings puts back -45 dB. Find Silent Takes first lets REAPER finish building any missing peaks. Both refuse while recording, playing or paused, and in a project whose file name contains PLUGIN HOST. The window closes when recording starts or the project changes tab, and after a remove.

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local silent = dofile(dir .. "BSK_Remove_Silent_Takes_Common.lua")

local TITLE = silent.TITLE
local W, PAD, ROWS_Y, ROW_H, NOTE_H, BTN_H = 520, 12, 38, 22, 18, 28
local START_HEIGHT = ROWS_Y + 2 * ROW_H + 6 + 4 * NOTE_H + 12 + BTN_H + 12
local ACCENT = "#2FA39A"
local BOX_PAD, BOX_TITLE_H, BOX_GAP = 10, 20, 10
local LIST_MAX = 20
local SCAN_BUDGET = 0.008
local PROGRESS_EVERY = 0.2
local COLUMNS = { { 0, 28, 4 }, { 28, 130, 4 }, { 158, 120, 4 }, { 278, 100, 4 }, { 378, 118, 6 } }
local REASON_COLUMN = { 348, 148, 6 }
local HEADING_TRASH = "FILE GOES TO THE TRASH"
local HEADING_KEPT = "FILE STAYS (TAKE REMOVED, FILE NOT TOUCHED)"

local proj, projectFile = reaper.EnumProjects(-1)

local blockedReason, blockedFix = silent.blocked(proj, projectFile)
if blockedReason then
  reaper.ShowMessageBox(silent.failure("open Remove Silent Takes", blockedReason, blockedFix), TITLE, 0)
  return
end

local scan, scanDb, scanTracks, scanStarted, scanNote, status, results, settingsOpen
local scale, hits, wasDown, pressedKey = 1, {}, false, nil
local dirty, signature, lastProgress, lastW, lastH = true, nil, 0, nil, nil
local content
local heldList, heldHeight = nil, 0

local function plural(count, one, many)
  return count == 1 and one or many
end

local function setStatus(text)
  status = text
  dirty = true
end

local function close()
  return true
end

local function quit()
  if scan then
    silent.stopScan(scan)
    scan = nil
  end
  gfx.quit()
end

local function everyTrack()
  local tracks = {}
  for i = 0, reaper.CountTracks(proj) - 1 do tracks[#tracks + 1] = reaper.GetTrack(proj, i) end
  return tracks
end

local function find()
  local reason, fix = silent.blocked(proj, projectFile)
  if reason then return setStatus(silent.failure("find silent takes", reason, fix)) end
  local tracks = everyTrack()
  if #tracks == 0 then return setStatus(silent.failure("find silent takes", "there are no tracks to listen to.")) end
  scanDb = silent.db()
  scanTracks = #tracks
  scanStarted = reaper.time_precise()
  scan = silent.startScan(proj, tracks, scanDb)
  setStatus(nil)
end

local function openSettings()
  settingsOpen = true
  setStatus(nil)
end

local function closeSettings()
  settingsOpen = false
  setStatus(nil)
end

local function resetSettings()
  silent.saveDb(silent.DEFAULT_DB)
  setStatus(nil)
end

local function changeSettings()
  local ok, text = reaper.GetUserInputs(TITLE .. " Settings", 1, "Silent below (dB)", silent.formatNumber(silent.db()))
  if not ok then return end
  local db, problem = silent.parseDb(text)
  if not db then return setStatus(problem) end
  silent.saveDb(db)
  setStatus(nil)
end

local function removeTakes()
  local reason, fix = silent.blocked(proj, projectFile)
  if reason then return setStatus(silent.failure("remove silent takes", reason, fix)) end
  if reaper.GetProjectStateChangeCount(proj) ~= results.change then
    results = nil
    return setStatus(silent.failure("remove silent takes", "the project changed after Find Silent Takes.", "Press Find Silent Takes again."))
  end
  local shown = {}
  for file in pairs(results.files) do shown[file:lower()] = true end
  local files = {}
  for file, size in pairs(silent.filesToTrash(proj, projectFile, results.found)) do
    if shown[file:lower()] then files[file] = size end
  end
  silent.remove(proj, results.found)
  local left = silent.trash(files)
  if left > 0 then
    reaper.ShowMessageBox(silent.failure("move " .. left .. plural(left, " file", " files") .. " to the Trash", "macOS did not move "
      .. plural(left, "it", "them") .. ".", "The takes are removed. Their files are still where they were."), TITLE, 0)
  end
  return true
end

local function stepScanning()
  local state, value = silent.stepScan(scan, SCAN_BUDGET)
  if state == "running" then
    local now = reaper.time_precise()
    if now - lastProgress >= PROGRESS_EVERY then
      lastProgress = now
      dirty = true
    end
    return
  end
  scan = nil
  if state == "done" then
    if #value == 0 then
      local who = scanTracks == 1 and "the track" or ("the " .. scanTracks .. " tracks")
      return setStatus("No silent takes found on " .. who .. ".")
    end
    local files, reasons = silent.filesToTrash(proj, projectFile, value)
    results = { found = value, change = reaper.GetProjectStateChangeCount(proj), files = files, reasons = reasons }
    setStatus(nil)
    scanNote = string.format("Listened to %d %s in %.1f s.", scanTracks, plural(scanTracks, "track", "tracks"), reaper.time_precise() - scanStarted)
    return
  elseif state == "unreadable" then
    return setStatus(silent.failure("find silent takes", "the audio on " .. silent.trackLabel(value) .. " cannot be read yet.",
      "Check that its audio file is there, wait a moment, then try again."))
  elseif state == "changed" then
    return setStatus(silent.failure("find silent takes", "the project changed while listening.", "Press Find Silent Takes again."))
  end
  return setStatus(silent.failure("find silent takes", "something went wrong while listening.", "Press Find Silent Takes again."))
end

local function statusLines(fallback)
  if not status then return fallback end
  local lines = {}
  for line in (status .. "\n"):gmatch("([^\n]*)\n") do
    if line ~= "" then lines[#lines + 1] = line end
  end
  return lines
end

local function contentA()
  local total = reaper.CountTracks(proj)
  local listening
  if total == 1 then
    listening = "Listening to:  the only track"
  else
    listening = "Listening to:  all " .. total .. " tracks"
  end
  return {
    header = "Finds recordings with no sound and removes them to save space.",
    rows = {
      "Silent:  loudest moment below " .. silent.formatNumber(silent.db()) .. " dB for the whole take",
      listening,
    },
    notes = statusLines({ "Find Silent Takes only lists them. Nothing is removed yet." }),
    buttons = {
      { label = "Find Silent Takes", action = find },
      { label = "Change Settings", action = openSettings },
      { label = "Close", action = close },
    },
    enter = 1,
  }
end

local function contentSettings()
  return {
    header = "Remove Silent Takes settings",
    rows = { "Silent below:  " .. silent.formatNumber(silent.db()) .. " dB" },
    notes = statusLines({ "Default: " .. silent.formatNumber(silent.DEFAULT_DB) .. " dB." }),
    buttons = {
      { label = "Change Value", action = changeSettings },
      { label = "Reset Settings", action = resetSettings },
      { label = "Back", action = closeSettings },
    },
    enter = 1,
  }
end

local function contentScanning()
  return {
    header = "Listening... track " .. math.min(scan.done + 1, scan.total) .. " of " .. scan.total .. ".",
    rows = {},
    notes = { "Close stops it and removes nothing." },
    buttons = { { label = "Close", action = close } },
  }
end

local function contentB()
  local trashRows, keptRows, trackCount, bytes, fileCount = silent.rows(results.found, results.files, results.reasons)
  local count = #results.found
  local header = count .. plural(count, " silent take on ", " silent takes on ") .. trackCount .. plural(trackCount, " track. ", " tracks. ")
  if fileCount == 0 then
    header = header .. "No files go to the Trash."
  else
    header = header .. fileCount .. plural(fileCount, " file goes", " files go") .. " to the Trash, " .. silent.size(bytes) .. "."
  end
  local shown, left = {}, LIST_MAX
  if #trashRows + #keptRows <= LIST_MAX + 1 then left = LIST_MAX + 1 end
  for _, group in ipairs({ { HEADING_TRASH, trashRows }, { HEADING_KEPT, keptRows } }) do
    if #group[2] > 0 and left > 0 then
      shown[#shown + 1] = { heading = group[1] }
      for i = 1, math.min(left, #group[2]) do shown[#shown + 1] = group[2][i] end
      left = left - math.min(left, #group[2])
    end
  end
  if left == 0 and #trashRows + #keptRows > LIST_MAX + 1 then
    shown[#shown + 1] = "...and " .. (#trashRows + #keptRows - LIST_MAX) .. " more"
  end
  local notes = { "Tracks, names, routing and every other take stay exactly where they are." }
  if #keptRows > 0 then notes[#notes + 1] = "A file that stays is not touched." end
  if fileCount > 0 then notes[#notes + 1] = "The files go to the Trash (Finder can put them back)." end
  for _, line in ipairs(statusLines({})) do notes[#notes + 1] = line end
  if scanNote and not status then notes[#notes + 1] = scanNote end
  local box
  if fileCount > 0 then
    box = { title = "Save after removing.", lines = { "If you close without saving, REAPER asks for the missing files." }, fix = "Put Back in the Trash restores them." }
  end
  return {
    list = true,
    header = header,
    rows = shown,
    box = box,
    notes = notes,
    buttons = {
      { label = "Remove " .. count .. plural(count, " Take", " Takes"), action = removeTakes },
      { label = "Cancel", action = close },
    },
  }
end

local function buildContent()
  if scan then return contentScanning() end
  if results and reaper.GetProjectStateChangeCount(proj) ~= results.change then
    results = nil
    scanNote = nil
    status = "The project changed. Press Find Silent Takes again."
  end
  if results then return contentB() end
  if settingsOpen then return contentSettings() end
  return contentA()
end

local function setColor(hex, alpha)
  local r, g, b = hex:match("^#(%x%x)(%x%x)(%x%x)$")
  gfx.set(tonumber(r, 16) / 255, tonumber(g, 16) / 255, tonumber(b, 16) / 255, alpha or 1)
end

local function fillRound(x, y, w, h, r)
  x, y, w, h, r = x * scale, y * scale, w * scale, h * scale, r * scale
  gfx.rect(x + r, y, w - 2 * r, h, 1)
  gfx.rect(x, y + r, w, h - 2 * r, 1)
  gfx.circle(x + r, y + r, r, 1, 1)
  gfx.circle(x + w - r - 1, y + r, r, 1, 1)
  gfx.circle(x + r, y + h - r - 1, r, 1, 1)
  gfx.circle(x + w - r - 1, y + h - r - 1, r, 1, 1)
end

local function frameRound(x, y, w, h, r)
  gfx.roundrect(x * scale, y * scale, w * scale, h * scale, r * scale, 1)
end

local function fitText(text, width)
  if gfx.measurestr(text) <= width then return text end
  while #text > 0 and gfx.measurestr(text .. "...") > width do text = text:sub(1, -2) end
  return text .. "..."
end

local function drawText(text, x, y, w, h, flags)
  gfx.x, gfx.y = x * scale, y * scale
  gfx.drawstr(fitText(text, w * scale), flags, (x + w) * scale, (y + h) * scale)
end

local function setFont(size, bold)
  if bold then
    gfx.setfont(1, "Arial", size * scale, string.byte("b"))
  else
    gfx.setfont(1, "Arial", size * scale)
  end
end

local function wrap(lines, width)
  local out = {}
  for _, line in ipairs(lines) do
    local current = ""
    for word in line:gmatch("%S+") do
      local candidate = current == "" and word or (current .. " " .. word)
      if current ~= "" and gfx.measurestr(candidate) > width * scale then
        out[#out + 1] = current
        current = word
      else
        current = candidate
      end
    end
    if current ~= "" then out[#out + 1] = current end
  end
  return out
end

local function addHit(key, x, y, w, h, action)
  hits[#hits + 1] = { key = key, x = x, y = y, w = w, h = h, action = action }
end

local function button(key, label, x, y, w, h, primary, action)
  setColor(primary and ACCENT or "#444444")
  fillRound(x, y, w, h, 4)
  if not primary then
    setColor("#666666")
    frameRound(x, y, w, h, 4)
  end
  setColor(primary and "#FFFFFF" or "#DDDDDD")
  drawText(label, x, y, w, h, 5)
  addHit(key, x, y, w, h, action)
end

local function boxLayout(box)
  if not box then return nil end
  local width = W - 2 * PAD - 2 * BOX_PAD
  setFont(12)
  local lines = wrap(box.lines, width)
  local fixLines = wrap({ box.fix }, width)
  return { lines = lines, fixLines = fixLines, width = width, h = BOX_PAD + BOX_TITLE_H + (#lines + #fixLines) * NOTE_H + BOX_PAD }
end

local function drawBox(box, layout, y)
  setColor("#3A3224")
  fillRound(PAD, y, W - 2 * PAD, layout.h, 4)
  setColor("#D6A03C")
  frameRound(PAD, y, W - 2 * PAD, layout.h, 4)
  local x = PAD + BOX_PAD
  local lineY = y + BOX_PAD
  setFont(13, true)
  setColor("#F0BE5A")
  drawText(box.title, x, lineY, layout.width, BOX_TITLE_H, 4)
  lineY = lineY + BOX_TITLE_H
  setFont(12)
  setColor("#E6E6E6")
  for _, line in ipairs(layout.lines) do
    drawText(line, x, lineY, layout.width, NOTE_H, 4)
    lineY = lineY + NOTE_H
  end
  setColor("#BEBEBE")
  for _, line in ipairs(layout.fixLines) do
    drawText(line, x, lineY, layout.width, NOTE_H, 4)
    lineY = lineY + NOTE_H
  end
end

local function draw()
  scale = (gfx.ext_retina and gfx.ext_retina > 0) and gfx.ext_retina or 1
  content = buildContent()
  local layout = boxLayout(content.box)
  local boxH = layout and (layout.h + BOX_GAP) or 0
  setFont(12)
  local notes = wrap(content.notes, W - 2 * PAD)
  local needed = ROWS_Y + #content.rows * ROW_H + 6 + boxH + #notes * NOTE_H + 12 + BTN_H + 12
  if content.list ~= heldList then heldList, heldHeight = content.list, 0 end
  heldHeight = math.max(heldHeight, START_HEIGHT, needed)
  local height = heldHeight
  if math.abs(gfx.h / scale - height) > 1 then gfx.init("", W, height) end

  hits = {}
  setColor("#2B2B2B")
  gfx.rect(0, 0, gfx.w, gfx.h, 1)

  setFont(14)
  setColor("#EEEEEE")
  drawText(content.header, PAD, 12, W - 2 * PAD, 18, 4)

  setFont(13)
  setColor("#DDDDDD")
  for i, row in ipairs(content.rows) do
    local y = ROWS_Y + (i - 1) * ROW_H
    if type(row) == "table" and row.heading then
      setFont(11, true)
      setColor("#8C8C8C")
      drawText(row.heading, PAD, y, W - 2 * PAD, ROW_H, 4)
      setFont(13)
      setColor("#DDDDDD")
    elseif type(row) == "table" then
      for c = 1, 4 do drawText(row[c], PAD + COLUMNS[c][1], y, COLUMNS[c][2], ROW_H, COLUMNS[c][3]) end
      if row.stays then
        setFont(12)
        setColor("#AAAAAA")
        drawText(row[5], PAD + REASON_COLUMN[1], y, REASON_COLUMN[2], ROW_H, REASON_COLUMN[3])
        setFont(13)
        setColor("#DDDDDD")
      else
        drawText(row[5], PAD + COLUMNS[5][1], y, COLUMNS[5][2], ROW_H, COLUMNS[5][3])
      end
    else
      drawText(row, PAD, y, W - 2 * PAD, ROW_H, 4)
    end
  end

  local y = ROWS_Y + #content.rows * ROW_H + 6
  if layout then
    drawBox(content.box, layout, y)
    y = y + boxH
  end
  setFont(12)
  setColor(status and "#DDDDDD" or "#999999")
  for i, line in ipairs(notes) do
    drawText(line, PAD, y + (i - 1) * NOTE_H, W - 2 * PAD, NOTE_H, 4)
  end

  y = height - 12 - BTN_H
  setFont(13)
  local count = #content.buttons
  local buttonW = (W - 2 * PAD - (count - 1) * 8) / count
  for i, b in ipairs(content.buttons) do
    button(i, b.label, PAD + (i - 1) * (buttonW + 8), y, buttonW, BTN_H, i == 1 and count > 1, b.action)
  end
end

local function hitAt(x, y)
  for i = #hits, 1, -1 do
    local hit = hits[i]
    if x >= hit.x and x < hit.x + hit.w and y >= hit.y and y < hit.y + hit.h then return hit end
  end
  return nil
end

local function loop()
  local char = gfx.getchar()
  if char < 0 or char == 27 or silent.anyRecording() or not silent.sameProject(proj, projectFile) then
    quit()
    return
  end

  if scan then stepScanning() end

  local now = reaper.GetProjectStateChangeCount(proj) .. "|" .. reaper.CountSelectedTracks2(proj, false) .. "|" .. reaper.CountTracks(proj)
  if now ~= signature then
    signature = now
    dirty = true
  end

  if char == 13 and content and content.enter then
    if content.buttons[content.enter].action() then
      quit()
      return
    end
    dirty = true
  end

  local x, y = gfx.mouse_x / scale, gfx.mouse_y / scale
  local down = (gfx.mouse_cap & 1) == 1
  if down and not wasDown then
    local hit = hitAt(x, y)
    pressedKey = hit and hit.key
  elseif wasDown and not down then
    local hit = hitAt(x, y)
    local key = pressedKey
    pressedKey = nil
    if hit and key and hit.key == key then
      if hit.action() then
        quit()
        return
      end
      dirty = true
    end
  end
  wasDown = down

  if dirty or gfx.w ~= lastW or gfx.h ~= lastH then
    draw()
    dirty = false
    lastW, lastH = gfx.w, gfx.h
  end

  gfx.update()
  reaper.defer(loop)
end

if reaper.set_action_options then reaper.set_action_options(3) end

local startContent = buildContent()
local startHeight = math.max(START_HEIGHT, ROWS_Y + #startContent.rows * ROW_H + 6 + #startContent.notes * NOTE_H + 12 + BTN_H + 12)
local mouseX, mouseY = reaper.GetMousePosition()
reaper.atexit(function() silent.stopScan(scan) end)
gfx.ext_retina = 1
gfx.init(TITLE, W, startHeight, 0, mouseX - W / 2, mouseY - startHeight / 2)
reaper.defer(loop)
