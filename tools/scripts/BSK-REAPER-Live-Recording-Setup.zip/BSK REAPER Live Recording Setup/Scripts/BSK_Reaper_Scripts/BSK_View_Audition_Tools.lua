-- @description BSK View: AUDITION TOOLS (unlit: open Toolbar 5 AUDITION at the mouse; lit: close it)
-- @author BSK
-- @version 1.1
-- @about Unlit: opens the floating Toolbar 5 AUDITION at the mouse. Lit: closes it. The light follows the toolbar, so closing it with its own close button turns the light off and the next press opens it at the mouse again.

if reaper.set_action_options then reaper.set_action_options(3) end
reaper.defer(function() end)

local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])")
local transport = dofile(dir .. "BSK_Transport_Common.lua")

transport.toggleToolbar(3)
