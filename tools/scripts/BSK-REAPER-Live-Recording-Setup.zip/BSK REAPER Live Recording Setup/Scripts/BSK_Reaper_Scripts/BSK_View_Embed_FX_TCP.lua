-- @description BSK: SHOW PLUGIN CONTROLS IN THE TRACK PANEL
-- @author BSK
-- @version 1.0
-- @about First press shows the plugin controls in the track panel and lights; the next press hides them and goes dark.

if reaper.set_action_options then reaper.set_action_options(3) end
reaper.defer(function() end)

local _, _, section, id = reaper.get_action_context()
local on = reaper.GetToggleCommandStateEx(section, id) == 1
reaper.Main_OnCommand(on and 42341 or 42340, 0)
reaper.SetToggleCommandState(section, id, on and 0 or 1)
reaper.RefreshToolbar2(section, id)
