$ErrorActionPreference = "Stop"

$Src = Split-Path -Parent $MyInvocation.MyCommand.Path
$Rez = Join-Path $env:APPDATA "REAPER"
$Stamp = Get-Date -Format "yyyyMMdd-HHmmss"

Write-Host "BSK REAPER Live Recording Setup installer"
Write-Host ""

if (Get-Process -Name "reaper" -ErrorAction SilentlyContinue) {
    Write-Host "REAPER is running. Quit REAPER first, then run this installer again."
    exit 1
}

if (-not (Test-Path $Rez)) {
    Write-Host "REAPER resource folder not found at:"
    Write-Host "  $Rez"
    Write-Host "Run REAPER once first. For portable installs, use the manual"
    Write-Host "steps in README.txt instead."
    exit 1
}

Write-Host "Installing into: $Rez"
Write-Host ""

foreach ($d in "ProjectTemplates", "TrackTemplates", "FXChains", "Scripts", "Data\toolbar_icons", "ColorThemes") {
    New-Item -ItemType Directory -Force -Path (Join-Path $Rez $d) | Out-Null
}

Copy-Item (Join-Path $Src "ProjectTemplates\*.RPP")          (Join-Path $Rez "ProjectTemplates") -Force
Copy-Item (Join-Path $Src "TrackTemplates\*.RTrackTemplate") (Join-Path $Rez "TrackTemplates") -Force
Copy-Item (Join-Path $Src "FXChains\*.RfxChain")             (Join-Path $Rez "FXChains") -Force
Copy-Item (Join-Path $Src "Scripts\BSK_Reaper_Scripts")      (Join-Path $Rez "Scripts") -Recurse -Force
Copy-Item (Join-Path $Src "Data\toolbar_icons\*.png")        (Join-Path $Rez "Data\toolbar_icons") -Force
Copy-Item (Join-Path $Src "ColorThemes\*.ReaperThemeZip")    (Join-Path $Rez "ColorThemes") -Force
Write-Host "Copied templates, FX chains, scripts, toolbar icons and theme."

$Screensets = Join-Path $Rez "reaper-screensets.ini"
if (Test-Path $Screensets) {
    Copy-Item $Screensets "$Screensets.backup-$Stamp"
    Write-Host "Backed up your existing window sets to reaper-screensets.ini.backup-$Stamp"
}
Copy-Item (Join-Path $Src "WindowSets\reaper-screensets.ini") $Screensets -Force
Write-Host "Installed window sets (meter bridge and mixer views)."

function Merge-Section($Ini, $Section, $SrcFile) {
    if (Test-Path $Ini) {
        Copy-Item $Ini "$Ini.backup-$Stamp"
        $lines = Get-Content $Ini
    } else {
        $lines = @()
    }
    $out = @()
    $skip = $false
    foreach ($line in $lines) {
        if ($line -eq "[$Section]") { $skip = $true; continue }
        if ($line -match '^\[')     { $skip = $false }
        if (-not $skip)             { $out += $line }
    }
    $found = $false
    foreach ($line in Get-Content $SrcFile) {
        if ($line -eq "[$Section]") { $found = $true }
        elseif ($found -and $line -match '^\[') { break }
        if ($found) { $out += $line }
    }
    $out += ""
    Set-Content -Path $Ini -Value $out
}

Merge-Section (Join-Path $Rez "S&M.ini") "TrackTemplates" (Join-Path $Src "Toolbars\SWS-Resources-TrackTemplates.txt")
Write-Host "Filled the SWS Resources track template list (slots 1-9)."

Merge-Section (Join-Path $Rez "reaper-themeconfig.ini") "Default_5.0_green_yellow_red_VU" (Join-Path $Src "WindowSets\reaper-themeconfig.ini")
Write-Host "Installed theme colour calibration."

Write-Host ""
Write-Host "Done. Finish inside REAPER (see README.txt):"
Write-Host "  1. Actions > Show action list > Key map... > Import...  -> Toolbars/BSK_Actions.ReaperKeyMap"
Write-Host "  2. Extensions > Cycle Action editor > Import/export > Import all sections -> Toolbars/BSK_Cyclactions.ini"
Write-Host "  3. Right-click each toolbar > Customize toolbar... > Import... -> matching file in Toolbars/"
Write-Host "  4. Options > Themes > Default_5.0_green_yellow_red_VU"
