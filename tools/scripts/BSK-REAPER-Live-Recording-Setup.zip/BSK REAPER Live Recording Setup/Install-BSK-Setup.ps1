$ErrorActionPreference = "Stop"

$Src = Split-Path -Parent $MyInvocation.MyCommand.Path
$Rez = if ($env:BSK_INSTALL_REZ) { $env:BSK_INSTALL_REZ } else { Join-Path $env:APPDATA "REAPER" }
$Stamp = Get-Date -Format "yyyyMMdd-HHmmss"

Write-Host "BSK REAPER Live Recording Setup installer"
Write-Host ""

if ($env:BSK_INSTALL_FORCE -ne "1" -and (Get-Process -Name "reaper" -ErrorAction SilentlyContinue)) {
    Write-Host "REAPER is running. Quit REAPER first, then run this installer again."
    exit 1
}

if (-not (Test-Path (Join-Path $Rez "reaper.ini"))) {
    Write-Host "REAPER resource folder not found at:"
    Write-Host "  $Rez"
    Write-Host "Start REAPER once and quit it, then run this installer again."
    Write-Host "For a portable REAPER, use the Portable download instead."
    exit 1
}

Write-Host "Installing into: $Rez"
Write-Host ""

$Utf8 = New-Object System.Text.UTF8Encoding($false)
function Write-Lines($Path, $Lines) { [System.IO.File]::WriteAllLines($Path, [string[]]$Lines, $Utf8) }
function Src-Lines($Path) { return [System.IO.File]::ReadAllLines($Path, $Utf8) }

function Backup($Path) {
    if (Test-Path -LiteralPath $Path) { Copy-Item -LiteralPath $Path "$Path.backup-$Stamp" }
}

foreach ($d in "ProjectTemplates", "TrackTemplates", "FXChains", "Scripts\BSK_Reaper_Scripts", "ColorThemes",
               "Data\toolbar_icons\150", "Data\toolbar_icons\200") {
    New-Item -ItemType Directory -Force -Path (Join-Path $Rez $d) | Out-Null
}

Copy-Item (Join-Path $Src "ProjectTemplates\*.RPP")              (Join-Path $Rez "ProjectTemplates") -Force
Copy-Item (Join-Path $Src "TrackTemplates\*.RTrackTemplate")     (Join-Path $Rez "TrackTemplates") -Force
Copy-Item (Join-Path $Src "FXChains\*.RfxChain")                 (Join-Path $Rez "FXChains") -Force
Copy-Item (Join-Path $Src "Scripts\BSK_Reaper_Scripts\*.lua")    (Join-Path $Rez "Scripts\BSK_Reaper_Scripts") -Force
Copy-Item (Join-Path $Src "Data\toolbar_icons\*.png")            (Join-Path $Rez "Data\toolbar_icons") -Force
Copy-Item (Join-Path $Src "Data\toolbar_icons\150\*.png")        (Join-Path $Rez "Data\toolbar_icons\150") -Force
Copy-Item (Join-Path $Src "Data\toolbar_icons\200\*.png")        (Join-Path $Rez "Data\toolbar_icons\200") -Force
Copy-Item (Join-Path $Src "ColorThemes\*.ReaperThemeZip")        (Join-Path $Rez "ColorThemes") -Force
Write-Host "Copied templates, FX chains, scripts, toolbar icons and theme."

$Startup = Join-Path $Rez "Scripts\__startup.eel"
$OurStartup = Join-Path $Src "Scripts\__startup.eel"
if (-not (Test-Path -LiteralPath $Startup)) {
    Copy-Item -LiteralPath $OurStartup $Startup
    Write-Host "Added the startup file that lights the toolbar buttons at launch."
} elseif (Select-String -LiteralPath $Startup -SimpleMatch "_RSc33c09db3647fbb75a92022edef4d9d24ceb880e" -Quiet) {
    Write-Host "Startup file already starts the BSK lights."
} else {
    Backup $Startup
    $add = @("") + (Src-Lines $OurStartup | Where-Object { $_ -notmatch '^//' })
    [System.IO.File]::AppendAllLines($Startup, [string[]]$add, $Utf8)
    Write-Host "Added the BSK lights to your existing startup file (backup next to it)."
}

$Screensets = Join-Path $Rez "reaper-screensets.ini"
Backup $Screensets
Copy-Item (Join-Path $Src "WindowSets\reaper-screensets.ini") $Screensets -Force
Write-Host "Installed window sets (meter bridge and mixer views)."

function Read-Lines($Path) {
    if (Test-Path -LiteralPath $Path) { return @([System.IO.File]::ReadAllLines($Path, $Utf8)) } else { return @() }
}

function Remove-Sections($Lines, $IsDropped) {
    $out = New-Object System.Collections.Generic.List[string]
    $skip = $false
    foreach ($line in $Lines) {
        if ($line -match '^\[') { $skip = & $IsDropped $line }
        if (-not $skip) { $out.Add($line) }
    }
    return ,$out
}

$Menu = Join-Path $Rez "reaper-menu.ini"
Backup $Menu
$kept = Remove-Sections (Read-Lines $Menu) { param($l) $l -eq "[Main toolbar]" -or $l -match '^\[Floating toolbar ([1-9]|10)\]$' }
$kept.AddRange([string[]](Src-Lines (Join-Path $Src "Toolbars\BSK_Toolbars.ini")))
Write-Lines $Menu $kept
Write-Host "Installed the toolbars (Main toolbar and floating toolbars 1 to 10)."

function Set-Key($Lines, $Section, $Key, $Value) {
    $out = New-Object System.Collections.Generic.List[string]
    $inSec = $false; $seen = $false; $done = $false
    foreach ($line in $Lines) {
        if ($line -match '^\[') {
            if ($inSec -and -not $done) { $out.Add("$Key=$Value"); $done = $true }
            $inSec = ($line -eq "[$Section]")
            if ($inSec) { $seen = $true }
            $out.Add($line); continue
        }
        if ($inSec -and $line.StartsWith("$Key=")) {
            if (-not $done) { $out.Add("$Key=$Value"); $done = $true }
            continue
        }
        $out.Add($line)
    }
    if (-not $done) {
        if (-not $seen) { $out.Add("[$Section]") }
        $out.Add("$Key=$Value")
    }
    return ,$out
}

$Ini = Join-Path $Rez "reaper.ini"
Backup $Ini
$lines = Read-Lines $Ini
foreach ($pair in Src-Lines (Join-Path $Src "Toolbars\BSK_Settings.txt")) {
    $i = $pair.IndexOf("=")
    if ($i -gt 0) { $lines = Set-Key $lines "REAPER" $pair.Substring(0, $i) $pair.Substring($i + 1) }
}
$current = $null
$inSec = $false
foreach ($line in $lines) {
    if ($line -match '^\[') { $inSec = ($line -eq "[REAPER]") }
    elseif ($inSec -and $line -match '^diskcheck=(\d+)$') { $current = [int]$Matches[1]; break }
}
$disk = if ($null -ne $current) { $current - ($current % 2) } else { 22 }
$lines = Set-Key $lines "REAPER" "diskcheck" $disk
$lines = Set-Key $lines "SWS" "Record input check" "0"
Write-Lines $Ini $lines
Write-Host "Set the mixer layouts, the recorded file names, and turned off the"
Write-Host "free disk space check and the SWS record input check at record start."

$Snm = Join-Path $Rez "S&M.ini"
Backup $Snm
$kept = Remove-Sections (Read-Lines $Snm) { param($l) $l -eq "[TrackTemplates]" }
$kept.AddRange([string[]](Src-Lines (Join-Path $Src "Toolbars\SWS-Resources-TrackTemplates.txt")))
Write-Lines $Snm $kept
Write-Host "Filled the SWS Resources track template list (slots 1-9)."

Write-Host ""
Write-Host "Your toolbars, window sets, reaper.ini, S&M.ini and startup file are backed up"
Write-Host "next to the originals with .backup-$Stamp"
Write-Host ""
Write-Host "Done. Finish inside REAPER (see README.txt):"
Write-Host "  1. Actions > Show action list > Key map... >"
Write-Host "     Import shortcuts/custom actions, import all sections...  -> Toolbars\BSK_Actions.ReaperKeyMap"
Write-Host "  2. Options > Themes > bsk_flat"
Write-Host "  3. Quit and restart REAPER."
