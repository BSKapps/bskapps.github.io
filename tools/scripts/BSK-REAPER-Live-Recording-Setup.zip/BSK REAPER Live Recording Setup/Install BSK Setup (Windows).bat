@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-BSK-Setup.ps1"
pause
