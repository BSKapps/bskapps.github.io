BSK REAPER LIVE RECORDING SETUP
===============================

A REAPER setup built for virtual soundcheck (VSC) and live multitrack
recording on a Mac. Every button and script is tuned for foolproof live
records: safe record, buttons that light to show what is on, outputs
that go back to the desk before the plugins, and checks before you roll.
It is not a general mixing setup.

Mac tested, untested on Windows. Some features like REC TIME LEFT may
not work on Windows.

WHAT IS IN IT
-------------
- Project templates for 8, 16, 32, 48 and 64 inputs and outputs, patched
  1:1, recording to a "REAPER AUDIO FILES" folder next to the project.
- Track templates that drop in 8 to 128 tracks patched 1:1, a blank
  track, and a Plugin Host (4 mono + 2 stereo).
- Four toolbar tabs: SETUP, RECORD, VSC and EDIT. Each tab swaps the
  main toolbar to the buttons for that job.
- The BSK scripts behind every button, the toolbar icons, the bsk_flat
  dark theme, and window sets for the meter bridge and mixer views.

REQUIREMENTS
------------
- REAPER 7.26 or newer  (reaper.fm)
- SWS Extension  (sws-extension.org), free. Install it first.

INSTALL ON A MAC
----------------
1. Install REAPER and the SWS Extension. Start REAPER once, then QUIT it.

2. Double-click "Install BSK Setup (Mac).command". The download is not
   signed, so the first time macOS may say it cannot be opened: go to
   System Settings > Privacy & Security, scroll down, click Open Anyway,
   then open it again. It copies the templates, scripts, icons, theme
   and window sets, installs the toolbars, turns on the settings below,
   and fills the SWS Resources track template list.

   It REPLACES your Main toolbar, floating toolbars 1 to 10, your window
   sets and your SWS track template list. Those files, and reaper.ini,
   are backed up next to the originals first. Templates, scripts, icons
   and the theme with the same names as ours are overwritten.

   Settings it changes:
   - The mixer views each button opens (meter bridge, strip, standard)
   - Recorded file names: date, time, project, track and take number
   - REAPER's free disk space check at record start: off
   - SWS record input check at record start: off
   Both checks can hold a record start on a shared input or a big drive.

3. Start REAPER and import the scripts and shortcuts:
   Actions > Show action list > Key map... (bottom left) >
   "Import shortcuts/custom actions, import all sections..." and choose
   Toolbars/BSK_Actions.ReaperKeyMap from this download.
   This registers every BSK script and custom action, and sets these
   keys (everything else stays as you had it):
      Space                 Play / pause. Never pauses a recording.
      Return                Play / stop. Never stops a recording.
      Shift+Space           Audition the time selection once
      Option+Shift+Space    Loop the time selection
      Control+Space         Loop and play the selected item, solo
      Option+Control+Space  Loop the whole selected item, solo
      Option+Shift+Left/Right  Move items left / right

4. Options > Themes > bsk_flat. The meter bridge and mixer views are
   built for this theme.

5. Quit and restart REAPER, so the buttons light from the start.

WINDOWS (UNTESTED)
------------------
Double-click "Install BSK Setup (Windows).bat", then do steps 3 to 5.
It does the same as the Mac installer, but nobody has run it on Windows
yet. Back up your REAPER resource folder first.

PORTABLE OR BY HAND
-------------------
For a separate portable REAPER, use the Portable download instead. To
install by hand, copy the CONTENTS of ProjectTemplates, TrackTemplates,
FXChains, Scripts, Data and ColorThemes into the same folders in
REAPER's resource folder (Options > Show REAPER resource path). Do not
let Finder replace whole folders: that deletes what is already in them.
Copy WindowSets/reaper-screensets.ini next to reaper.ini, import each
toolbar from Toolbars/ (right-click the toolbar > Customize toolbar...
> Import...), then do steps 3 to 5 above.

USING IT
--------
New show: File > Project templates > pick the size of your desk.

SETUP tab
- PREP REC checks the REAPER settings that can spoil a live recording,
  fixes the wrong ones, and shows the record drive and its free time.
- AUTO PATCH patches every track 1:1 to the interface's inputs and
  outputs. Set a track's input to stereo first (any pair will do) and it
  takes the next pair; the tracks after it move along. Tracks the
  interface cannot cover come out blank (no input or output), so nothing
  doubles up; a stereo one comes back stereo on a bigger interface.
- AUTO ROUTE sets the outputs pre FX, record monitoring off and master
  send off, for virtual soundcheck.
- AUTO NAME names tracks from the interface's input labels. CSV NAME
  names them from a console export (dLive, Avantis, SQ, Yamaha) or a
  plain list. AUTO COLOR colours tracks by name.
- Primary Record, Secondary Record and Dual Record set where every track
  records: the Mac, an external drive, or both. New tracks follow the
  choice. To change it back, press the button you want (Cmd+Z of one of
  these presses does not stick).
- MIX DOWN sets every track up for a mixdown; press again to put it all
  back. The 0dB button (RESET VOLUME, PAN AND OUTPUTS) puts faders,
  pans, outputs and items back to 0 dB.

RECORD tab
- SAFE REC arms every track, turns monitoring off and records from the
  end of the project, so a take never lands on old audio. It stays lit
  until recording stops. While it is lit it guards the record drives:
  if a drive being recorded to gets under 5 minutes or 5 GB free, it
  stops and saves the recording and says why, or on Dual, when only one
  drive is low, carries on recording on the other drive. A plain Record
  press is not guarded.
- TAKE saves the take and starts a new one with a marker.
- DELETE TAKE needs two presses within 3 seconds, so one stray press
  never deletes a take.
- REC TIME LEFT shows how long each record drive has left before SAFE
  REC's stop. It only shows: SAFE REC guards the drives whether this
  window is open or not.
- MIDI SCENE lets desk scene recalls (through Companion) drive REAPER,
  or ignore them while you tweak scenes.

VSC tab
- VSC UNITY stays lit while what goes back to the desk is exactly as it
  went in, and goes dark the moment a level changes. Once the project
  has recordings it also watches the patch, mutes and solos.
- FOLLOW FADERS lets the faders change what goes out, and the meters
  show post-fader to match; press again to put the outputs and meters
  back.
- AUDITION TOOLS loops a time selection or an item. Press the lit
  audition button again to stop, and the loop and solo go back how they
  were.

EDIT tab
- REMOVE SILENT GAPS finds the stretches where every track is silent,
  marks them as red regions and cuts every track at once. One undo puts
  it back. REMOVE SILENT TAKES lists takes with nothing on them;
  removing them sends their files to the Trash.
- TOOLS opens the automation, audition, fade and split toolbars.

Plugin Host
- A separate project for running a live insert plugin (feedback
  suppression, live tuning). Insert the "PLUGIN HOST 4 MONO 2 STEREO"
  track template into its own project, not your recording session, and
  open the PLUGIN HOST toolbar (Toolbar 4) from View > Toolbars.

Window positions were saved on the original Mac. If a mixer or meter
view lands somewhere odd, drag it where you want and re-save that set
(View > Screensets/Layouts > right-click the set > Save).

CREDITS
-------
Toolbar icon images include community icon sets shared on the REAPER
forums (DM icons, RIPO icons), included here for convenience.

bskapps.com
