BSK REAPER LIVE RECORDING SETUP
===============================

A complete REAPER setup for multitrack live recording:

- A clean project template (48kHz WAV, record-ready settings, no tracks)
- Track templates that drop in 8/16/32/48/64/96/128 tracks already
  patched 1:1 to your hardware inputs
- Scripts for auto-patching tracks and safe-record transport control
- The BSK toolbars (record workflow, editing, views, automation) with icons
- Window sets and theme, so the meter bridge and mixer view buttons open
  the exact layouts they were built for

REQUIREMENTS
------------
- REAPER 7.x  (reaper.fm)
- SWS Extension  (sws-extension.org) - free. Several toolbar buttons and
  all cycle actions need it. Install it before importing anything below.

INSTALL
-------
1. In REAPER go to Options > Show REAPER resource path in finder/explorer.
   Keep that window open.

2. Copy the CONTENTS of these folders from this download into the
   same-named folders in the resource path:
      ProjectTemplates  ->  ProjectTemplates
      TrackTemplates    ->  TrackTemplates
      Scripts           ->  Scripts
      Data              ->  Data
      ColorThemes       ->  ColorThemes
   (You are merging files in, not replacing the folders.)

   Then QUIT REAPER and copy the two files from the WindowSets folder
   into the resource path itself (the top level, next to reaper.ini):
      reaper-screensets.ini   - the window sets the view buttons load
      reaper-themeconfig.ini  - theme color calibration
   If you already use screensets of your own, back up your existing
   reaper-screensets.ini first - this replaces it.

3. Register the scripts and custom actions:
   Actions > Show action list > Key map... (bottom left) > Import...
   Choose Toolbars/BSK_Actions.ReaperKeyMap from this download.
   This adds the scripts and custom actions only. It does not change
   any of your keyboard shortcuts.

4. Import the cycle actions:
   Extensions > Cycle Action editor > Import/export > Import all sections
   Choose Toolbars/BSK_Cyclactions.ini from this download.
   Note: the toolbars expect these in Main section slots 1-21, so on a
   setup that already has cycle actions in those slots some toolbar
   buttons will trigger the wrong action.

5. Import the toolbars:
   Right-click the main toolbar > Customize toolbar... > Import...
   Choose Toolbars/BSK Main Toolbar REC.ReaperMenu.
   For the floating toolbars, open each one (Actions list: search
   "open toolbar 1" etc), then right-click it > Customize toolbar... >
   Import... and pick the matching file:
      Toolbar 1 = EDIT, 2 = VIEWS, 3 = AUTOMATION, 5 = AUDITION,
      6 = FADES, 7 = SPLIT GLUE
   Importing a toolbar replaces that toolbar only.

6. Fill the track template list: the toolbar's track template button
   opens the SWS Resources window. First time in, right-click in the
   empty list > Auto-fill slots (or Add files) to pull in the 8-128
   Tracks IO Patched templates, and set the Double-click dropdown at
   the bottom to Import tracks.

7. Set the theme: Options > Themes > Default_5.0_green_yellow_red_VU.
   The meter bridge and mixer window sets use this theme's mixer
   layouts, so with a different theme those views will not look right.

8. Restart REAPER.

USING IT
--------
- New session: File > Project templates > BSK Live Recording.
  Recording goes to a "REAPER AUDIO FILES" folder next to the project.
- Add patched tracks: insert a track template (8-128 Tracks IO Patched)
  from the toolbar button or Track menu. Tracks arrive named, armed
  and patched 1:1 to hardware inputs.
- Or insert plain tracks yourself and run BSK_AutoPatch_HW_1to1_Mono
  from the toolbar (AUTO PATCH 1:1) to patch them in one go.
  BSK_AutoPatch_HW_Teardown clears the patching.
- BSK_Import_Track_Names renames your tracks from a pasted list, so you
  can prep track names from a channel list in seconds.
- The main toolbar carries the record workflow: safe record with marker,
  next/new record with marker, finish record stop/save, record monitor
  toggle, arm/mute all, and primary/secondary record path toggles.
- The view buttons (METER BRIDGE, STRIP MIXER, DEFAULT MIXER and the
  VIEWS toolbar) load the included window sets: full meter bridge,
  strip inputs mixer, normal mixer, edit view, split mixer, routing
  matrix and small meter bridge. Window positions were saved on the
  original machine, so if one lands somewhere odd on your screen, drag
  it where you want and re-save that set (View > Screensets/Layouts >
  right-click the set > Save) to make the position stick.

CREDITS
-------
Toolbar icon images include community icon sets shared on the REAPER
forums (DM icons, RIPO icons), included here for convenience.

bskapps.com
